package com.ammaster.app

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ammaster.core.AssetStatus
import com.ammaster.core.RunMode
import com.ammaster.core.RunStatus
import com.ammaster.core.specText

private fun fmt(ms: Long): String {
    val s = ms / 1000.0
    val m = (s / 60).toInt()
    return "%d:%04.1f".format(m, s - m * 60)
}

private fun modeLabel(m: RunMode) = when (m) {
    RunMode.PLAN_ONLY -> "تخطيط فقط"
    RunMode.ASSISTED -> "مساعدة"
    RunMode.AUTONOMOUS -> "مستقل"
}

private fun statusLabel(s: RunStatus) = when (s) {
    RunStatus.PLANNED -> "خطة جاهزة (دون تنفيذ)"
    RunStatus.WAITING_ASSETS -> "بانتظار المواد"
    RunStatus.READY -> "جاهز للتنفيذ (التنفيذ الآلي داخل Alight Motion لم يُبنَ بعد)"
    RunStatus.RUNNING -> "قيد التنفيذ"
    RunStatus.PAUSED -> "متوقف"
    RunStatus.DONE -> "مكتمل"
    RunStatus.FAILED -> "فشل"
}

@Composable
fun ProjectScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var goal by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(RunMode.ASSISTED) }
    var pendingAsset by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { vm.loadLatestRun() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val id = pendingAsset
        if (uri != null && id != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (t: Throwable) {
                // بعض المزودين لا يدعمون الإذن الدائم؛ يبقى الإذن طوال الجلسة.
            }
            vm.provideAsset(id, uri.toString())
        }
        pendingAsset = null
    }

    val run = vm.run

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("مشروع مونتاج منظم", style = MaterialTheme.typography.titleLarge) }
        item {
            Text(
                "ينتج خطة JSON قابلة للتنفيذ ويتحقق منها ويحفظ حالتها لاستئنافها بعد إغلاق التطبيق. البحث التلقائي عن المواد والتنفيذ داخل Alight Motion لم يُبنيا بعد.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        item {
            OutlinedTextField(
                value = goal,
                onValueChange = { goal = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("فكرة الفيديو") },
                minLines = 2,
            )
        }
        item {
            Column {
                RunMode.values().forEach { m ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = mode == m, onClick = { mode = m })
                        Text(modeLabel(m))
                    }
                }
            }
        }
        item {
            Button(enabled = goal.isNotBlank() && !vm.runBusy, onClick = { vm.createRun(goal, mode) }) {
                Text(if (vm.runBusy) "…جارٍ التخطيط" else "أنشئ المشروع")
            }
        }
        vm.runError?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }

        if (run != null) {
            val plan = run.plan
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الحالة: ${statusLabel(run.status)}", style = MaterialTheme.typography.titleSmall)
                        Text("الفكرة: ${run.goal}")
                        Text("الوضع الحالي:", style = MaterialTheme.typography.labelMedium)
                        RunMode.values().forEach { m ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = run.mode == m, onClick = { vm.changeMode(m) })
                                Text(modeLabel(m))
                            }
                        }
                    }
                }
            }
            if (plan != null) {
                item {
                    Text(
                        "${plan.title} · ${plan.aspectRatio} · ${plan.fps}fps · ${fmt(plan.totalDurationMs)}",
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
                plan.scenes.forEach { sc ->
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(sc.title, style = MaterialTheme.typography.titleSmall)
                                sc.shots.sortedBy { it.startMs }.forEach { sh ->
                                    val parts = listOfNotNull(
                                        "${fmt(sh.startMs)}–${fmt(sh.startMs + sh.durationMs)}",
                                        sh.assetId.takeIf { it.isNotBlank() }?.let { "مادة $it" },
                                        sh.text.takeIf { it.isNotBlank() }?.let { "«$it»" },
                                        sh.effects.takeIf { it.isNotEmpty() }?.joinToString("+") { e -> e.name },
                                        sh.transition?.name?.takeIf { it.isNotBlank() }?.let { "انتقال $it" },
                                    )
                                    Text(parts.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
                if (run.issues.isNotEmpty()) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text("ملاحظات التحقق", style = MaterialTheme.typography.titleSmall)
                                run.issues.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                }
                item { Text("المواد المطلوبة", style = MaterialTheme.typography.titleMedium) }
                items(plan.assets, key = { it.id }) { a ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            val provided = a.status == AssetStatus.USER_PROVIDED || a.status == AssetStatus.FOUND_LOCAL
                            if (provided) {
                                Text("✔ ${a.id}: ${a.description}", style = MaterialTheme.typography.titleSmall)
                                Text(a.uri, style = MaterialTheme.typography.bodySmall)
                            } else {
                                Text(a.specText(), style = MaterialTheme.typography.bodyMedium)
                            }
                            OutlinedButton(onClick = {
                                pendingAsset = a.id
                                picker.launch(arrayOf("image/*", "video/*"))
                            }) { Text(if (provided) "استبدال الملف" else "اختر ملفاً من هاتفك") }
                        }
                    }
                }
            }
        }
    }
}
