package com.ammaster.app

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ammaster.core.ImplStatus

@Composable
fun StatusScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.refreshStatus() }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("حالة الوحدات (المرحلة 1)", style = MaterialTheme.typography.titleLarge) }
        item { Text("الموسوعة: ${vm.kbCount} إدخالاً") }
        vm.seedError?.let { err -> item { Text("خطأ في تحميل بذرة الموسوعة: $err", color = MaterialTheme.colorScheme.error) } }
        items(vm.modules, key = { it.name }) { m ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    val label = when (m.status) {
                        ImplStatus.IMPLEMENTED -> "✅ مكتمل"
                        ImplStatus.PARTIAL -> "🟡 جزئي"
                        ImplStatus.PLANNED -> "⏳ مخطط"
                    }
                    Text("${m.name}  —  $label", style = MaterialTheme.typography.titleSmall)
                    Text(m.summary, style = MaterialTheme.typography.bodyMedium)
                    m.missing.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        item { Text("اختبار OPERATOR وVISION", style = MaterialTheme.typography.titleMedium) }
        item {
            Text(
                if (vm.operatorReady) "خدمة الوصول: مفعّلة" else "خدمة الوصول: غير مفعّلة. فعّلها من الإعدادات ثم اضغط تحديث.",
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("إعدادات الوصول") }
                OutlinedButton(onClick = { vm.refreshStatus() }) { Text("تحديث") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = vm.operatorReady && !vm.diagBusy, onClick = { vm.testScreenshot() }) { Text("اختبار الالتقاط") }
                Button(enabled = vm.operatorReady && !vm.diagBusy, onClick = { vm.testVision() }) { Text("اختبار الرؤية") }
            }
        }
        vm.diagnostics?.let { d -> item { Text(d) } }
    }
}
