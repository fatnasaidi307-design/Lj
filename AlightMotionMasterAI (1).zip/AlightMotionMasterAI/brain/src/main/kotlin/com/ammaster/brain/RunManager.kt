package com.ammaster.brain

import com.ammaster.core.AssetStatus
import com.ammaster.core.MemoryStore
import com.ammaster.core.PlanValidator
import com.ammaster.core.RunLogic
import com.ammaster.core.RunMode
import com.ammaster.core.RunState
import com.ammaster.core.RunStore
import com.ammaster.core.Severity
import com.ammaster.core.VideoPlanner
import java.util.UUID

/** ينشئ المشاريع المنظمة ويحفظ حالتها بعد كل تغيير، فيمكن استئنافها بعد إغلاق التطبيق. */
class RunManager(
    private val planner: VideoPlanner,
    private val memory: MemoryStore,
    private val store: RunStore,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    suspend fun create(goal: String, mode: RunMode): Result<RunState> = runCatching {
        val hits = memory.searchKnowledge(goal, 8)
        val plan = planner.plan(goal, hits).getOrThrow()
        val known = memory.listKnowledge(1000).map { it.key }.toSet()
        val issues = PlanValidator.validate(plan, known)
        check(issues.none { it.severity == Severity.ERROR }) {
            "Invalid plan: " + issues.filter { it.severity == Severity.ERROR }.joinToString { it.message }
        }
        val state = RunState(
            runId = UUID.randomUUID().toString(),
            goal = goal,
            mode = mode,
            plan = plan,
            issues = issues.map { "${it.severity}: ${it.message}" },
            status = RunLogic.statusFor(mode, plan),
            log = listOf("created"),
            updatedAt = clock(),
        )
        store.save(state)
        state
    }

    suspend fun provideAsset(state: RunState, assetId: String, uri: String): RunState {
        val next = RunLogic.withAsset(state, assetId, AssetStatus.USER_PROVIDED, uri, clock())
        store.save(next)
        return next
    }

    suspend fun changeMode(state: RunState, mode: RunMode): RunState {
        val next = RunLogic.withMode(state, mode, clock())
        store.save(next)
        return next
    }

    suspend fun resume(): RunState? = store.latestUnfinished()
}
