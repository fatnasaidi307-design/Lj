package com.ammaster.core

import kotlinx.serialization.Serializable

@Serializable
data class PlanStep(val title: String, val technique: String = "", val details: String = "")

@Serializable
data class Plan(val goal: String, val steps: List<PlanStep>)

sealed class UiAction {
    data class Tap(val x: Int, val y: Int) : UiAction()
    data class LongPress(val x: Int, val y: Int, val durationMs: Long = 600) : UiAction()
    data class Swipe(val x1: Int, val y1: Int, val x2: Int, val y2: Int, val durationMs: Long = 300) : UiAction()
    data object Back : UiAction()
    data class Wait(val ms: Long) : UiAction()
}

/** لقطة شاشة مصغّرة؛ deviceWidth/Height هما الأبعاد الحقيقية لتحويل الإحداثيات. */
class Screenshot(
    val jpegBase64: String,
    val width: Int,
    val height: Int,
    val deviceWidth: Int = width,
    val deviceHeight: Int = height,
)

data class Observation(val summary: String)

data class Review(val score: Int, val passed: Boolean, val issues: List<String>, val suggestions: List<String>)

data class Failure(val step: PlanStep?, val message: String, val attempt: Int)

sealed class RecoveryDecision {
    data class Retry(val adjustedDetails: String) : RecoveryDecision()
    data class Alternative(val newStep: PlanStep) : RecoveryDecision()
    data class GiveUp(val reason: String) : RecoveryDecision()
}

object KnowledgeStatus {
    const val VERIFIED = "verified"
    const val UNVERIFIED = "unverified"
}

data class KnowledgeEntry(
    val key: String,
    val category: String,
    val title: String,
    val body: String,
    val keywords: String = "",
    val sourceUrl: String = "",
    val status: String = KnowledgeStatus.UNVERIFIED,
    val verifiedAt: String = "",
)

data class KnowledgeHit(val entry: KnowledgeEntry, val score: Double)

data class Experience(
    val id: Long = 0,
    val goal: String,
    val outcome: String,
    val score: Int,
    val notes: String,
    val createdAt: Long,
)
