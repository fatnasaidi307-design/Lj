package com.ammaster.core

data class ChatMessage(val role: String, val text: String, val imageJpegBase64: String? = null)

data class ChatRequest(
    val messages: List<ChatMessage>,
    val system: String? = null,
    val maxTokens: Int = 1024,
    val temperature: Double? = null,
)

data class ChatResponse(val text: String, val providerName: String = "")

interface LlmClient {
    suspend fun chat(request: ChatRequest): Result<ChatResponse>
}

interface MemoryStore : ExpertModule {
    suspend fun searchKnowledge(query: String, limit: Int = 5): List<KnowledgeHit>
    suspend fun listKnowledge(limit: Int = 50): List<KnowledgeEntry>
    suspend fun upsertKnowledge(entry: KnowledgeEntry)
    suspend fun knowledgeCount(): Int
    suspend fun saveExperience(experience: Experience): Long
    suspend fun recentExperiences(limit: Int = 5): List<Experience>
}

interface Planner : ExpertModule {
    suspend fun plan(goal: String, knowledge: List<KnowledgeHit>): Result<Plan>
}

interface Vision : ExpertModule {
    suspend fun observe(shot: Screenshot, question: String): Result<Observation>
}

interface Operator : ExpertModule {
    suspend fun isReady(): Boolean
    suspend fun screenshot(): Result<Screenshot>
    suspend fun perform(action: UiAction): Result<Unit>
}

interface Reviewer : ExpertModule {
    suspend fun review(goal: String, expected: String, shot: Screenshot): Result<Review>
}

interface Recovery : ExpertModule {
    suspend fun decide(failure: Failure, knowledge: List<KnowledgeHit>): Result<RecoveryDecision>
}
