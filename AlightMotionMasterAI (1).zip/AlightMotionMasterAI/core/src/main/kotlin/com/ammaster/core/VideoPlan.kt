package com.ammaster.core

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
enum class MediaKind { IMAGE, VIDEO }

@Serializable
enum class AssetStatus { UNRESOLVED, FOUND_LOCAL, MISSING, USER_PROVIDED }

/** مادة مطلوبة للمشروع (صورة/فيديو). الحالة يحددها التطبيق لا النموذج. */
@Serializable
data class AssetRequest(
    val id: String,
    val kind: MediaKind = MediaKind.IMAGE,
    val description: String,
    val orientation: String = "any", // portrait | landscape | square | any
    val minWidth: Int = 0,
    val minHeight: Int = 0,
    val durationMs: Long = 0,
    val cameraAngle: String = "",
    val background: String = "",
    val needsTransparency: Boolean = false,
    val searchKeywords: List<String> = emptyList(),
    val status: AssetStatus = AssetStatus.UNRESOLVED,
    val uri: String = "",
    val rejectedReasons: List<String> = emptyList(),
)

/** تأثير: kbKey مفتاح إدخاله في الموسوعة؛ فارغ أو غير موجود يعني غير موثّق. */
@Serializable
data class EffectSpec(val name: String, val kbKey: String = "", val params: Map<String, String> = emptyMap())

@Serializable
data class TransitionSpec(val name: String, val kbKey: String = "", val durationMs: Long = 0)

@Serializable
data class Shot(
    val id: String,
    val startMs: Long,
    val durationMs: Long,
    val assetId: String = "",
    val text: String = "",
    val effects: List<EffectSpec> = emptyList(),
    val transition: TransitionSpec? = null,
    val layerOrder: List<String> = emptyList(), // من الأسفل إلى الأعلى
    val notes: String = "",
)

@Serializable
data class Scene(val id: String, val title: String, val shots: List<Shot>)

@Serializable
data class VideoPlan(
    val title: String,
    val aspectRatio: String = "9:16",
    val fps: Int = 30,
    val totalDurationMs: Long,
    val scenes: List<Scene>,
    val assets: List<AssetRequest> = emptyList(),
)

object PlanJson {
    val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        isLenient = true
        encodeDefaults = true
    }

    fun decode(text: String): VideoPlan = json.decodeFromString(VideoPlan.serializer(), text)
}

enum class Severity { ERROR, WARNING }

data class PlanIssue(val severity: Severity, val message: String)

object PlanValidator {
    fun validate(plan: VideoPlan, knownKbKeys: Set<String>): List<PlanIssue> {
        val issues = mutableListOf<PlanIssue>()
        fun err(m: String) { issues.add(PlanIssue(Severity.ERROR, m)) }
        fun warn(m: String) { issues.add(PlanIssue(Severity.WARNING, m)) }

        if (plan.totalDurationMs <= 0) err("totalDurationMs must be positive")
        if (plan.fps !in 1..120) err("fps must be between 1 and 120")
        if (plan.scenes.isEmpty()) err("plan has no scenes")

        val assetIds = plan.assets.map { it.id }
        if (assetIds.size != assetIds.toSet().size) err("duplicate asset ids")

        val shotIds = HashSet<String>()
        val usedAssets = HashSet<String>()
        for (scene in plan.scenes) {
            if (scene.shots.isEmpty()) warn("scene '${scene.id}' has no shots")
            var prevEnd = -1L
            for (shot in scene.shots.sortedBy { it.startMs }) {
                if (!shotIds.add(shot.id)) err("duplicate shot id '${shot.id}'")
                if (shot.startMs < 0) err("shot '${shot.id}' starts before 0")
                if (shot.durationMs <= 0) err("shot '${shot.id}' has non-positive duration")
                if (shot.startMs + shot.durationMs > plan.totalDurationMs) err("shot '${shot.id}' ends after totalDurationMs")
                if (prevEnd > shot.startMs) warn("shot '${shot.id}' overlaps the previous shot in scene '${scene.id}'")
                prevEnd = shot.startMs + shot.durationMs
                if (shot.assetId.isNotBlank()) {
                    usedAssets.add(shot.assetId)
                    if (shot.assetId !in assetIds) err("shot '${shot.id}' uses unknown asset '${shot.assetId}'")
                }
                shot.effects.forEach {
                    if (it.kbKey.isBlank() || it.kbKey !in knownKbKeys) {
                        warn("effect '${it.name}' (shot '${shot.id}') is not in the knowledge base: unverified")
                    }
                }
                shot.transition?.let {
                    if (it.kbKey.isBlank() || it.kbKey !in knownKbKeys) {
                        warn("transition '${it.name}' (shot '${shot.id}') is not in the knowledge base: unverified")
                    }
                }
            }
        }
        for (a in plan.assets) {
            if (a.description.isBlank()) err("asset '${a.id}' has no description")
            if (a.kind == MediaKind.VIDEO && a.durationMs <= 0) warn("video asset '${a.id}' has no duration")
            if (a.id !in usedAssets) warn("asset '${a.id}' is not used by any shot")
        }
        return issues
    }

    fun hasErrors(issues: List<PlanIssue>): Boolean = issues.any { it.severity == Severity.ERROR }
}

/** نص مواصفات المادة. العنوان MISSING ASSET يُستعمل فقط عند ثبوت أن المادة غير موجودة بعد بحث فعلي. */
fun AssetRequest.specText(): String = buildString {
    append(if (status == AssetStatus.MISSING) "MISSING ASSET\n" else "المادة المطلوبة\n")
    append("المعرّف: $id\n")
    append("النوع: ${if (kind == MediaKind.VIDEO) "فيديو" else "صورة"}\n")
    append("الوصف: $description\n")
    append("الاتجاه: $orientation")
    if (minWidth > 0 || minHeight > 0) append(" · الحد الأدنى ${minWidth}x$minHeight")
    append("\n")
    if (kind == MediaKind.VIDEO && durationMs > 0) append("المدة: ${durationMs / 1000.0} ث\n")
    if (cameraAngle.isNotBlank()) append("زاوية التصوير: $cameraAngle\n")
    if (background.isNotBlank()) append("الخلفية: $background\n")
    append("خلفية شفافة: ${if (needsTransparency) "نعم" else "لا"}\n")
    if (searchKeywords.isNotEmpty()) append("كلمات بحث: ${searchKeywords.joinToString("، ")}\n")
    if (rejectedReasons.isNotEmpty()) {
        append("أسباب رفض المواد التي وُجدت:\n")
        rejectedReasons.forEach { append("- $it\n") }
    }
}.trimEnd()
