package com.ammaster.memory

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** المخطط يُقرأ من assets/schema.sql حتى يبقى مصدراً واحداً مشتركاً مع tools/validate_kb.py. */
class MemoryDb(private val context: Context, name: String = "ammaster.db") :
    SQLiteOpenHelper(context, name, null, SCHEMA_VERSION) {

    override fun onCreate(db: SQLiteDatabase) = applySchema(db)

    /** المخطط كله بصيغة IF NOT EXISTS، فالترقية تعيد تطبيقه دون المساس بالبيانات الموجودة. */
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = applySchema(db)

    private fun applySchema(db: SQLiteDatabase) {
        val sql = context.assets.open("schema.sql").bufferedReader(Charsets.UTF_8).use { it.readText() }
        sql.split(";").map { it.trim() }.filter { it.isNotEmpty() }.forEach { db.execSQL(it) }
    }

    companion object {
        const val SCHEMA_VERSION = 2
    }
}
