package com.ammaster.operator

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.ammaster.core.Screenshot
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** الخدمة لا تفعل شيئاً من تلقاء نفسها: تنفّذ فقط ما يطلبه AccessibilityOperator. */
class AlightAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    suspend fun gesture(path: Path, durationMs: Long) = suspendCancellableCoroutine<Unit> { cont ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1)))
            .build()
        val accepted = dispatchGesture(
            g,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(Unit)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resumeWithException(IllegalStateException("Gesture was cancelled"))
                }
            },
            null,
        )
        if (!accepted && cont.isActive) cont.resumeWithException(IllegalStateException("Gesture was rejected"))
    }

    /** يلتقط الشاشة (Android 11+) ويصغّرها إلى 1280px كحد أقصى ويضغطها JPEG. */
    suspend fun capture(): Screenshot = suspendCancellableCoroutine { cont ->
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val buffer = result.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                            ?: throw IllegalStateException("wrapHardwareBuffer returned null")
                        val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                            ?: throw IllegalStateException("Bitmap copy failed")
                        buffer.close()
                        val scale = minOf(1f, MAX_SIDE / maxOf(soft.width, soft.height).toFloat())
                        val out = if (scale < 1f) {
                            Bitmap.createScaledBitmap(soft, (soft.width * scale).toInt(), (soft.height * scale).toInt(), true)
                        } else {
                            soft
                        }
                        val bos = ByteArrayOutputStream()
                        out.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                        val shot = Screenshot(
                            Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP),
                            out.width, out.height, soft.width, soft.height,
                        )
                        if (cont.isActive) cont.resume(shot)
                    } catch (t: Throwable) {
                        if (cont.isActive) cont.resumeWithException(t)
                    }
                }

                override fun onFailure(errorCode: Int) {
                    if (cont.isActive) {
                        cont.resumeWithException(IllegalStateException("takeScreenshot failed, error code $errorCode"))
                    }
                }
            },
        )
    }

    companion object {
        @Volatile
        var instance: AlightAccessibilityService? = null
            private set

        private const val MAX_SIDE = 1280f
    }
}
