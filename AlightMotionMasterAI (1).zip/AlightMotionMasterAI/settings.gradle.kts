pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "AlightMotionMasterAI"

// كل وحدة مستقلة: تعتمد فقط على :core (العقود) ولا تعتمد على بعضها.
include(":core")      // النماذج والعقود (Ports) - Kotlin خالص
include(":llm")       // عميل API متعدد المزودين + مزود احتياطي
include(":memory")    // SQLite: الموسوعة + الخبرات + تخزين إعدادات المزودين
include(":brain")     // EXPERT BRAIN
include(":planner")   // PLANNER
include(":vision")    // VISION
include(":operator")  // OPERATOR (خدمة الوصول: لمس + لقطة شاشة)
include(":reviewer")  // REVIEWER
include(":recovery")  // RECOVERY
include(":app")       // الواجهة (Compose) وربط الوحدات
