#!/usr/bin/env python3
"""يتحقق من: صحة بذرة الموسوعة، المخطط الفعلي (assets/schema.sql)، والبحث FTS4 بنفس التطبيع المستعمل في Kotlin.
يشغَّل محلياً وفي GitHub Actions قبل البناء."""
import json, pathlib, re, sqlite3, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
ASSETS = ROOT / "memory/src/main/assets"
OFFICIAL = ("https://support.alightmotion.com/", "https://alightmotion.com/", "https://alightcreative.com/")
errors = []

# ---- نسخة مطابقة لـ core/.../Lexical.kt ----
DIAC = re.compile("[\u064B-\u065F\u0670\u0640]")
NONWORD = re.compile(r"[\W_]+", re.UNICODE)
STOP = {"ما","هو","هي","في","من","على","الي","عن","مع","كيف","لماذا","هل","ان","ال","او","و",
        "what","is","the","how","to","of","in","and","do","my","me","can"}
def map_chars(s):
    return "".join({"أ":"ا","إ":"ا","آ":"ا","ى":"ي","ة":"ه"}.get(c, c) for c in s)
def normalize(s):
    s = NONWORD.sub(" ", map_chars(DIAC.sub("", s.lower())))
    words = [w for w in s.split(" ") if w]
    return " ".join(w[2:] if w.startswith("ال") and len(w) > 4 else w for w in words)
def tokens(q):
    out = []
    for t in normalize(q).split(" "):
        if len(t) >= 2 and t not in STOP and t not in out:
            out.append(t)
    return out[:12]
def fts_query(toks): return " OR ".join(t + "*" for t in toks)

# ---- 1) صحة البذرة ----
seed = json.loads((ASSETS / "kb_seed.json").read_text(encoding="utf-8"))
if not isinstance(seed.get("seed_version"), int): errors.append("seed_version must be int")
keys = set()
for e in seed["entries"]:
    k = e.get("key", "?")
    for f in ("key", "category", "title", "body", "keywords", "source_url", "status", "verified_at"):
        if f not in e: errors.append(f"{k}: missing {f}")
    if k in keys: errors.append(f"{k}: duplicate key")
    keys.add(k)
    if e.get("status") not in ("verified", "unverified"): errors.append(f"{k}: bad status")
    if not e.get("title", "").strip() or len(e.get("body", "")) < 20: errors.append(f"{k}: empty title/body")
    if e.get("status") == "verified":
        if not e.get("source_url", "").startswith(OFFICIAL): errors.append(f"{k}: verified entry needs an official source_url")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", e.get("verified_at", "")): errors.append(f"{k}: verified_at must be YYYY-MM-DD")

# ---- 2) المخطط + البحث ----
db = sqlite3.connect(":memory:")
for stmt in (ASSETS / "schema.sql").read_text(encoding="utf-8").split(";"):
    if stmt.strip(): db.execute(stmt)
for e in seed["entries"]:
    cur = db.execute("INSERT INTO knowledge(key,category,title,body,keywords,source_url,status,verified_at,origin,updated_at) VALUES (?,?,?,?,?,?,?,?,'seed',0)",
                     (e["key"], e["category"], e["title"], e["body"], e["keywords"], e["source_url"], e["status"], e["verified_at"]))
    db.execute("INSERT INTO knowledge_fts(docid,title,body,keywords) VALUES (?,?,?,?)",
               (cur.lastrowid, normalize(e["title"]), normalize(e["body"]), normalize(e["keywords"])))

def search(q):
    toks = tokens(q)
    if not toks: return []
    ids = [r[0] for r in db.execute("SELECT docid FROM knowledge_fts WHERE knowledge_fts MATCH ? LIMIT 80", (fts_query(toks),))]
    scored = []
    for i in ids:
        key, title, kw, body, st = db.execute("SELECT key,title,keywords,body,status FROM knowledge WHERE id=?", (i,)).fetchone()
        s = sum((3 if t in normalize(title) else 0) + (2 if t in normalize(kw) else 0) + (1 if t in normalize(body) else 0) for t in toks)
        scored.append((s * (1.0 if st == "verified" else 0.8), key))
    return [k for _, k in sorted(scored, reverse=True)]

EXPECT = [  # (استعلام, مفتاح يجب أن يظهر ضمن أول 3 نتائج)
    ("ما هو Easing", "easing.what"),
    ("كيف أضيف Null Object", "null.add"),
    ("Copy Curve", "easing.copy_paste_curve"),
    ("Enable Overshoot", "easing.overshoot"),
    ("الارتداد bounce elastic", "easing.advanced_types"),
    ("ربط الطبقات parenting", "parenting.overview"),
]
for q, want in EXPECT:
    top = search(q)[:3]
    if want not in top: errors.append(f"search '{q}': expected {want} in top3, got {top}")
if search("zzzzqqqq"): errors.append("nonsense query should return nothing")

# ---- 2b) المخطط idempotent + جدول حفظ الحالة ----
for stmt in (ASSETS / "schema.sql").read_text(encoding="utf-8").split(";"):
    if stmt.strip(): db.execute(stmt)  # إعادة التطبيق (ترقية) يجب ألا تفشل ولا تمسح بيانات
db.execute("INSERT OR REPLACE INTO run_state(run_id,status,json,updated_at) VALUES ('r','READY','{}',1)")
db.execute("INSERT OR REPLACE INTO run_state(run_id,status,json,updated_at) VALUES ('r2','DONE','{}',2)")
latest = db.execute("SELECT run_id FROM run_state WHERE status NOT IN ('DONE','FAILED') ORDER BY updated_at DESC LIMIT 1").fetchone()
if not latest or latest[0] != 'r': errors.append("run_state latestUnfinished query failed")
if db.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0] != len(seed["entries"]): errors.append("schema re-apply lost data")

# ---- 3) تحديث أمين: إعادة الفهرسة لا تكرر الصفوف ----
before = db.execute("SELECT COUNT(*) FROM knowledge_fts").fetchone()[0]
if before != len(seed["entries"]): errors.append("fts row count mismatch")

if errors:
    print("KB VALIDATION FAILED"); [print(" -", x) for x in errors]; sys.exit(1)
print(f"KB OK: {len(seed['entries'])} entries, {len(EXPECT)} search checks passed, sqlite {sqlite3.sqlite_version}")
