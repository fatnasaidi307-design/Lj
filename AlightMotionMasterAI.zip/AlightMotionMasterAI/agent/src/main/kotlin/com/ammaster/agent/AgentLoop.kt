package com.ammaster.agent

import com.ammaster.core.ActionDecider
import com.ammaster.core.AgentStatus
import com.ammaster.core.Decision
import com.ammaster.core.GoalVerifier
import com.ammaster.core.Operator
import com.ammaster.core.RunMode
import com.ammaster.core.SafetyPolicy
import com.ammaster.core.Screenshot
import com.ammaster.core.StepRecord
import com.ammaster.core.UiAction
import com.ammaster.core.describe
import com.ammaster.core.kind
import com.ammaster.core.nodeToImage
import com.ammaster.core.scaledToDevice
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive

data class AgentResult(val success: Boolean, val message: String, val steps: Int)

/**
 * حلقة: لقطة ← قرار ← سياسة الأمان ← تنفيذ ← انتظار ← (تحقق مستقل عند ادّعاء الإنجاز).
 * تتوقف عند: نجاح محقَّق، فشل، تكرار بلا تقدم، حد الخطوات، أو إلغاء المستخدم.
 */
class AgentLoop(
    private val operator: Operator,
    private val decider: ActionDecider,
    private val verifier: GoalVerifier,
    private val maxSteps: Int = 15,
    private val settleMs: Long = 1500,
    private val allowedPackages: Set<String> = setOf("com.alightcreative.motion"),
    private val log: (String) -> Unit = {},
) {
    suspend fun run(
        goal: String,
        mode: RunMode,
        knowledge: String = "",
        initialActions: List<UiAction> = emptyList(),
    ): AgentResult {
        if (mode == RunMode.PLAN_ONLY) return AgentResult(false, "وضع التخطيط فقط لا ينفّذ شيئاً", 0)
        if (!operator.isReady()) return AgentResult(false, "خدمة الوصول غير مفعّلة", 0)

        for (a in initialActions) {
            if (a is UiAction.OpenApp && a.packageName !in allowedPackages) return AgentResult(false, "تطبيق غير مسموح", 0)
            if (SafetyPolicy.decide(mode, a.kind()) != Decision.ALLOW) return AgentResult(false, "السياسة تمنع: ${a.describe()}", 0)
            log("تمهيد: ${a.describe()}")
            val r = operator.perform(a)
            if (r.isFailure) return AgentResult(false, "فشل ${a.describe()}: ${r.exceptionOrNull()?.message}", 0)
            delay(settleMs * 2)
        }

        val history = mutableListOf<StepRecord>()
        val recent = mutableListOf<String>()
        for (n in 1..maxSteps) {
            currentCoroutineContext().ensureActive()
            val shot = capture() ?: return AgentResult(false, "تعذّر التقاط الشاشة", n - 1)
            val nodes = operator.uiNodes().map { shot.nodeToImage(it) }
            val decision = decider.decide(goal, knowledge, history, shot, nodes)
                .getOrElse { return AgentResult(false, "فشل قرار النموذج: ${it.message}", n - 1) }

            if (decision.status == AgentStatus.FAILED) return AgentResult(false, "توقف الوكيل: ${decision.reason}", n - 1)
            if (decision.status == AgentStatus.DONE) {
                val v = verifier.verify(goal, shot, nodes)
                    .getOrElse { return AgentResult(false, "فشل التحقق: ${it.message}", n - 1) }
                if (v.achieved) return AgentResult(true, v.evidence, n - 1)
                log("المدقّق رفض ادّعاء الإنجاز: ${v.evidence}")
                history.add(StepRecord(n, "claimed done", decision.reason, "", "verification rejected: ${v.evidence}"))
                continue
            }

            val action = decision.action ?: return AgentResult(false, "قرار بلا إجراء", n - 1)
            if (action is UiAction.OpenApp && action.packageName !in allowedPackages) {
                log("تم حجب فتح تطبيق غير مسموح: ${action.packageName}")
                history.add(StepRecord(n, action.describe(), decision.reason, decision.expected, "blocked: app not allowed"))
                continue
            }
            when (SafetyPolicy.decide(mode, action.kind())) {
                Decision.DENY -> return AgentResult(false, "السياسة تمنع: ${action.describe()}", n - 1)
                Decision.ASK_USER -> return AgentResult(false, "يحتاج موافقتك (غير مدعوم في الحلقة بعد): ${action.describe()}", n - 1)
                Decision.ALLOW -> Unit
            }

            val sig = action.describe()
            recent.add(sig)
            if (recent.size > 3) recent.removeAt(0)
            if (recent.size == 3 && recent.all { it == sig }) {
                return AgentResult(false, "تكرار الإجراء نفسه 3 مرات دون تقدم: $sig", n - 1)
            }

            log("خطوة $n: $sig — ${decision.reason}")
            val outcome = operator.perform(action.scaledToDevice(shot))
                .fold(onSuccess = { "performed" }, onFailure = { "error: ${it.message}" })
            if (outcome != "performed") log("   ↳ $outcome")
            history.add(StepRecord(n, sig, decision.reason, decision.expected, outcome))
            delay(settleMs)
        }
        return AgentResult(false, "بلغ الحد الأقصى للخطوات ($maxSteps)", maxSteps)
    }

    /** التقاط الشاشة محدود المعدل في أندرويد؛ نعيد المحاولة بعد انتظار قصير. */
    private suspend fun capture(): Screenshot? {
        repeat(3) {
            val r = operator.screenshot()
            if (r.isSuccess) return r.getOrNull()
            delay(1300)
        }
        return null
    }
}
