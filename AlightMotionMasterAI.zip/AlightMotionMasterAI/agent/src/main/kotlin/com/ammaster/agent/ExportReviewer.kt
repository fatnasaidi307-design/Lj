package com.ammaster.agent

import com.ammaster.core.FrameSource
import com.ammaster.core.MediaItem
import com.ammaster.core.Review
import com.ammaster.core.Reviewer
import com.ammaster.core.VideoPlan

data class ShotReview(val shotId: String, val timeMs: Long, val review: Review?, val error: String? = null)

data class ExportReviewResult(val durationNote: String?, val shots: List<ShotReview>) {
    val passed: Boolean get() = durationNote == null && shots.isNotEmpty() && shots.all { it.review?.passed == true }
}

/** مراجع مستقل: يأخذ لقطة من منتصف كل لقطة في الفيديو المُصدَّر ويقارنها بما خُطِّط لها. */
class ExportReviewer(private val reviewer: Reviewer, private val frames: FrameSource) {
    suspend fun review(plan: VideoPlan, video: MediaItem): ExportReviewResult {
        val assets = plan.assets.associateBy { it.id }
        val note = if (video.durationMs > 0 && kotlin.math.abs(video.durationMs - plan.totalDurationMs) > 1500) {
            "مدة الفيديو ${video.durationMs / 1000.0}ث تختلف عن المخطط ${plan.totalDurationMs / 1000.0}ث"
        } else {
            null
        }
        val results = mutableListOf<ShotReview>()
        for (shot in plan.scenes.flatMap { it.shots }.sortedBy { it.startMs }) {
            var t = shot.startMs + shot.durationMs / 2
            if (video.durationMs > 0) t = t.coerceAtMost(video.durationMs - 100).coerceAtLeast(0)
            val expected = buildString {
                assets[shot.assetId]?.let { append("The frame shows: ${it.description}. ") }
                if (shot.text.isNotBlank()) append("The text «${shot.text}» is clearly visible and readable. ")
                if (shot.effects.isNotEmpty()) append("Effects applied: ${shot.effects.joinToString { e -> e.name }}. ")
                if (isEmpty()) append("The frame is not black or empty.")
            }
            val fr = frames.frameAt(video.uri, t)
            if (fr.isFailure) {
                results.add(ShotReview(shot.id, t, null, "تعذّر استخراج اللقطة: ${fr.exceptionOrNull()?.message}"))
                continue
            }
            val r = reviewer.review(plan.title, expected, fr.getOrThrow())
            results.add(ShotReview(shot.id, t, r.getOrNull(), r.exceptionOrNull()?.message))
        }
        return ExportReviewResult(note, results)
    }
}
