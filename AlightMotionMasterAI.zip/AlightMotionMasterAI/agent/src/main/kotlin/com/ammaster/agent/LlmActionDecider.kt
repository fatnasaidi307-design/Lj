package com.ammaster.agent

import com.ammaster.core.ActionDecider
import com.ammaster.core.AgentDecision
import com.ammaster.core.AgentStatus
import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ImplStatus
import com.ammaster.core.JsonUtil
import com.ammaster.core.LlmClient
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Screenshot
import com.ammaster.core.StepRecord
import com.ammaster.core.UiAction
import com.ammaster.core.UiNode
import com.ammaster.core.str
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

internal fun describeNodes(nodes: List<UiNode>): String =
    if (nodes.isEmpty()) "(no UI tree available; rely on the screenshot)" else nodes.take(60).joinToString("\n") {
        "- ${it.type} text='${it.text}' desc='${it.desc}' ${if (it.clickable) "clickable " else ""}" +
            "bounds=(${it.left},${it.top},${it.right},${it.bottom})"
    }

class LlmActionDecider(private val llm: LlmClient) : ActionDecider {
    override val info = ModuleInfo(
        name = "AGENT DECIDER",
        status = ImplStatus.PARTIAL,
        summary = "يرى لقطة الشاشة وشجرة العناصر ويقرر إجراءً واحداً (نقر/سحب/كتابة/رجوع/انتظار/فتح التطبيق).",
        missing = listOf(
            "غير مختبر على هاتفك بعد؛ دقة تحديد الإحداثيات تعتمد على نموذج الرؤية",
            "مهارة واحدة فقط حالياً: إنشاء مشروع جديد",
        ),
    )

    override suspend fun decide(
        goal: String,
        knowledge: String,
        history: List<StepRecord>,
        shot: Screenshot,
        nodes: List<UiNode>,
    ): Result<AgentDecision> {
        val hist = if (history.isEmpty()) "(none)" else history.takeLast(8).joinToString("\n") {
            "${it.n}. ${it.action} — ${it.reason} | expected: ${it.expected} | outcome: ${it.outcome}"
        }
        val user = buildString {
            append("Goal: $goal\n\n")
            append("Screenshot size: ${shot.width}x${shot.height} pixels (all coordinates use this system).\n\n")
            append("Visible UI elements:\n${describeNodes(nodes)}\n\n")
            append("Previous steps:\n$hist\n\n")
            if (knowledge.isNotBlank()) append("Knowledge entries:\n$knowledge\n\n")
            append("Choose the single next action.")
        }
        return llm.chat(ChatRequest(listOf(ChatMessage("user", user, shot.jpegBase64)), SYSTEM, 600, 0.1))
            .mapCatching { parse(it.text) }
    }

    companion object {
        val SYSTEM: String = """
            You operate an Android phone to achieve a goal inside the Alight Motion app. You see ONE screenshot and
            a list of UI elements. Choose exactly ONE next action. Reply with JSON only:
            {"status":"continue|done|failed","action":"tap|long_press|swipe|type|back|wait|open_app",
             "x":0,"y":0,"x2":0,"y2":0,"durationMs":300,"text":"","package":"","waitMs":1000,
             "reason":"why this action","expected":"what should be visible after it"}
            Rules:
            - Coordinates are pixels in the screenshot. Prefer the center of a listed UI element whose text/desc matches; otherwise use only what you can clearly see. Never guess blindly.
            - Check the outcome of the previous step: if the screen did not change as expected, try a different approach instead of repeating.
            - status "done" only when the goal is visibly achieved in THIS screenshot. Use "failed" if you are stuck.
            - Never purchase, subscribe, sign in, grant permissions beyond what the goal needs, delete or overwrite anything, or share/publish. If the only way forward involves that, reply status "failed" and explain.
            - Alight Motion facts must come from the knowledge entries; otherwise rely only on what is visible.
        """.trimIndent()

        fun parse(text: String): AgentDecision {
            val json = JsonUtil.extractObject(text) ?: error("Decider reply has no JSON object")
            val root = Json.parseToJsonElement(json).jsonObject
            val reason = root.str("reason")
            val expected = root.str("expected")
            fun num(key: String): Int = root[key]?.jsonPrimitive?.doubleOrNull?.toInt() ?: error("missing '$key'")
            return when (root.str("status").lowercase()) {
                "done" -> AgentDecision(AgentStatus.DONE, null, reason, expected)
                "failed" -> AgentDecision(AgentStatus.FAILED, null, reason, expected)
                "continue" -> {
                    val action: UiAction = when (root.str("action").lowercase()) {
                        "tap" -> UiAction.Tap(num("x"), num("y"))
                        "long_press" -> UiAction.LongPress(num("x"), num("y"))
                        "swipe" -> UiAction.Swipe(
                            num("x"), num("y"), num("x2"), num("y2"),
                            (root["durationMs"]?.jsonPrimitive?.doubleOrNull?.toLong() ?: 300L).coerceIn(150L, 1500L),
                        )
                        "type" -> UiAction.TypeText(root.str("text").also { require(it.isNotEmpty()) { "empty text" } })
                        "back" -> UiAction.Back
                        "wait" -> UiAction.Wait((root["waitMs"]?.jsonPrimitive?.doubleOrNull?.toLong() ?: 1000L).coerceIn(200L, 10_000L))
                        "open_app" -> UiAction.OpenApp(root.str("package"))
                        else -> error("unknown action")
                    }
                    AgentDecision(AgentStatus.CONTINUE, action, reason, expected)
                }
                else -> error("unknown status")
            }
        }
    }
}
