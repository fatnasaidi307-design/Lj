package com.ammaster.agent

import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.GoalVerifier
import com.ammaster.core.ImplStatus
import com.ammaster.core.JsonUtil
import com.ammaster.core.LlmClient
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Screenshot
import com.ammaster.core.UiNode
import com.ammaster.core.VerifyResult
import com.ammaster.core.str
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject

class LlmGoalVerifier(private val llm: LlmClient) : GoalVerifier {
    override val info = ModuleInfo(
        name = "GOAL VERIFIER",
        status = ImplStatus.PARTIAL,
        summary = "مدقّق مستقل: يقرر من لقطة الشاشة وحدها هل تحقق الهدف فعلاً.",
        missing = listOf("يعتمد على لقطة ثابتة؛ لا يتحقق من الحركة أو التصدير بعد"),
    )

    override suspend fun verify(goal: String, shot: Screenshot, nodes: List<UiNode>): Result<VerifyResult> {
        val user = "Goal: $goal\n\nVisible UI elements:\n${describeNodes(nodes)}\n\nIs the goal achieved in this screenshot?"
        return llm.chat(ChatRequest(listOf(ChatMessage("user", user, shot.jpegBase64)), SYSTEM, 300, 0.0))
            .mapCatching { parse(it.text) }
    }

    companion object {
        const val SYSTEM = "You are a skeptical verifier. Decide only from the screenshot and UI list whether the goal is " +
            "visibly achieved right now. Reply with JSON only: {\"achieved\":true|false,\"evidence\":\"what you see\"}. " +
            "If there is any doubt, answer false."

        fun parse(text: String): VerifyResult {
            val json = JsonUtil.extractObject(text) ?: error("Verifier reply has no JSON object")
            val root = Json.parseToJsonElement(json).jsonObject
            val achieved = root.str("achieved").trim().lowercase() == "true"
            return VerifyResult(achieved, root.str("evidence"))
        }
    }
}
