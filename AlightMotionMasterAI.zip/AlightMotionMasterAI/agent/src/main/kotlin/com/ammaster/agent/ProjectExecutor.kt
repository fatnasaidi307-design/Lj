package com.ammaster.agent

import com.ammaster.core.ActionDecider
import com.ammaster.core.AssetStatus
import com.ammaster.core.Failure
import com.ammaster.core.GoalVerifier
import com.ammaster.core.MediaCatalog
import com.ammaster.core.MediaItem
import com.ammaster.core.MemoryStore
import com.ammaster.core.Operator
import com.ammaster.core.PlanStep
import com.ammaster.core.Recovery
import com.ammaster.core.RecoveryDecision
import com.ammaster.core.RunMode
import com.ammaster.core.RunState
import com.ammaster.core.RunStatus
import com.ammaster.core.UiAction
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/**
 * ينفّذ المشروع كاملاً داخل Alight Motion: تجهيز المواد ← خطوات بأهداف نصية (كل خطوة بحلقة وكيل ومدقق) ←
 * إعادة محاولة بقرار RECOVERY ← تصدير مع تحقق فعلي من ظهور ملف فيديو جديد. تُحفظ الحالة بعد كل خطوة للاستئناف.
 */
class ProjectExecutor(
    private val operator: Operator,
    private val decider: ActionDecider,
    private val verifier: GoalVerifier,
    private val recovery: Recovery,
    private val memory: MemoryStore,
    private val catalog: MediaCatalog,
    private val maxStepsPerGoal: Int = 20,
    private val settleMs: Long = 1500,
    private val maxRecoveries: Int = 2,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val log: (String) -> Unit = {},
) {
    suspend fun execute(initial: RunState, onState: suspend (RunState) -> Unit): RunState {
        var state = initial
        suspend fun update(next: RunState) {
            state = next.copy(updatedAt = clock())
            onState(state)
        }

        val plan = state.plan
        if (plan == null) {
            update(state.copy(status = RunStatus.FAILED, log = state.log + "no plan to execute"))
            return state
        }
        if (state.mode == RunMode.PLAN_ONLY) {
            update(state.copy(log = state.log + "plan-only mode: nothing executed"))
            return state
        }
        if (plan.assets.any { it.status == AssetStatus.MISSING || it.status == AssetStatus.UNRESOLVED }) {
            update(state.copy(status = RunStatus.WAITING_ASSETS, log = state.log + "assets still missing: execution not started"))
            return state
        }

        // 1) تجهيز المواد: نسخ إلى ألبوم المشروع (الأصول لا تُمس)
        var staged = plan.assets
        for ((i, a) in plan.assets.withIndex()) {
            if (a.uri.isBlank() || a.stagedUri.isNotBlank()) continue
            val item = catalog.describe(a.uri) ?: MediaItem(a.uri, a.kind, "media")
            val r = catalog.stage(state.runId, i + 1, item)
            if (r.isFailure) {
                update(state.copy(status = RunStatus.PAUSED, log = state.log + "staging failed for ${a.id}: ${r.exceptionOrNull()?.message}"))
                return state
            }
            val uri = r.getOrThrow()
            staged = staged.map { if (it.id == a.id) it.copy(stagedUri = uri) else it }
        }
        update(state.copy(plan = plan.copy(assets = staged), status = RunStatus.RUNNING, log = state.log + "assets staged"))

        // 2) الخطوات
        val album = state.runId.take(8)
        val steps = StepPlanner.build(plan, album)
        val resumeAt = state.stepIndex.coerceIn(0, steps.size)
        var i = resumeAt
        var exportedFound = false
        while (i < steps.size) {
            currentCoroutineContext().ensureActive()
            val step = steps[i]
            log("▶ ${step.title} (${i + 1}/${steps.size})")
            val startedAt = clock()
            val (ok, msg) = runStep(step, state.mode, openApp = i == resumeAt)

            if (step.kind == StepKind.EXPORT) {
                val vids = catalog.newVideosSince(startedAt)
                if (vids.isNotEmpty()) {
                    val v = vids.first()
                    exportedFound = true
                    update(state.copy(stepIndex = i + 1, log = state.log + "EXPORT:${v.uri}|${v.name}|${v.durationMs}"))
                    i++
                    continue
                }
            }
            if (ok) {
                update(state.copy(stepIndex = i + 1, log = state.log + "✔ ${step.title}"))
                i++
            } else if (step.optional) {
                log("تخطي خطوة اختيارية فشلت: ${step.title}")
                update(state.copy(stepIndex = i + 1, log = state.log + "skipped (optional): ${step.title}: $msg"))
                i++
            } else {
                update(state.copy(status = RunStatus.PAUSED, stepIndex = i, log = state.log + "paused at '${step.title}': $msg"))
                return state
            }
        }
        if (exportedFound || RunLogicExport.hasExport(state)) {
            update(state.copy(status = RunStatus.DONE, log = state.log + "done"))
        } else {
            update(state.copy(status = RunStatus.PAUSED, log = state.log + "لم يظهر فيديو مُصدَّر جديد في المعرض؛ تحقق من التصدير يدوياً"))
        }
        return state
    }

    private suspend fun runStep(step: ExecStep, mode: RunMode, openApp: Boolean): Pair<Boolean, String> {
        var goal = step.goal
        var lastMsg = ""
        val kb = kbText(step.kbQuery.ifBlank { step.title })
        for (attempt in 0..maxRecoveries) {
            val loop = AgentLoop(operator, decider, verifier, maxStepsPerGoal, settleMs, log = log)
            val initialActions = if (openApp && attempt == 0) listOf<UiAction>(UiAction.OpenApp("com.alightcreative.motion")) else emptyList()
            val res = loop.run(goal, mode, kb, initialActions)
            if (res.success) return true to res.message
            lastMsg = res.message
            if (attempt == maxRecoveries) break
            val decision = recovery.decide(Failure(PlanStep(step.title, "", goal), res.message, attempt + 1), memory.searchKnowledge(step.title, 3))
                .getOrNull() ?: break
            when (decision) {
                is RecoveryDecision.Retry -> goal = step.goal + "\nAdjustment: " + decision.adjustedDetails
                is RecoveryDecision.Alternative -> goal = decision.newStep.details.ifBlank { decision.newStep.title }
                is RecoveryDecision.GiveUp -> break
            }
        }
        return false to lastMsg
    }

    private suspend fun kbText(query: String): String =
        memory.searchKnowledge(query, 4).joinToString("\n") { "- [${it.entry.status}] ${it.entry.title}: ${it.entry.body}" }
}

internal object RunLogicExport {
    fun hasExport(state: RunState): Boolean = state.log.any { it.startsWith("EXPORT:") }
}
