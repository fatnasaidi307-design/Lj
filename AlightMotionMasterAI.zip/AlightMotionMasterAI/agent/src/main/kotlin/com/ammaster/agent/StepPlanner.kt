package com.ammaster.agent

import com.ammaster.core.MediaKind
import com.ammaster.core.VideoPlan

enum class StepKind { CREATE, IMPORT, TEXT, EFFECT, TRANSITION, EXPORT }

/** خطوة تنفيذية بهدف نصي دقيق يُسلَّم لحلقة الوكيل. الاختيارية لا توقف المشروع إن فشلت. */
data class ExecStep(
    val id: String,
    val kind: StepKind,
    val title: String,
    val goal: String,
    val kbQuery: String = "",
    val optional: Boolean = false,
)

object StepPlanner {
    private fun sec(ms: Long): String = "%.1f".format(ms / 1000.0)

    fun build(plan: VideoPlan, album: String): List<ExecStep> {
        val steps = mutableListOf<ExecStep>()
        steps.add(
            ExecStep(
                "create", StepKind.CREATE, "إنشاء المشروع",
                "Create a new project in Alight Motion. In the new-project dialog choose aspect ratio ${plan.aspectRatio} " +
                    "(or the closest preset) and ${plan.fps} fps, keep the other defaults, and confirm. Never purchase or subscribe. " +
                    "Done only when the editor of the NEW project (timeline and tools) is visible.",
                "إنشاء مشروع جديد project settings",
            ),
        )
        val assets = plan.assets.associateBy { it.id }
        val shots = plan.scenes.flatMap { it.shots }.sortedBy { it.startMs }
        for (shot in shots) {
            val asset = assets[shot.assetId]
            if (asset != null) {
                val word = if (asset.kind == MediaKind.VIDEO) "video" else "image"
                steps.add(
                    ExecStep(
                        "import-${shot.id}", StepKind.IMPORT, "استيراد مادة اللقطة ${shot.id}",
                        "In the open project editor, add a $word: tap the add/plus button, choose to add a $word from the gallery, " +
                            "open the album named '$album', select the thumbnail that clearly shows: ${asset.description}, and confirm so it " +
                            "becomes a layer. Then make that layer start at ${sec(shot.startMs)}s on the timeline and last ${sec(shot.durationMs)}s " +
                            "(drag or trim the layer edges, or use the layer timing controls). Done when a new media layer with that content " +
                            "is visible on the timeline at roughly that position.",
                        "import media layer timeline",
                    ),
                )
            }
            if (shot.text.isNotBlank()) {
                steps.add(
                    ExecStep(
                        "text-${shot.id}", StepKind.TEXT, "إضافة نص اللقطة ${shot.id}",
                        "Add a text layer whose content is exactly: «${shot.text}» (type it exactly as written, including Arabic letters). " +
                            "Make the text layer start at ${sec(shot.startMs)}s and last ${sec(shot.durationMs)}s. " +
                            "Done when a text layer with exactly that text is visible on the canvas or timeline.",
                        "text layer نص",
                    ),
                )
            }
            for ((i, e) in shot.effects.withIndex()) {
                val params = if (e.params.isEmpty()) "" else " with settings " + e.params.entries.joinToString { "${it.key}=${it.value}" }
                steps.add(
                    ExecStep(
                        "fx-${shot.id}-$i", StepKind.EFFECT, "تأثير ${e.name}",
                        "Apply the effect '${e.name}'$params to the layer of shot ${shot.id} (the layer at ${sec(shot.startMs)}s). " +
                            "Done when the effect is visibly listed on that layer or visible in the preview.",
                        e.name + " " + e.kbKey,
                        optional = true,
                    ),
                )
            }
            shot.transition?.takeIf { it.name.isNotBlank() }?.let { t ->
                steps.add(
                    ExecStep(
                        "tr-${shot.id}", StepKind.TRANSITION, "انتقال ${t.name}",
                        "Add the transition '${t.name}' (about ${sec(t.durationMs)}s) at the end of the layer of shot ${shot.id}. " +
                            "Done when the transition is visible on that layer.",
                        t.name + " " + t.kbKey,
                        optional = true,
                    ),
                )
            }
        }
        steps.add(
            ExecStep(
                "export", StepKind.EXPORT, "تصدير الفيديو",
                "Export the project as a video: tap the export/share button, choose video export with the best quality available " +
                    "without any purchase, confirm, and wait until the export finishes. Done when the export-complete or saved confirmation is visible.",
                "export تصدير",
            ),
        )
        return steps
    }
}
