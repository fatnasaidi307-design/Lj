package com.ammaster.agent

import com.ammaster.core.ActionDecider
import com.ammaster.core.AgentDecision
import com.ammaster.core.AgentStatus
import com.ammaster.core.GoalVerifier
import com.ammaster.core.ImplStatus
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Operator
import com.ammaster.core.RunMode
import com.ammaster.core.Screenshot
import com.ammaster.core.StepRecord
import com.ammaster.core.UiAction
import com.ammaster.core.UiNode
import com.ammaster.core.VerifyResult
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class AgentTest {
    private val info = ModuleInfo("fake", ImplStatus.PARTIAL, "fake")
    private val shot = Screenshot("b", 100, 200, 1000, 2000)

    private class FakeOp(private val ready: Boolean = true) : Operator {
        override val info = ModuleInfo("OP", ImplStatus.PARTIAL, "fake")
        val performed = mutableListOf<UiAction>()
        override suspend fun isReady() = ready
        override suspend fun screenshot() = Result.success(Screenshot("b", 100, 200, 1000, 2000))
        override suspend fun uiNodes() = listOf(UiNode("New project", "", true, 100, 200, 300, 400))
        override suspend fun perform(action: UiAction): Result<Unit> {
            performed.add(action)
            return Result.success(Unit)
        }
    }

    private inner class Scripted(private val decisions: List<AgentDecision>) : ActionDecider {
        override val info = this@AgentTest.info
        var calls = 0
        val histories = mutableListOf<List<StepRecord>>()
        override suspend fun decide(
            goal: String, knowledge: String, history: List<StepRecord>, shot: Screenshot, nodes: List<UiNode>,
        ): Result<AgentDecision> {
            histories.add(history.toList())
            return Result.success(decisions[minOf(calls++, decisions.size - 1)])
        }
    }

    private inner class Verifier(private val answers: List<Boolean>) : GoalVerifier {
        override val info = this@AgentTest.info
        var calls = 0
        override suspend fun verify(goal: String, shot: Screenshot, nodes: List<UiNode>): Result<VerifyResult> =
            Result.success(VerifyResult(answers[minOf(calls++, answers.size - 1)], "evidence"))
    }

    private fun cont(a: UiAction) = AgentDecision(AgentStatus.CONTINUE, a, "r", "e")
    private val done = AgentDecision(AgentStatus.DONE, null, "looks done", "")

    private fun loop(op: Operator, d: ActionDecider, v: GoalVerifier, max: Int = 5) =
        AgentLoop(op, d, v, maxSteps = max, settleMs = 0)

    @Test
    fun succeedsAfterVerifiedDoneAndScalesCoordinates() = runBlocking {
        val op = FakeOp()
        val r = loop(op, Scripted(listOf(cont(UiAction.Tap(10, 20)), done)), Verifier(listOf(true)))
            .run("goal", RunMode.ASSISTED)
        assertTrue(r.success)
        assertEquals(listOf<UiAction>(UiAction.Tap(100, 200)), op.performed)
    }

    @Test
    fun planOnlyAndNotReadyNeverPerform() = runBlocking {
        val op = FakeOp()
        assertFalse(loop(op, Scripted(listOf(done)), Verifier(listOf(true))).run("g", RunMode.PLAN_ONLY).success)
        val off = FakeOp(ready = false)
        assertFalse(loop(off, Scripted(listOf(done)), Verifier(listOf(true))).run("g", RunMode.ASSISTED).success)
        assertTrue(op.performed.isEmpty() && off.performed.isEmpty())
    }

    @Test
    fun rejectedDoneClaimKeepsGoingAndIsInHistory() = runBlocking {
        val d = Scripted(listOf(done, cont(UiAction.Tap(1, 1)), done))
        val r = loop(FakeOp(), d, Verifier(listOf(false, true))).run("g", RunMode.ASSISTED)
        assertTrue(r.success)
        assertTrue(d.histories[1].any { it.outcome.startsWith("verification rejected") })
    }

    @Test
    fun repeatedSameActionIsStuck() = runBlocking {
        val r = loop(FakeOp(), Scripted(listOf(cont(UiAction.Tap(5, 5)))), Verifier(listOf(true)), max = 10)
            .run("g", RunMode.ASSISTED)
        assertFalse(r.success)
        assertTrue(r.message.contains("3"))
    }

    @Test
    fun stopsAtMaxSteps() = runBlocking {
        val d = Scripted((1..10).map { cont(UiAction.Tap(it, it)) })
        val r = loop(FakeOp(), d, Verifier(listOf(true)), max = 3).run("g", RunMode.ASSISTED)
        assertFalse(r.success)
        assertEquals(3, r.steps)
    }

    @Test
    fun blocksOtherApps() = runBlocking {
        val op = FakeOp()
        val d = Scripted(listOf(cont(UiAction.OpenApp("com.bank.app")), AgentDecision(AgentStatus.FAILED, null, "stop", "")))
        val r = loop(op, d, Verifier(listOf(true))).run("g", RunMode.ASSISTED)
        assertFalse(r.success)
        assertTrue(op.performed.isEmpty())
        assertTrue(d.histories[1].any { it.outcome.contains("not allowed") })
    }

    @Test
    fun initialActionsRunFirst() = runBlocking {
        val op = FakeOp()
        loop(op, Scripted(listOf(done)), Verifier(listOf(true)))
            .run("g", RunMode.ASSISTED, initialActions = listOf(UiAction.OpenApp("com.alightcreative.motion")))
        assertEquals(UiAction.OpenApp("com.alightcreative.motion"), op.performed.first())
    }

    @Test
    fun parsesDeciderReplies() {
        val tap = LlmActionDecider.parse("```json\n{\"status\":\"continue\",\"action\":\"tap\",\"x\":120.5,\"y\":300,\"reason\":\"r\",\"expected\":\"e\"}\n```")
        assertEquals(UiAction.Tap(120, 300), tap.action)
        assertEquals(AgentStatus.DONE, LlmActionDecider.parse("{\"status\":\"done\",\"reason\":\"x\"}").status)
        assertEquals(UiAction.Wait(10000), LlmActionDecider.parse("{\"status\":\"continue\",\"action\":\"wait\",\"waitMs\":99999}").action)
        assertEquals(UiAction.Back, LlmActionDecider.parse("{\"status\":\"continue\",\"action\":\"back\"}").action)
        assertFailsWith<IllegalStateException> { LlmActionDecider.parse("{\"status\":\"continue\",\"action\":\"tap\",\"x\":1}") }
        assertFailsWith<IllegalStateException> { LlmActionDecider.parse("{\"status\":\"continue\",\"action\":\"fly\"}") }
    }

    @Test
    fun parsesVerifierReplies() {
        assertTrue(LlmGoalVerifier.parse("{\"achieved\":true,\"evidence\":\"timeline visible\"}").achieved)
        assertFalse(LlmGoalVerifier.parse("{\"achieved\":\"maybe\"}").achieved)
    }
}
