package com.ammaster.agent

import com.ammaster.core.ActionDecider
import com.ammaster.core.AgentDecision
import com.ammaster.core.AgentStatus
import com.ammaster.core.AssetRequest
import com.ammaster.core.AssetStatus
import com.ammaster.core.EffectSpec
import com.ammaster.core.Experience
import com.ammaster.core.Failure
import com.ammaster.core.FrameSource
import com.ammaster.core.GoalVerifier
import com.ammaster.core.ImplStatus
import com.ammaster.core.KnowledgeEntry
import com.ammaster.core.KnowledgeHit
import com.ammaster.core.MediaCatalog
import com.ammaster.core.MediaItem
import com.ammaster.core.MediaKind
import com.ammaster.core.MemoryStore
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Operator
import com.ammaster.core.Recovery
import com.ammaster.core.RecoveryDecision
import com.ammaster.core.Review
import com.ammaster.core.Reviewer
import com.ammaster.core.RunLogic
import com.ammaster.core.RunMode
import com.ammaster.core.RunState
import com.ammaster.core.RunStatus
import com.ammaster.core.Scene
import com.ammaster.core.Screenshot
import com.ammaster.core.Shot
import com.ammaster.core.StepRecord
import com.ammaster.core.UiAction
import com.ammaster.core.UiNode
import com.ammaster.core.VerifyResult
import com.ammaster.core.VideoPlan
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ExecutorTest {
    private val info = ModuleInfo("fake", ImplStatus.PARTIAL, "fake")

    private class Op : Operator {
        override val info = ModuleInfo("OP", ImplStatus.PARTIAL, "fake")
        val performed = mutableListOf<UiAction>()
        override suspend fun isReady() = true
        override suspend fun screenshot() = Result.success(Screenshot("b", 100, 200, 100, 200))
        override suspend fun uiNodes() = emptyList<UiNode>()
        override suspend fun perform(action: UiAction): Result<Unit> { performed.add(action); return Result.success(Unit) }
    }

    private inner class AlwaysDone : ActionDecider {
        override val info = this@ExecutorTest.info
        override suspend fun decide(goal: String, knowledge: String, history: List<StepRecord>, shot: Screenshot, nodes: List<UiNode>) =
            Result.success(AgentDecision(AgentStatus.DONE, null, "done", ""))
    }

    private inner class Verifier(val rejectWhen: (String) -> Boolean = { false }) : GoalVerifier {
        override val info = this@ExecutorTest.info
        val goals = mutableListOf<String>()
        override suspend fun verify(goal: String, shot: Screenshot, nodes: List<UiNode>): Result<VerifyResult> {
            goals.add(goal)
            return Result.success(VerifyResult(!rejectWhen(goal), "e"))
        }
    }

    private inner class GiveUpRecovery : Recovery {
        override val info = this@ExecutorTest.info
        override suspend fun decide(failure: Failure, knowledge: List<KnowledgeHit>) =
            Result.success<RecoveryDecision>(RecoveryDecision.GiveUp("no"))
    }

    private class Mem : MemoryStore {
        override val info = ModuleInfo("M", ImplStatus.PARTIAL, "fake")
        override suspend fun searchKnowledge(query: String, limit: Int) = emptyList<KnowledgeHit>()
        override suspend fun listKnowledge(limit: Int) = emptyList<KnowledgeEntry>()
        override suspend fun upsertKnowledge(entry: KnowledgeEntry) {}
        override suspend fun knowledgeCount() = 0
        override suspend fun saveExperience(experience: Experience) = 1L
        override suspend fun recentExperiences(limit: Int) = emptyList<Experience>()
    }

    private class Cat(var exported: List<MediaItem>) : MediaCatalog {
        val staged = mutableListOf<String>()
        override suspend fun scan() = emptyList<MediaItem>()
        override suspend fun newVideosSince(sinceMs: Long) = exported
        override suspend fun describe(uri: String): MediaItem? = MediaItem(uri, MediaKind.IMAGE, "pic.jpg")
        override suspend fun stage(runId: String, ordinal: Int, item: MediaItem): Result<String> {
            staged.add("$runId/$ordinal/${item.name}")
            return Result.success("content://staged/$ordinal")
        }
    }

    private val video = MediaItem("content://v/1", MediaKind.VIDEO, "out.mp4", durationMs = 5000)

    private fun plan(status: AssetStatus = AssetStatus.FOUND_LOCAL) = VideoPlan(
        "t", totalDurationMs = 5000,
        scenes = listOf(Scene("s", "t", listOf(Shot("sh1", 0, 5000, assetId = "a1", text = "مرحبا", effects = listOf(EffectSpec("Blur")))))),
        assets = listOf(AssetRequest("a1", description = "قرية", status = status, uri = if (status == AssetStatus.MISSING) "" else "content://src/1")),
    )

    private fun state(plan: VideoPlan, step: Int = 0) =
        RunState("run12345678", "g", RunMode.ASSISTED, plan, status = RunStatus.READY, stepIndex = step, updatedAt = 0)

    private fun executor(op: Op, v: Verifier, cat: Cat) = ProjectExecutor(
        op, AlwaysDone(), v, GiveUpRecovery(), Mem(), cat, maxStepsPerGoal = 2, settleMs = 0, maxRecoveries = 1,
    )

    @Test
    fun stepPlannerBuildsOrderedStepsWithOptionalEffects() {
        val steps = StepPlanner.build(plan(), "alb")
        assertEquals(listOf(StepKind.CREATE, StepKind.IMPORT, StepKind.TEXT, StepKind.EFFECT, StepKind.EXPORT), steps.map { it.kind })
        assertTrue(steps[1].goal.contains("album named 'alb'"))
        assertTrue(steps[2].goal.contains("«مرحبا»"))
        assertTrue(steps.first { it.kind == StepKind.EFFECT }.optional)
        assertFalse(steps.first { it.kind == StepKind.TEXT }.optional)
    }

    @Test
    fun fullRunStagesAssetsExecutesAndVerifiesExport() = runBlocking {
        val cat = Cat(listOf(video))
        val saved = mutableListOf<RunState>()
        val end = executor(Op(), Verifier(), cat).execute(state(plan())) { saved.add(it) }
        assertEquals(RunStatus.DONE, end.status)
        assertEquals(5, end.stepIndex)
        assertEquals("content://v/1", RunLogic.exportedUri(end))
        assertEquals("content://staged/1", end.plan!!.assets[0].stagedUri)
        assertEquals(1, cat.staged.size)
        assertTrue(saved.size >= 6)
    }

    @Test
    fun requiredStepFailurePausesAtThatStep() = runBlocking {
        val end = executor(Op(), Verifier { it.contains("Add a text layer") }, Cat(listOf(video))).execute(state(plan())) {}
        assertEquals(RunStatus.PAUSED, end.status)
        assertEquals(2, end.stepIndex)
    }

    @Test
    fun optionalEffectFailureIsSkipped() = runBlocking {
        val end = executor(Op(), Verifier { it.contains("Apply the effect") }, Cat(listOf(video))).execute(state(plan())) {}
        assertEquals(RunStatus.DONE, end.status)
        assertTrue(end.log.any { it.startsWith("skipped (optional)") })
    }

    @Test
    fun claimedExportWithoutNewVideoIsNotDone() = runBlocking {
        val end = executor(Op(), Verifier(), Cat(emptyList())).execute(state(plan())) {}
        assertEquals(RunStatus.PAUSED, end.status)
        assertEquals(null, RunLogic.exportedUri(end))
    }

    @Test
    fun missingAssetsBlockExecution() = runBlocking {
        val op = Op()
        val end = executor(op, Verifier(), Cat(listOf(video))).execute(state(plan(AssetStatus.MISSING))) {}
        assertEquals(RunStatus.WAITING_ASSETS, end.status)
        assertTrue(op.performed.isEmpty())
    }

    @Test
    fun resumeSkipsFinishedStepsAndReopensTheApp() = runBlocking {
        val op = Op()
        val v = Verifier()
        val end = executor(op, v, Cat(listOf(video))).execute(state(plan(), step = 3)) {}
        assertEquals(RunStatus.DONE, end.status)
        assertTrue(v.goals.none { it.contains("Create a new project") })
        assertEquals(UiAction.OpenApp("com.alightcreative.motion"), op.performed.first())
    }

    @Test
    fun exportReviewerComparesMidShotFramesAndDuration() = runBlocking {
        val frames = object : FrameSource {
            val times = mutableListOf<Long>()
            override suspend fun frameAt(videoUri: String, timeMs: Long): Result<Screenshot> {
                times.add(timeMs)
                return Result.success(Screenshot("b", 10, 10))
            }
        }
        var expectedSeen = ""
        val reviewer = object : Reviewer {
            override val info = this@ExecutorTest.info
            override suspend fun review(goal: String, expected: String, shot: Screenshot): Result<Review> {
                expectedSeen = expected
                return Result.success(Review(90, true, emptyList(), emptyList()))
            }
        }
        val res = ExportReviewer(reviewer, frames).review(plan(), video.copy(durationMs = 9000))
        assertEquals(listOf(2500L), frames.times)
        assertTrue(expectedSeen.contains("قرية") && expectedSeen.contains("مرحبا"))
        assertTrue(res.durationNote != null)
        assertFalse(res.passed)
        assertTrue(ExportReviewer(reviewer, frames).review(plan(), video).passed)
    }
}
