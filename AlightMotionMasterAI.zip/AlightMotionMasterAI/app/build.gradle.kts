plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ammaster.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ammaster.alightmotionai"
        minSdk = 30
        targetSdk = 34
        versionCode = 4
        versionName = "0.4.0-full"
    }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(project(":core"))
    implementation(project(":llm"))
    implementation(project(":memory"))
    implementation(project(":brain"))
    implementation(project(":planner"))
    implementation(project(":vision"))
    implementation(project(":operator"))
    implementation(project(":reviewer"))
    implementation(project(":recovery"))
    implementation(project(":agent"))
    implementation(project(":assets"))

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
