package com.ammaster.app

import android.app.Application
import com.ammaster.agent.ExportReviewer
import com.ammaster.agent.LlmActionDecider
import com.ammaster.agent.LlmGoalVerifier
import com.ammaster.assets.MediaStoreCatalog
import com.ammaster.assets.MlKitLabeler
import com.ammaster.assets.VideoFrameSource
import com.ammaster.brain.AssetIndexer
import com.ammaster.brain.AssetResolver
import com.ammaster.brain.ExpertBrain
import com.ammaster.brain.LlmKeywordExpander
import com.ammaster.brain.RunManager
import com.ammaster.core.Operator
import com.ammaster.llm.SettingsLlmClient
import com.ammaster.memory.MemoryDb
import com.ammaster.memory.PrefsProviderStore
import com.ammaster.memory.SqliteAssetIndex
import com.ammaster.memory.SqliteRunStore
import com.ammaster.memory.SqliteMemoryStore
import com.ammaster.operator.AccessibilityOperator
import com.ammaster.planner.LlmPlanner
import com.ammaster.planner.LlmVideoPlanner
import com.ammaster.recovery.LlmRecovery
import com.ammaster.reviewer.LlmReviewer
import com.ammaster.vision.LlmVision
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async

class App : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/** تجميع الوحدات. كل وحدة تتعامل مع الباقي عبر عقود :core فقط. */
class AppContainer(app: Application) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val providers = PrefsProviderStore(app)
    private val db = MemoryDb(app)
    val memory = SqliteMemoryStore(app, db)
    private val runStore = SqliteRunStore(db)
    val operator: Operator = AccessibilityOperator()

    private val llm = SettingsLlmClient(providers)
    val brain = ExpertBrain(llm, memory)
    val planner = LlmPlanner(llm)
    val videoPlanner = LlmVideoPlanner(llm)
    val runManager = RunManager(videoPlanner, memory, runStore)
    val vision = LlmVision(llm)
    val reviewer = LlmReviewer(llm)
    val recovery = LlmRecovery(llm)
    val actionDecider = LlmActionDecider(llm)
    val goalVerifier = LlmGoalVerifier(llm)

    val catalog = MediaStoreCatalog(app)
    val assetIndex = SqliteAssetIndex(db)
    val indexer = AssetIndexer(catalog, MlKitLabeler(app), assetIndex)
    private val expander = LlmKeywordExpander(llm)
    val resolver = AssetResolver(assetIndex) { expander.expand(it) }
    val exportReviewer = ExportReviewer(reviewer, VideoFrameSource(app))

    @Volatile
    var seedError: String? = null
        private set

    private val seedJob: Deferred<Unit> = scope.async {
        try {
            memory.seedIfNeeded()
        } catch (t: Throwable) {
            seedError = t.message ?: t.javaClass.simpleName
        }
        Unit
    }

    suspend fun awaitReady() {
        seedJob.await()
    }
}
