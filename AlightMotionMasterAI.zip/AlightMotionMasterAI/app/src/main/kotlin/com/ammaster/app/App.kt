package com.ammaster.app

import android.app.Application
import com.ammaster.brain.ExpertBrain
import com.ammaster.core.Operator
import com.ammaster.llm.SettingsLlmClient
import com.ammaster.memory.PrefsProviderStore
import com.ammaster.memory.SqliteMemoryStore
import com.ammaster.operator.AccessibilityOperator
import com.ammaster.planner.LlmPlanner
import com.ammaster.recovery.LlmRecovery
import com.ammaster.reviewer.LlmReviewer
import com.ammaster.vision.LlmVision
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async

class App : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/** تجميع الوحدات. كل وحدة تتعامل مع الباقي عبر عقود :core فقط. */
class AppContainer(app: Application) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val providers = PrefsProviderStore(app)
    val memory = SqliteMemoryStore(app)
    val operator: Operator = AccessibilityOperator()

    private val llm = SettingsLlmClient(providers)
    val brain = ExpertBrain(llm, memory)
    val planner = LlmPlanner(llm)
    val vision = LlmVision(llm)
    val reviewer = LlmReviewer(llm)
    val recovery = LlmRecovery(llm)

    @Volatile
    var seedError: String? = null
        private set

    private val seedJob: Deferred<Unit> = scope.async {
        try {
            memory.seedIfNeeded()
        } catch (t: Throwable) {
            seedError = t.message ?: t.javaClass.simpleName
        }
        Unit
    }

    suspend fun awaitReady() {
        seedJob.await()
    }
}
