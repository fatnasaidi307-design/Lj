package com.ammaster.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ChatScreen(vm: MainViewModel) {
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (vm.messages.isEmpty()) {
                item {
                    Text(
                        "اسأل عن أي أداة أو تقنية في Alight Motion. الإجابات مبنية على الموسوعة المحلية، وما لم يُتحقق منه يُعلَّم بذلك. تغطية الموسوعة أولية حالياً (Easing وParenting وNull Objects).",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            items(vm.messages) { m ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(if (m.fromUser) "أنت" else "الخبير", style = MaterialTheme.typography.labelMedium)
                        Text(m.text)
                        if (m.sources.isNotEmpty()) {
                            Text(
                                "المصادر: " + m.sources.joinToString("، "),
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }
            if (vm.chatBusy) item { Text("…يفكّر") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب سؤالك") },
                maxLines = 4,
            )
            Spacer(Modifier.width(8.dp))
            Button(
                enabled = input.isNotBlank() && !vm.chatBusy,
                onClick = {
                    vm.ask(input)
                    input = ""
                },
            ) { Text("إرسال") }
        }
    }
}
