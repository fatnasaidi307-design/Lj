package com.ammaster.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ammaster.core.KnowledgeStatus

@Composable
fun KnowledgeScreen(vm: MainViewModel) {
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.search("") }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("موسوعة Alight Motion (${vm.kbCount} إدخالاً)", style = MaterialTheme.typography.titleLarge) }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    vm.search(it)
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ابحث (عربي أو English)") },
                singleLine = true,
            )
        }
        if (vm.kbResults.isEmpty()) item { Text("لا توجد نتائج.") }
        items(vm.kbResults, key = { it.key }) { e ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(e.title, style = MaterialTheme.typography.titleSmall)
                    Text(
                        if (e.status == KnowledgeStatus.VERIFIED) "✔ موثّق من مصدر رسمي (${e.verifiedAt})" else "⚠ غير مؤكد",
                        style = MaterialTheme.typography.labelMedium,
                    )
                    Text(e.body, style = MaterialTheme.typography.bodyMedium)
                    if (e.sourceUrl.isNotBlank()) Text(e.sourceUrl, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
