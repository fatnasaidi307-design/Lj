package com.ammaster.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ammaster.agent.AgentLoop
import com.ammaster.agent.ExportReviewResult
import com.ammaster.agent.ProjectExecutor
import com.ammaster.core.ApiProvider
import com.ammaster.core.ImplStatus
import com.ammaster.core.KnowledgeEntry
import com.ammaster.core.MediaItem
import com.ammaster.core.MediaKind
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Plan
import com.ammaster.core.RunMode
import com.ammaster.core.RunState
import com.ammaster.core.RunStatus
import com.ammaster.core.UiAction
import com.ammaster.core.ProviderSettings
import com.ammaster.llm.ConnectionTestResult
import com.ammaster.llm.testConnection
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

data class UiMessage(val fromUser: Boolean, val text: String, val sources: List<String> = emptyList())

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as App).container

    var messages by mutableStateOf<List<UiMessage>>(emptyList())
        private set
    var chatBusy by mutableStateOf(false)
        private set

    var plan by mutableStateOf<Plan?>(null)
        private set
    var planStatus by mutableStateOf<String?>(null)
        private set
    var planBusy by mutableStateOf(false)
        private set

    var run by mutableStateOf<RunState?>(null)
        private set
    var runBusy by mutableStateOf(false)
        private set
    var runError by mutableStateOf<String?>(null)
        private set

    var kbResults by mutableStateOf<List<KnowledgeEntry>>(emptyList())
        private set
    var kbCount by mutableStateOf(0)
        private set

    var settings by mutableStateOf(c.providers.load())
        private set
    var testResults by mutableStateOf<Map<String, ConnectionTestResult>>(emptyMap())
        private set
    var testingId by mutableStateOf<String?>(null)
        private set

    var operatorReady by mutableStateOf(false)
        private set
    var diagnostics by mutableStateOf<String?>(null)
        private set
    var diagBusy by mutableStateOf(false)
        private set
    var agentLog by mutableStateOf<List<String>>(emptyList())
        private set
    var agentRunning by mutableStateOf(false)
        private set
    private var agentJob: Job? = null

    var indexRunning by mutableStateOf(false)
        private set
    var indexStatus by mutableStateOf("")
        private set
    var indexedCount by mutableStateOf(0)
        private set
    private var indexJob: Job? = null
    var review by mutableStateOf<ExportReviewResult?>(null)
        private set
    var reviewBusy by mutableStateOf(false)
        private set

    var seedError by mutableStateOf<String?>(null)
        private set

    val storeEncrypted: Boolean get() = c.providers.isEncrypted

    val modules: List<ModuleInfo> = listOf(
        c.brain.info, c.planner.info, c.videoPlanner.info, c.actionDecider.info, c.goalVerifier.info, c.vision.info, c.operator.info,
        c.reviewer.info, c.recovery.info, c.memory.info,
        ModuleInfo(
            "ASSET MANAGER", ImplStatus.PARTIAL,
            "يفهرس صور وفيديوهات هاتفك على الجهاز (تسميات ML Kit) ويبحث فيها بالعربية والإنجليزية ويرفض غير المناسب بسبب.",
            listOf("لا بحث على الإنترنت ولا تنزيل مواد خارجية", "التسميات إنجليزية؛ الوصف العربي يُترجم عبر نموذجك (نص فقط)", "الفهرسة على دفعات"),
        ),
        ModuleInfo(
            "PROJECT EXECUTOR", ImplStatus.PARTIAL,
            "ينفّذ الخطة داخل Alight Motion خطوة بخطوة مع تحقق وإعادة محاولة وحفظ حالة، ويتحقق من ظهور فيديو مُصدَّر فعلاً.",
            listOf("غير مختبر على هاتفك بعد: النجاح يعتمد على دقة نموذج الرؤية", "الخطوات الطويلة بطيئة؛ أبقِ الشاشة مضاءة"),
        ),
    )

    private fun hasProvider() = c.providers.load().providers.isNotEmpty()

    // ---- المساعد الخبير ----
    fun ask(question: String) {
        val q = question.trim()
        if (q.isEmpty() || chatBusy) return
        messages = messages + UiMessage(true, q)
        if (!hasProvider()) {
            messages = messages + UiMessage(false, "أضف مزوداً في تبويب API أولاً ليتمكن المساعد من الإجابة.")
            return
        }
        chatBusy = true
        viewModelScope.launch {
            c.awaitReady()
            val reply = c.brain.advise(q).fold(
                onSuccess = { UiMessage(false, it.text, it.sources.map { s -> s.title }) },
                onFailure = { UiMessage(false, "تعذّر الحصول على رد: ${it.message}") },
            )
            messages = messages + reply
            chatBusy = false
        }
    }

    // ---- الخطة ----
    fun makePlan(goal: String) {
        val g = goal.trim()
        if (g.isEmpty() || planBusy) return
        if (!hasProvider()) {
            planStatus = "أضف مزوداً في تبويب API أولاً."
            return
        }
        planBusy = true
        planStatus = null
        viewModelScope.launch {
            c.awaitReady()
            val hits = c.memory.searchKnowledge(g, 6)
            c.planner.plan(g, hits).fold(
                onSuccess = { plan = it },
                onFailure = {
                    plan = null
                    planStatus = "تعذّر إنشاء الخطة: ${it.message}"
                },
            )
            planBusy = false
        }
    }

    // ---- المشروع المنظم (خطة JSON + مواد + حفظ الحالة) ----
    fun loadLatestRun() {
        viewModelScope.launch {
            c.awaitReady()
            if (run == null) run = c.runManager.resume()
        }
    }

    fun createRun(goal: String, mode: RunMode) {
        val g = goal.trim()
        if (g.isEmpty() || runBusy) return
        if (!hasProvider()) {
            runError = "أضف مزوداً في تبويب API أولاً."
            return
        }
        runBusy = true
        runError = null
        viewModelScope.launch {
            c.awaitReady()
            c.runManager.create(g, mode).fold(
                onSuccess = { r ->
                    run = r
                    review = null
                    if (c.assetIndex.count() > 0) run = c.runManager.resolveAssets(r, c.resolver)
                },
                onFailure = { runError = "تعذّر إنشاء المشروع: ${it.message}" },
            )
            runBusy = false
        }
    }

    fun provideAsset(assetId: String, uri: String) {
        val cur = run ?: return
        viewModelScope.launch { run = c.runManager.provideAsset(cur, assetId, uri) }
    }

    fun changeMode(mode: RunMode) {
        val cur = run ?: return
        viewModelScope.launch { run = c.runManager.changeMode(cur, mode) }
    }

    // ---- الموسوعة ----
    fun search(query: String) {
        viewModelScope.launch {
            c.awaitReady()
            kbResults = if (query.isBlank()) {
                c.memory.listKnowledge(100)
            } else {
                c.memory.searchKnowledge(query, 20).map { it.entry }
            }
            kbCount = c.memory.knowledgeCount()
        }
    }

    // ---- إعدادات API ----
    private fun persist(s: ProviderSettings) {
        c.providers.save(s)
        settings = s
    }

    fun saveProvider(p: ApiProvider) {
        val exists = settings.providers.any { it.id == p.id }
        val list = if (exists) settings.providers.map { if (it.id == p.id) p else it } else settings.providers + p
        persist(settings.copy(providers = list, primaryId = settings.primaryId ?: p.id))
    }

    fun deleteProvider(id: String) {
        persist(
            settings.copy(
                providers = settings.providers.filter { it.id != id },
                primaryId = settings.primaryId.takeIf { it != id },
                fallbackId = settings.fallbackId.takeIf { it != id },
            ),
        )
    }

    fun setPrimary(id: String) {
        persist(settings.copy(primaryId = id, fallbackId = settings.fallbackId.takeIf { it != id }))
    }

    fun toggleFallback(id: String) {
        if (id == settings.primaryId) return
        persist(settings.copy(fallbackId = if (settings.fallbackId == id) null else id))
    }

    fun testProvider(p: ApiProvider) {
        if (testingId != null) return
        testingId = p.id
        viewModelScope.launch {
            val r = testConnection(p)
            testResults = testResults + (p.id to r)
            testingId = null
        }
    }

    // ---- الحالة والتشخيص ----
    fun refreshStatus() {
        viewModelScope.launch {
            c.awaitReady()
            kbCount = c.memory.knowledgeCount()
            operatorReady = c.operator.isReady()
            seedError = c.seedError
        }
    }

    fun testScreenshot() {
        if (diagBusy) return
        diagBusy = true
        viewModelScope.launch {
            diagnostics = c.operator.screenshot().fold(
                onSuccess = {
                    "نجح الالتقاط: ${it.deviceWidth}x${it.deviceHeight} (يُرسل بحجم ${it.width}x${it.height}، نحو ${it.jpegBase64.length / 1365} KB)"
                },
                onFailure = { "فشل الالتقاط: ${it.message}" },
            )
            diagBusy = false
        }
    }

    fun testVision() {
        if (diagBusy) return
        diagBusy = true
        viewModelScope.launch {
            val shot = c.operator.screenshot().getOrElse {
                diagnostics = "فشل الالتقاط: ${it.message}"
                diagBusy = false
                return@launch
            }
            diagnostics = c.vision.observe(shot, "صف ما تراه على الشاشة باختصار.").fold(
                onSuccess = { it.summary },
                onFailure = { "فشل التحليل: ${it.message}" },
            )
            diagBusy = false
        }
    }

    // ---- الوكيل (تجريبي): المهارة 1 = إنشاء مشروع جديد في Alight Motion ----
    fun startAgent(goal: String) {
        if (agentRunning) return
        if (!hasProvider()) {
            agentLog = listOf("أضف مزوداً يدعم الصور (فعّل «يدعم تحليل الصور») في تبويب API أولاً.")
            return
        }
        agentRunning = true
        agentLog = listOf("بدء المهمة… سيفتح Alight Motion الآن.")
        agentJob = viewModelScope.launch {
            try {
                c.awaitReady()
                val kb = c.memory.searchKnowledge(goal, 5).joinToString("\n") {
                    "- [${it.entry.status}] ${it.entry.title}: ${it.entry.body}"
                }
                val loop = AgentLoop(c.operator, c.actionDecider, c.goalVerifier, log = { line -> agentLog = agentLog + line })
                val res = withTimeoutOrNull(240_000L) {
                    loop.run(goal, RunMode.ASSISTED, kb, listOf(UiAction.OpenApp("com.alightcreative.motion")))
                }
                agentLog = agentLog + when {
                    res == null -> "انتهت المهلة (4 دقائق)."
                    res.success -> "✔ نجحت المهمة: ${res.message}"
                    else -> "✘ لم تكتمل: ${res.message}"
                }
            } finally {
                agentRunning = false
            }
        }
    }

    fun stopAgent() {
        agentJob?.cancel()
        agentLog = agentLog + "تم إيقاف المهمة يدوياً."
    }

    // ---- ASSET MANAGER ----
    fun refreshIndexCount() {
        viewModelScope.launch { indexedCount = c.assetIndex.count() }
    }

    fun startIndexing(maxItems: Int = 300) {
        if (indexRunning) return
        indexRunning = true
        indexStatus = "جارٍ الفهرسة على الجهاز (لا تُرفع أي صورة)…"
        indexJob = viewModelScope.launch {
            try {
                val p = c.indexer.run(maxItems) { pr ->
                    indexStatus = "فُهرس ${pr.done} من ${pr.total}" + if (pr.failed > 0) " (تعذّر ${pr.failed})" else ""
                }
                indexStatus = "اكتملت الدفعة: ${p.done} من ${p.total}. اضغط مرة أخرى لفهرسة المزيد."
            } catch (e: CancellationException) {
                indexStatus = "أُوقفت الفهرسة."
                throw e
            } catch (t: Throwable) {
                indexStatus = "فشلت الفهرسة: ${t.message}"
            } finally {
                indexRunning = false
            }
            indexedCount = c.assetIndex.count()
        }
    }

    fun stopIndexing() {
        indexJob?.cancel()
    }

    fun resolveAssets() {
        val cur = run ?: return
        if (runBusy) return
        runBusy = true
        viewModelScope.launch {
            try {
                run = c.runManager.resolveAssets(cur, c.resolver)
            } finally {
                runBusy = false
            }
        }
    }

    // ---- التنفيذ الكامل داخل Alight Motion ----
    fun executeRun() {
        val cur = run ?: return
        if (agentRunning) return
        if (!hasProvider()) {
            agentLog = listOf("أضف مزوداً يدعم الصور في تبويب API أولاً.")
            return
        }
        agentRunning = true
        agentLog = listOf("بدء التنفيذ الكامل في Alight Motion…")
        agentJob = viewModelScope.launch {
            try {
                c.awaitReady()
                val exec = ProjectExecutor(
                    c.operator, c.actionDecider, c.goalVerifier, c.recovery, c.memory, c.catalog,
                    log = { line -> agentLog = (agentLog + line).takeLast(200) },
                )
                exec.execute(cur) { s ->
                    run = s
                    c.runManager.save(s)
                }
                agentLog = agentLog + "انتهى التنفيذ: ${run?.status}"
            } catch (e: CancellationException) {
                agentLog = agentLog + "أُوقف التنفيذ. يمكنك المتابعة من آخر خطوة محفوظة."
                withContext(NonCancellable) {
                    run?.let { r ->
                        val paused = r.copy(status = RunStatus.PAUSED, log = r.log + "stopped by user")
                        c.runManager.save(paused)
                        run = paused
                    }
                }
                throw e
            } catch (t: Throwable) {
                agentLog = agentLog + "خطأ: ${t.message}"
            } finally {
                agentRunning = false
            }
        }
    }

    fun reviewExport() {
        val cur = run ?: return
        val plan = cur.plan ?: return
        val line = cur.log.lastOrNull { it.startsWith("EXPORT:") }
        if (line == null || reviewBusy) {
            if (line == null) agentLog = agentLog + "لا يوجد فيديو مُصدَّر مؤكد لمراجعته."
            return
        }
        val parts = line.removePrefix("EXPORT:").split("|")
        val item = MediaItem(
            uri = parts[0], kind = MediaKind.VIDEO, name = parts.getOrElse(1) { "video" },
            durationMs = parts.getOrNull(2)?.toLongOrNull() ?: 0L,
        )
        reviewBusy = true
        viewModelScope.launch {
            try {
                review = c.exportReviewer.review(plan, item)
            } catch (t: Throwable) {
                agentLog = agentLog + "فشلت المراجعة: ${t.message}"
            } finally {
                reviewBusy = false
            }
        }
    }
}
