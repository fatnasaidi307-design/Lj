package com.ammaster.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ammaster.core.ApiProvider
import com.ammaster.core.KnowledgeEntry
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Plan
import com.ammaster.core.ProviderSettings
import com.ammaster.llm.ConnectionTestResult
import com.ammaster.llm.testConnection
import kotlinx.coroutines.launch

data class UiMessage(val fromUser: Boolean, val text: String, val sources: List<String> = emptyList())

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as App).container

    var messages by mutableStateOf<List<UiMessage>>(emptyList())
        private set
    var chatBusy by mutableStateOf(false)
        private set

    var plan by mutableStateOf<Plan?>(null)
        private set
    var planStatus by mutableStateOf<String?>(null)
        private set
    var planBusy by mutableStateOf(false)
        private set

    var kbResults by mutableStateOf<List<KnowledgeEntry>>(emptyList())
        private set
    var kbCount by mutableStateOf(0)
        private set

    var settings by mutableStateOf(c.providers.load())
        private set
    var testResults by mutableStateOf<Map<String, ConnectionTestResult>>(emptyMap())
        private set
    var testingId by mutableStateOf<String?>(null)
        private set

    var operatorReady by mutableStateOf(false)
        private set
    var diagnostics by mutableStateOf<String?>(null)
        private set
    var diagBusy by mutableStateOf(false)
        private set
    var seedError by mutableStateOf<String?>(null)
        private set

    val storeEncrypted: Boolean get() = c.providers.isEncrypted

    val modules: List<ModuleInfo> = listOf(
        c.brain.info, c.planner.info, c.vision.info, c.operator.info,
        c.reviewer.info, c.recovery.info, c.memory.info,
    )

    private fun hasProvider() = c.providers.load().providers.isNotEmpty()

    // ---- المساعد الخبير ----
    fun ask(question: String) {
        val q = question.trim()
        if (q.isEmpty() || chatBusy) return
        messages = messages + UiMessage(true, q)
        if (!hasProvider()) {
            messages = messages + UiMessage(false, "أضف مزوداً في تبويب API أولاً ليتمكن المساعد من الإجابة.")
            return
        }
        chatBusy = true
        viewModelScope.launch {
            c.awaitReady()
            val reply = c.brain.advise(q).fold(
                onSuccess = { UiMessage(false, it.text, it.sources.map { s -> s.title }) },
                onFailure = { UiMessage(false, "تعذّر الحصول على رد: ${it.message}") },
            )
            messages = messages + reply
            chatBusy = false
        }
    }

    // ---- الخطة ----
    fun makePlan(goal: String) {
        val g = goal.trim()
        if (g.isEmpty() || planBusy) return
        if (!hasProvider()) {
            planStatus = "أضف مزوداً في تبويب API أولاً."
            return
        }
        planBusy = true
        planStatus = null
        viewModelScope.launch {
            c.awaitReady()
            val hits = c.memory.searchKnowledge(g, 6)
            c.planner.plan(g, hits).fold(
                onSuccess = { plan = it },
                onFailure = {
                    plan = null
                    planStatus = "تعذّر إنشاء الخطة: ${it.message}"
                },
            )
            planBusy = false
        }
    }

    // ---- الموسوعة ----
    fun search(query: String) {
        viewModelScope.launch {
            c.awaitReady()
            kbResults = if (query.isBlank()) {
                c.memory.listKnowledge(100)
            } else {
                c.memory.searchKnowledge(query, 20).map { it.entry }
            }
            kbCount = c.memory.knowledgeCount()
        }
    }

    // ---- إعدادات API ----
    private fun persist(s: ProviderSettings) {
        c.providers.save(s)
        settings = s
    }

    fun saveProvider(p: ApiProvider) {
        val exists = settings.providers.any { it.id == p.id }
        val list = if (exists) settings.providers.map { if (it.id == p.id) p else it } else settings.providers + p
        persist(settings.copy(providers = list, primaryId = settings.primaryId ?: p.id))
    }

    fun deleteProvider(id: String) {
        persist(
            settings.copy(
                providers = settings.providers.filter { it.id != id },
                primaryId = settings.primaryId.takeIf { it != id },
                fallbackId = settings.fallbackId.takeIf { it != id },
            ),
        )
    }

    fun setPrimary(id: String) {
        persist(settings.copy(primaryId = id, fallbackId = settings.fallbackId.takeIf { it != id }))
    }

    fun toggleFallback(id: String) {
        if (id == settings.primaryId) return
        persist(settings.copy(fallbackId = if (settings.fallbackId == id) null else id))
    }

    fun testProvider(p: ApiProvider) {
        if (testingId != null) return
        testingId = p.id
        viewModelScope.launch {
            val r = testConnection(p)
            testResults = testResults + (p.id to r)
            testingId = null
        }
    }

    // ---- الحالة والتشخيص ----
    fun refreshStatus() {
        viewModelScope.launch {
            c.awaitReady()
            kbCount = c.memory.knowledgeCount()
            operatorReady = c.operator.isReady()
            seedError = c.seedError
        }
    }

    fun testScreenshot() {
        if (diagBusy) return
        diagBusy = true
        viewModelScope.launch {
            diagnostics = c.operator.screenshot().fold(
                onSuccess = {
                    "نجح الالتقاط: ${it.deviceWidth}x${it.deviceHeight} (يُرسل بحجم ${it.width}x${it.height}، نحو ${it.jpegBase64.length / 1365} KB)"
                },
                onFailure = { "فشل الالتقاط: ${it.message}" },
            )
            diagBusy = false
        }
    }

    fun testVision() {
        if (diagBusy) return
        diagBusy = true
        viewModelScope.launch {
            val shot = c.operator.screenshot().getOrElse {
                diagnostics = "فشل الالتقاط: ${it.message}"
                diagBusy = false
                return@launch
            }
            diagnostics = c.vision.observe(shot, "صف ما تراه على الشاشة باختصار.").fold(
                onSuccess = { it.summary },
                onFailure = { "فشل التحليل: ${it.message}" },
            )
            diagBusy = false
        }
    }
}
