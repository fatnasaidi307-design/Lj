package com.ammaster.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun PlanScreen(vm: MainViewModel) {
    var goal by remember { mutableStateOf("") }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("المخطِّط", style = MaterialTheme.typography.titleLarge) }
        item {
            Text(
                "ينتج خطوات نصية مبنية على الموسوعة. التنفيذ الآلي داخل Alight Motion غير متاح بعد.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        item {
            OutlinedTextField(
                value = goal,
                onValueChange = { goal = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ما النتيجة التي تريدها؟") },
                minLines = 2,
            )
        }
        item {
            Button(enabled = goal.isNotBlank() && !vm.planBusy, onClick = { vm.makePlan(goal) }) {
                Text(if (vm.planBusy) "…جارٍ التخطيط" else "ولّد الخطة")
            }
        }
        vm.planStatus?.let { msg -> item { Text(msg, color = MaterialTheme.colorScheme.error) } }
        vm.plan?.let { p ->
            itemsIndexed(p.steps) { i, s ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${i + 1}. ${s.title}", style = MaterialTheme.typography.titleSmall)
                        if (s.technique.isNotBlank()) Text("الأداة: ${s.technique}", style = MaterialTheme.typography.labelMedium)
                        if (s.details.isNotBlank()) Text(s.details)
                    }
                }
            }
        }
    }
}
