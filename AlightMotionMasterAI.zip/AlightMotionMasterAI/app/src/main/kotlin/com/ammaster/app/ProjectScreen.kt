package com.ammaster.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ammaster.core.AssetStatus
import com.ammaster.core.RunLogic
import com.ammaster.core.RunMode
import com.ammaster.core.RunStatus
import com.ammaster.core.specText

private fun fmt(ms: Long): String {
    val s = ms / 1000.0
    val m = (s / 60).toInt()
    return "%d:%04.1f".format(m, s - m * 60)
}

private fun modeLabel(m: RunMode) = when (m) {
    RunMode.PLAN_ONLY -> "تخطيط فقط (لا ينفّذ)"
    RunMode.ASSISTED -> "مساعدة (ينفّذ ويعرض الخطوات)"
    RunMode.AUTONOMOUS -> "مستقل (دون موافقة عند كل نقرة)"
}

private fun statusLabel(s: RunStatus) = when (s) {
    RunStatus.PLANNED -> "خطة جاهزة (دون تنفيذ)"
    RunStatus.WAITING_ASSETS -> "بانتظار المواد"
    RunStatus.READY -> "جاهز للتنفيذ"
    RunStatus.RUNNING -> "قيد التنفيذ"
    RunStatus.PAUSED -> "متوقف (يمكن المتابعة)"
    RunStatus.DONE -> "مكتمل"
    RunStatus.FAILED -> "فشل"
}

private fun mediaPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

@Composable
fun ProjectScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var goal by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(RunMode.ASSISTED) }
    var pendingAsset by remember { mutableStateOf<String?>(null) }
    var consent by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.loadLatestRun()
        vm.refreshIndexCount()
        vm.refreshStatus()
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.isNotEmpty() && res.values.all { it }) vm.startIndexing()
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val id = pendingAsset
        if (uri != null && id != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (t: Throwable) {
                // بعض المزودين لا يدعمون الإذن الدائم؛ يبقى طوال الجلسة.
            }
            vm.provideAsset(id, uri.toString())
        }
        pendingAsset = null
    }

    val run = vm.run

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // ---------- 1) فهرس الوسائط ----------
        item { Text("1) فهرس صورك وفيديوهاتك", style = MaterialTheme.typography.titleMedium) }
        item {
            Text(
                "المفهرس حالياً: ${vm.indexedCount} عنصراً. الفهرسة تتم على جهازك بالكامل (لا تُرفع أي صورة)، على دفعات من 300 عنصر الأحدث أولاً لحماية أداء الهاتف.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !vm.indexRunning, onClick = {
                    val perms = mediaPermissions()
                    if (perms.all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) vm.startIndexing()
                    else permLauncher.launch(perms)
                }) { Text("افهرس معرضي") }
                OutlinedButton(enabled = vm.indexRunning, onClick = { vm.stopIndexing() }) { Text("إيقاف") }
            }
        }
        if (vm.indexStatus.isNotBlank()) item { Text(vm.indexStatus, style = MaterialTheme.typography.bodySmall) }

        // ---------- 2) المشروع ----------
        item { Text("2) فكرة الفيديو", style = MaterialTheme.typography.titleMedium) }
        item {
            OutlinedTextField(
                value = goal,
                onValueChange = { goal = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("اكتب فكرة المونتاج") },
                minLines = 2,
            )
        }
        item {
            Column {
                RunMode.values().forEach { m ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = mode == m, onClick = { mode = m })
                        Text(modeLabel(m))
                    }
                }
            }
        }
        item {
            Button(enabled = goal.isNotBlank() && !vm.runBusy, onClick = { vm.createRun(goal, mode) }) {
                Text(if (vm.runBusy) "…جارٍ العمل" else "خطّط وابحث عن المواد")
            }
        }
        vm.runError?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }

        if (run != null) {
            val plan = run.plan
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الحالة: ${statusLabel(run.status)}", style = MaterialTheme.typography.titleSmall)
                        Text("الفكرة: ${run.goal}")
                        RunMode.values().forEach { m ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = run.mode == m, onClick = { vm.changeMode(m) })
                                Text(modeLabel(m), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            if (plan != null) {
                item {
                    Text(
                        "${plan.title} · ${plan.aspectRatio} · ${plan.fps}fps · ${fmt(plan.totalDurationMs)}",
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
                plan.scenes.forEach { sc ->
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(sc.title, style = MaterialTheme.typography.titleSmall)
                                sc.shots.sortedBy { it.startMs }.forEach { sh ->
                                    val parts = listOfNotNull(
                                        "${fmt(sh.startMs)}–${fmt(sh.startMs + sh.durationMs)}",
                                        sh.assetId.takeIf { it.isNotBlank() }?.let { "مادة $it" },
                                        sh.text.takeIf { it.isNotBlank() }?.let { "«$it»" },
                                        sh.effects.takeIf { it.isNotEmpty() }?.joinToString("+") { e -> e.name },
                                        sh.transition?.name?.takeIf { it.isNotBlank() }?.let { "انتقال $it" },
                                    )
                                    Text(parts.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
                if (run.issues.isNotEmpty()) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text("ملاحظات التحقق", style = MaterialTheme.typography.titleSmall)
                                run.issues.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                }

                // ---------- 3) المواد ----------
                item { Text("3) المواد المطلوبة", style = MaterialTheme.typography.titleMedium) }
                item {
                    OutlinedButton(enabled = !vm.runBusy && vm.indexedCount > 0, onClick = { vm.resolveAssets() }) {
                        Text("أعد البحث عن المواد في معرضي")
                    }
                }
                items(plan.assets, key = { it.id }) { a ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            when (a.status) {
                                AssetStatus.FOUND_LOCAL, AssetStatus.USER_PROVIDED -> {
                                    val src = if (a.status == AssetStatus.USER_PROVIDED) "اخترتها أنت" else "وُجدت في معرضك"
                                    Text("✔ ${a.id}: ${a.description}", style = MaterialTheme.typography.titleSmall)
                                    Text("$src: ${a.uri}", style = MaterialTheme.typography.bodySmall)
                                    if (a.rejectedReasons.isNotEmpty()) {
                                        Text("مواد رُفضت قبل اختيارها:", style = MaterialTheme.typography.labelMedium)
                                        a.rejectedReasons.forEach { Text("- $it", style = MaterialTheme.typography.bodySmall) }
                                    }
                                }
                                else -> Text(a.specText(), style = MaterialTheme.typography.bodyMedium)
                            }
                            OutlinedButton(onClick = {
                                pendingAsset = a.id
                                picker.launch(arrayOf("image/*", "video/*"))
                            }) {
                                Text(if (a.status == AssetStatus.FOUND_LOCAL || a.status == AssetStatus.USER_PROVIDED) "استبدال الملف" else "اختر ملفاً من هاتفك")
                            }
                        }
                    }
                }

                // ---------- 4) التنفيذ ----------
                item { Text("4) التنفيذ داخل Alight Motion", style = MaterialTheme.typography.titleMedium) }
                item {
                    Text(
                        "تُنسخ المواد المختارة إلى ألبوم خاص بالمشروع في معرضك (الأصول لا تُمس ولا يُحذف شيء). أثناء التنفيذ تُرسَل لقطات شاشتك إلى مزود الذكاء الاصطناعي. أبقِ الشاشة مضاءة وزِد مهلة إطفائها، ولا تلمس الهاتف. للإيقاف: ارجع لهذا التطبيق واضغط إيقاف أو عطّل خدمة الوصول.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = consent, onCheckedChange = { consent = it })
                        Text("أوافق على إرسال لقطات الشاشة وإطارات الفيديو المُصدَّر للمراجعة")
                    }
                }
                item {
                    val canRun = consent && vm.operatorReady && !vm.agentRunning && run.mode != RunMode.PLAN_ONLY &&
                        (run.status == RunStatus.READY || run.status == RunStatus.PAUSED || run.status == RunStatus.RUNNING)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = canRun, onClick = { vm.executeRun() }) {
                            Text(if (run.stepIndex > 0 && run.status != RunStatus.DONE) "تابع التنفيذ" else "ابدأ التنفيذ")
                        }
                        OutlinedButton(enabled = vm.agentRunning, onClick = { vm.stopAgent() }) { Text("إيقاف") }
                    }
                }
                if (!vm.operatorReady) item { Text("خدمة الوصول غير مفعّلة: فعّلها من تبويب الحالة.", color = MaterialTheme.colorScheme.error) }
                if (run.mode == RunMode.PLAN_ONLY) item { Text("وضع «تخطيط فقط» لا ينفّذ. غيّر الوضع للتنفيذ.", style = MaterialTheme.typography.bodySmall) }
                items(vm.agentLog.takeLast(40)) { line -> Text(line, style = MaterialTheme.typography.bodySmall) }

                // ---------- 5) التصدير والمراجعة ----------
                val exported = RunLogic.exportedUri(run)
                if (exported != null) {
                    item { Text("5) فيديو مُصدَّر ومؤكد في معرضك", style = MaterialTheme.typography.titleMedium) }
                    item { Text(exported, style = MaterialTheme.typography.bodySmall) }
                    item {
                        Button(enabled = consent && !vm.reviewBusy, onClick = { vm.reviewExport() }) {
                            Text(if (vm.reviewBusy) "…جارٍ المراجعة" else "راجع الفيديو بصرياً")
                        }
                    }
                }
                vm.review?.let { rv ->
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(if (rv.passed) "✔ اجتاز المراجعة" else "⚠ ملاحظات المراجعة", style = MaterialTheme.typography.titleSmall)
                                rv.durationNote?.let { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                                rv.shots.forEach { sr ->
                                    val r = sr.review
                                    val line = when {
                                        r != null -> "لقطة ${sr.shotId} @${fmt(sr.timeMs)}: ${r.score}/100" +
                                            (if (r.issues.isNotEmpty()) " — " + r.issues.joinToString("؛ ") else "")
                                        else -> "لقطة ${sr.shotId}: ${sr.error ?: "غير مراجَعة"}"
                                    }
                                    Text("• $line", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
