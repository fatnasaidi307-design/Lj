package com.ammaster.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.ammaster.core.ApiFormat
import com.ammaster.core.ApiProvider
import com.ammaster.core.HeaderText
import com.ammaster.llm.ConnectionTestResult
import java.util.UUID

@Composable
fun SettingsScreen(vm: MainViewModel) {
    var editing by remember { mutableStateOf<ApiProvider?>(null) }
    val s = vm.settings

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("مزودو الذكاء الاصطناعي", style = MaterialTheme.typography.titleLarge) }
        item {
            Text(
                "يعمل أي مزود متوافق مع OpenAI (مثل OpenRouter أو Groq أو خادم محلي) أو Anthropic. يُجرَّب المزود الأساسي أولاً ثم الاحتياطي إن فشل.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        if (s.providers.isEmpty()) item { Text("لا يوجد مزود بعد.") }
        items(s.providers, key = { it.id }) { p ->
            val isPrimary = p.id == (s.primaryId ?: s.providers.firstOrNull()?.id)
            val isFallback = p.id == s.fallbackId
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(p.name.ifBlank { "(بدون اسم)" }, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${p.model} · ${if (p.format == ApiFormat.ANTHROPIC) "Anthropic" else "OpenAI-compatible"}" +
                            if (p.supportsVision) " · رؤية" else "",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    val tags = listOfNotNull(if (isPrimary) "أساسي" else null, if (isFallback) "احتياطي" else null)
                    if (tags.isNotEmpty()) Text(tags.joinToString(" · "), color = MaterialTheme.colorScheme.primary)
                    Row {
                        TextButton(onClick = { editing = p }) { Text("تعديل") }
                        TextButton(onClick = { vm.deleteProvider(p.id) }) { Text("حذف") }
                    }
                    Row {
                        TextButton(enabled = !isPrimary, onClick = { vm.setPrimary(p.id) }) { Text("جعله أساسياً") }
                        TextButton(enabled = !isPrimary, onClick = { vm.toggleFallback(p.id) }) {
                            Text(if (isFallback) "إلغاء الاحتياطي" else "جعله احتياطياً")
                        }
                    }
                }
            }
        }
        item {
            Button(onClick = { editing = ApiProvider(id = UUID.randomUUID().toString(), name = "", baseUrl = "", model = "") }) {
                Text("إضافة مزود")
            }
        }
        item {
            Text(
                if (vm.storeEncrypted) {
                    "المفاتيح مخزّنة مشفّرة عبر Android Keystore."
                } else {
                    "تنبيه: تعذّر التشفير على هذا الجهاز، فالمفاتيح مخزّنة في مساحة التطبيق الخاصة دون تشفير."
                },
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }

    editing?.let { init ->
        ProviderDialog(
            initial = init,
            testing = vm.testingId == init.id,
            result = vm.testResults[init.id],
            onTest = { vm.testProvider(it) },
            onSave = {
                vm.saveProvider(it)
                editing = null
            },
            onDismiss = { editing = null },
        )
    }
}

@Composable
private fun LtrField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    secret: Boolean = false,
    minLines: Int = 1,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        singleLine = minLines == 1,
        minLines = minLines,
    )
}

@Composable
private fun ProviderDialog(
    initial: ApiProvider,
    testing: Boolean,
    result: ConnectionTestResult?,
    onTest: (ApiProvider) -> Unit,
    onSave: (ApiProvider) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial.name) }
    var format by remember { mutableStateOf(initial.format) }
    var baseUrl by remember { mutableStateOf(initial.baseUrl) }
    var endpoint by remember { mutableStateOf(initial.endpoint) }
    var apiKey by remember { mutableStateOf(initial.apiKey) }
    var model by remember { mutableStateOf(initial.model) }
    var headers by remember { mutableStateOf(HeaderText.format(initial.headers)) }
    var vision by remember { mutableStateOf(initial.supportsVision) }

    fun build() = initial.copy(
        name = name.trim(),
        format = format,
        baseUrl = baseUrl.trim(),
        endpoint = endpoint.trim(),
        apiKey = apiKey.trim(),
        model = model.trim(),
        headers = HeaderText.parse(headers),
        supportsVision = vision,
    )

    val valid = name.isNotBlank() && baseUrl.isNotBlank() && model.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مزود API") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row {
                    TextButton(onClick = {
                        format = ApiFormat.OPENAI_COMPATIBLE; baseUrl = "https://api.openai.com/v1"; endpoint = ""
                        if (name.isBlank()) name = "OpenAI"
                    }) { Text("OpenAI") }
                    TextButton(onClick = {
                        format = ApiFormat.OPENAI_COMPATIBLE; baseUrl = "https://openrouter.ai/api/v1"; endpoint = ""
                        if (name.isBlank()) name = "OpenRouter"
                    }) { Text("OpenRouter") }
                    TextButton(onClick = {
                        format = ApiFormat.ANTHROPIC; baseUrl = "https://api.anthropic.com"; endpoint = ""
                        if (name.isBlank()) name = "Anthropic"
                    }) { Text("Anthropic") }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("الاسم") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = format == ApiFormat.OPENAI_COMPATIBLE, onClick = { format = ApiFormat.OPENAI_COMPATIBLE })
                    Text("OpenAI-compatible")
                    Spacer(Modifier.width(8.dp))
                    RadioButton(selected = format == ApiFormat.ANTHROPIC, onClick = { format = ApiFormat.ANTHROPIC })
                    Text("Anthropic")
                }
                LtrField(baseUrl, { baseUrl = it }, "Base URL")
                LtrField(endpoint, { endpoint = it }, "Endpoint (اختياري، الافتراضي حسب النوع)")
                LtrField(apiKey, { apiKey = it }, "API Key", secret = true)
                LtrField(model, { model = it }, "Model Name")
                LtrField(headers, { headers = it }, "Headers إضافية (سطر لكل Header: Key: Value)", minLines = 2)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = vision, onCheckedChange = { vision = it })
                    Spacer(Modifier.width(8.dp))
                    Text("يدعم تحليل الصور")
                }
                if (testing) CircularProgressIndicator()
                result?.let {
                    Text(
                        (if (it.ok) "✔ نجح" else "✘ فشل") + " (${it.latencyMs} ms): ${it.message}",
                        color = if (it.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onSave(build()) }) { Text("حفظ") } },
        dismissButton = {
            Row {
                TextButton(enabled = valid && !testing, onClick = { onTest(build()) }) { Text("اختبار الاتصال") }
                TextButton(onClick = onDismiss) { Text("إلغاء") }
            }
        },
    )
}
