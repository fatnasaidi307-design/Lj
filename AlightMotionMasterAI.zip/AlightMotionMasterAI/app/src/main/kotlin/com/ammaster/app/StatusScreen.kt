package com.ammaster.app

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ammaster.core.ImplStatus

@Composable
fun StatusScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var consent by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.refreshStatus() }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("حالة الوحدات (المرحلة 1)", style = MaterialTheme.typography.titleLarge) }
        item { Text("الموسوعة: ${vm.kbCount} إدخالاً") }
        vm.seedError?.let { err -> item { Text("خطأ في تحميل بذرة الموسوعة: $err", color = MaterialTheme.colorScheme.error) } }
        items(vm.modules, key = { it.name }) { m ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    val label = when (m.status) {
                        ImplStatus.IMPLEMENTED -> "✅ مكتمل"
                        ImplStatus.PARTIAL -> "🟡 جزئي"
                        ImplStatus.PLANNED -> "⏳ مخطط"
                    }
                    Text("${m.name}  —  $label", style = MaterialTheme.typography.titleSmall)
                    Text(m.summary, style = MaterialTheme.typography.bodyMedium)
                    m.missing.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        item { Text("اختبار OPERATOR وVISION", style = MaterialTheme.typography.titleMedium) }
        item {
            Text(
                if (vm.operatorReady) "خدمة الوصول: مفعّلة" else "خدمة الوصول: غير مفعّلة. فعّلها من الإعدادات ثم اضغط تحديث.",
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("إعدادات الوصول") }
                OutlinedButton(onClick = { vm.refreshStatus() }) { Text("تحديث") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = vm.operatorReady && !vm.diagBusy, onClick = { vm.testScreenshot() }) { Text("اختبار الالتقاط") }
                Button(enabled = vm.operatorReady && !vm.diagBusy, onClick = { vm.testVision() }) { Text("اختبار الرؤية") }
            }
        }
        vm.diagnostics?.let { d -> item { Text(d) } }

        item { Text("تشغيل الوكيل (تجريبي)", style = MaterialTheme.typography.titleMedium) }
        item { Text("المهارة 1: يفتح Alight Motion وينشئ مشروعاً جديداً ثم يتحقق بصرياً من النتيجة.", style = MaterialTheme.typography.bodyMedium) }
        item {
            Text(
                "تنبيه: أثناء التشغيل تُرسَل لقطات شاشتك ونصوص عناصرها إلى مزود الذكاء الاصطناعي الذي اخترته (يجب أن يدعم الصور). لا تُبقِ محتوى خاصاً ظاهراً. يتوقف تلقائياً بعد 15 خطوة أو 4 دقائق. للإيقاف: ارجع لهذا التطبيق واضغط إيقاف، أو عطّل خدمة الوصول.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = consent, onCheckedChange = { consent = it })
                Text("أوافق على إرسال لقطات الشاشة لهذه المهمة")
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = consent && vm.operatorReady && !vm.agentRunning,
                    onClick = { vm.startAgent(SKILL_NEW_PROJECT) },
                ) { Text("ابدأ") }
                OutlinedButton(enabled = vm.agentRunning, onClick = { vm.stopAgent() }) { Text("إيقاف") }
            }
        }
        items(vm.agentLog) { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
    }
}

private const val SKILL_NEW_PROJECT =
    "Create a new empty project in Alight Motion. From the home/projects screen, tap the button that creates a new project, " +
        "keep the default settings (or choose portrait 9:16) and confirm. The goal is achieved only when the editor screen of " +
        "the NEW project (with its timeline and tools) is visible."
