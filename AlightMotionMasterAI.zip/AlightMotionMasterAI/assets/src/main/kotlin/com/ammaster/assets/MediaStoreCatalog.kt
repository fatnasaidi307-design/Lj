package com.ammaster.assets

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.ammaster.core.MediaCatalog
import com.ammaster.core.MediaItem
import com.ammaster.core.MediaKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaStoreCatalog(context: Context) : MediaCatalog {
    private val resolver = context.applicationContext.contentResolver

    private val imagesUri: Uri get() = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    private val videosUri: Uri get() = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    /** نستبعد ألبوماتنا المؤقتة كي لا تُفهرس نسخنا نحن. */
    private val notStaged =
        "(${MediaStore.MediaColumns.RELATIVE_PATH} IS NULL OR ${MediaStore.MediaColumns.RELATIVE_PATH} NOT LIKE '%AMMaster/%')"

    override suspend fun scan(): List<MediaItem> = withContext(Dispatchers.IO) {
        query(MediaKind.IMAGE, imagesUri, notStaged, null) + query(MediaKind.VIDEO, videosUri, notStaged, null)
    }

    override suspend fun newVideosSince(sinceMs: Long): List<MediaItem> = withContext(Dispatchers.IO) {
        val sinceSec = (sinceMs / 1000L - 2L).coerceAtLeast(0L)
        query(MediaKind.VIDEO, videosUri, "${MediaStore.MediaColumns.DATE_ADDED} >= ? AND $notStaged", arrayOf(sinceSec.toString()))
    }

    private fun query(kind: MediaKind, base: Uri, selection: String, args: Array<String>?): List<MediaItem> {
        val proj = mutableListOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
        )
        if (kind == MediaKind.VIDEO) proj.add(MediaStore.Video.VideoColumns.DURATION)
        val out = ArrayList<MediaItem>()
        resolver.query(base, proj.toTypedArray(), selection, args, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            while (c.moveToNext()) {
                out.add(
                    MediaItem(
                        uri = ContentUris.withAppendedId(base, c.getLong(0)).toString(),
                        kind = kind,
                        name = c.getString(1) ?: "",
                        width = c.getInt(2),
                        height = c.getInt(3),
                        sizeBytes = c.getLong(4),
                        dateAddedSec = c.getLong(5),
                        bucket = c.getString(6) ?: "",
                        durationMs = if (kind == MediaKind.VIDEO) c.getLong(7) else 0L,
                    ),
                )
            }
        }
        return out
    }

    override suspend fun describe(uri: String): MediaItem? = withContext(Dispatchers.IO) {
        try {
            val u = Uri.parse(uri)
            val mime = resolver.getType(u) ?: return@withContext null
            val kind = if (mime.startsWith("video/")) MediaKind.VIDEO else MediaKind.IMAGE
            var name = "media"
            var size = 0L
            resolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    name = c.getString(0) ?: name
                    size = c.getLong(1)
                }
            }
            MediaItem(uri = uri, kind = kind, name = name, sizeBytes = size)
        } catch (t: Throwable) {
            null
        }
    }

    override suspend fun stage(runId: String, ordinal: Int, item: MediaItem): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val src = Uri.parse(item.uri)
            val mime = resolver.getType(src) ?: if (item.kind == MediaKind.VIDEO) "video/mp4" else "image/jpeg"
            val collection = if (item.kind == MediaKind.VIDEO) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "%02d_%s".format(ordinal, item.name.ifBlank { "media" }))
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/AMMaster/${runId.take(8)}")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val dst = resolver.insert(collection, cv) ?: error("Could not create a staged copy")
            try {
                val input = resolver.openInputStream(src) ?: error("Could not open the source file")
                val output = resolver.openOutputStream(dst) ?: error("Could not open the destination file")
                input.use { i -> output.use { o -> i.copyTo(o) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(dst, done, null, null)
            } catch (t: Throwable) {
                resolver.delete(dst, null, null) // حذف نسختنا الناقصة فقط، لا ملفات المستخدم
                throw t
            }
            dst.toString()
        }
    }
}
