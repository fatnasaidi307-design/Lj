package com.ammaster.assets

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Size
import com.ammaster.core.MediaItem
import com.ammaster.core.MediaKind
import com.ammaster.core.MediaLabeler
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabel
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** تصنيف بصري على الجهاز (ML Kit، بلا إنترنت). للفيديو: ثلاث لقطات (10% و50% و90%). */
class MlKitLabeler(context: Context) : MediaLabeler {
    private val app = context.applicationContext
    private val labeler = ImageLabeling.getClient(
        ImageLabelerOptions.Builder().setConfidenceThreshold(0.55f).build(),
    )

    override suspend fun labels(item: MediaItem): Result<Map<String, Float>> = withContext(Dispatchers.Default) {
        runCatching {
            val bitmaps = if (item.kind == MediaKind.IMAGE) listOf(loadImage(item.uri)) else loadVideoFrames(item)
            check(bitmaps.isNotEmpty()) { "No frames could be read" }
            val merged = LinkedHashMap<String, Float>()
            for (b in bitmaps) {
                for (l in label(b)) {
                    val key = l.text.lowercase()
                    if ((merged[key] ?: 0f) < l.confidence) merged[key] = l.confidence
                }
                b.recycle()
            }
            merged
        }
    }

    private fun loadImage(uri: String): Bitmap = app.contentResolver.loadThumbnail(Uri.parse(uri), Size(512, 512), null)

    private fun loadVideoFrames(item: MediaItem): List<Bitmap> {
        val r = MediaMetadataRetriever()
        val out = ArrayList<Bitmap>()
        try {
            r.setDataSource(app, Uri.parse(item.uri))
            val dur = item.durationMs.takeIf { it > 0 }
                ?: r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            for (f in listOf(0.1, 0.5, 0.9)) {
                val bmp = r.getFrameAtTime((dur * f * 1000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                val scale = 512f / maxOf(bmp.width, bmp.height)
                out.add(if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp)
            }
        } finally {
            r.release()
        }
        return out
    }

    private suspend fun label(bmp: Bitmap): List<ImageLabel> = suspendCancellableCoroutine { cont ->
        labeler.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
            .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
    }
}
