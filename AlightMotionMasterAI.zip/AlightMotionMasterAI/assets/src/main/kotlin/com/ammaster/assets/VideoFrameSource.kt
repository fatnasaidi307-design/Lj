package com.ammaster.assets

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Base64
import com.ammaster.core.FrameSource
import com.ammaster.core.Screenshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** يستخرج لقطة من فيديو مُصدَّر عند زمن محدد (لمراجعته بصرياً). */
class VideoFrameSource(context: Context) : FrameSource {
    private val app = context.applicationContext

    override suspend fun frameAt(videoUri: String, timeMs: Long): Result<Screenshot> = withContext(Dispatchers.IO) {
        runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(app, Uri.parse(videoUri))
                val bmp = r.getFrameAtTime(timeMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: error("No frame at ${timeMs}ms")
                val scale = minOf(1f, 1024f / maxOf(bmp.width, bmp.height))
                val out = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
                val bos = ByteArrayOutputStream()
                out.compress(Bitmap.CompressFormat.JPEG, 75, bos)
                Screenshot(Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP), out.width, out.height, bmp.width, bmp.height)
            } finally {
                r.release()
            }
        }
    }
}
