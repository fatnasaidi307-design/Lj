package com.ammaster.brain

import com.ammaster.core.AssetIndex
import com.ammaster.core.IndexedMedia
import com.ammaster.core.MediaCatalog
import com.ammaster.core.MediaLabeler
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.yield

data class IndexProgress(val done: Int, val total: Int, val failed: Int)

/** يفهرس الأحدث أولاً على دفعات (لحماية أداء الهاتف وحرارته). قابل للإيقاف والاستئناف. */
class AssetIndexer(
    private val catalog: MediaCatalog,
    private val labeler: MediaLabeler,
    private val index: AssetIndex,
) {
    suspend fun run(maxItems: Int = 300, onProgress: (IndexProgress) -> Unit = {}): IndexProgress {
        val todo = catalog.scan().filter { !index.isIndexed(it.uri) }.take(maxItems)
        var done = 0
        var failed = 0
        onProgress(IndexProgress(0, todo.size, 0))
        for (item in todo) {
            currentCoroutineContext().ensureActive()
            val labels = labeler.labels(item)
            if (labels.isSuccess) done++ else failed++
            // العنصر الفاشل يُحفظ بلا تسميات ليبقى قابلاً للبحث باسمه وألبومه
            index.upsert(IndexedMedia(item, labels.getOrDefault(emptyMap())))
            onProgress(IndexProgress(done, todo.size, failed))
            yield()
        }
        return IndexProgress(done, todo.size, failed)
    }
}
