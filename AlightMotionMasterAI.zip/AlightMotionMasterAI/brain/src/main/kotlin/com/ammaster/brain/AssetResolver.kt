package com.ammaster.brain

import com.ammaster.core.AssetIndex
import com.ammaster.core.AssetRequest
import com.ammaster.core.AssetStatus
import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.IndexedMedia
import com.ammaster.core.JsonUtil
import com.ammaster.core.Lexical
import com.ammaster.core.LlmClient
import com.ammaster.core.MediaItem
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * يحوّل وصف مادة مطلوبة إلى تسميات إنجليزية قريبة من تسميات تصنيف الصور (يرسل النص فقط، لا صوراً).
 * إن فشل النموذج تبقى كلمات المخطط ووصفه كافية للبحث.
 */
class LlmKeywordExpander(private val llm: LlmClient) {
    suspend fun expand(req: AssetRequest): List<String> {
        val user = "Asset description: ${req.description}\nBackground: ${req.background}\nKeywords: ${req.searchKeywords.joinToString()}"
        val reply = llm.chat(ChatRequest(listOf(ChatMessage("user", user)), SYSTEM, 300, 0.1)).getOrNull() ?: return emptyList()
        return parse(reply.text)
    }

    companion object {
        const val SYSTEM = "Translate the asset description into up to 12 short English words or phrases that an image " +
            "classifier (like Google ML Kit image labeling: Person, House, Sky, Building, Car, Room, Tree, Food...) would " +
            "output for a matching photo. Reply with JSON only: {\"labels\":[\"...\"]}."

        fun parse(text: String): List<String> {
            val json = JsonUtil.extractObject(text) ?: return emptyList()
            return try {
                Json.parseToJsonElement(json).jsonObject["labels"]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull } ?: emptyList()
            } catch (t: Throwable) {
                emptyList()
            }
        }
    }
}

/** يختار أفضل مادة من فهرس الهاتف لكل طلب، ويرفض غير المناسب مع ذكر السبب. لا يدّعي وجود ما لم يجده. */
class AssetResolver(
    private val index: AssetIndex,
    private val expander: suspend (AssetRequest) -> List<String> = { emptyList() },
) {
    suspend fun resolve(req: AssetRequest): AssetRequest {
        if (req.status == AssetStatus.USER_PROVIDED) return req
        val total = index.count()
        if (total == 0) {
            return req.copy(status = AssetStatus.MISSING, rejectedReasons = listOf("فهرس معرض الهاتف فارغ: افهرس صورك وفيديوهاتك أولاً"))
        }
        val extra = runCatching { expander(req) }.getOrDefault(emptyList())
        val tokens = (extra + req.searchKeywords + req.description).flatMap { Lexical.tokens(it) }.distinct().take(30)
        if (tokens.isEmpty()) {
            return req.copy(status = AssetStatus.MISSING, rejectedReasons = listOf("لا توجد كلمات بحث صالحة"))
        }
        val rejected = mutableListOf<String>()
        var best: IndexedMedia? = null
        var bestScore = 0.0
        for (c in index.candidates(tokens, 80)) {
            val hard = hardReject(req, c.item)
            if (hard != null) {
                rejected.add("${c.item.name}: $hard")
                continue
            }
            val s = score(c, tokens)
            if (s < MIN_SCORE) {
                rejected.add("${c.item.name}: تطابق ضعيف مع الوصف")
            } else if (s > bestScore) {
                best = c
                bestScore = s
            }
        }
        val chosen = best
        return if (chosen != null) {
            req.copy(status = AssetStatus.FOUND_LOCAL, uri = chosen.item.uri, rejectedReasons = rejected.take(5))
        } else {
            req.copy(
                status = AssetStatus.MISSING,
                rejectedReasons = rejected.take(5).ifEmpty { listOf("لا توجد مادة مطابقة بين $total عنصراً مفهرساً") },
            )
        }
    }

    internal fun hardReject(req: AssetRequest, item: MediaItem): String? {
        if (item.kind != req.kind) return "نوع مختلف عن المطلوب"
        if (req.minWidth > 0 && item.width in 1 until req.minWidth) return "دقة منخفضة (${item.width}x${item.height})"
        if (req.minHeight > 0 && item.height in 1 until req.minHeight) return "دقة منخفضة (${item.width}x${item.height})"
        if (req.durationMs > 0 && item.durationMs > 0 && item.durationMs < req.durationMs * 0.9) return "المدة أقصر من المطلوبة"
        val o = item.orientation
        if (o != "unknown" && req.orientation in setOf("portrait", "landscape", "square") && o != req.orientation) {
            return "اتجاه مختلف ($o بدل ${req.orientation})"
        }
        return null
    }

    internal fun score(c: IndexedMedia, tokens: List<String>): Double {
        val set = tokens.toSet()
        var s = 0.0
        for ((label, conf) in c.labels) {
            if (Lexical.tokens(label).any { it in set }) s += conf
        }
        val nameTokens = Lexical.tokens(c.item.name + " " + c.item.bucket)
        s += 0.25 * nameTokens.count { it in set }
        return s
    }

    companion object {
        const val MIN_SCORE = 0.6
    }
}
