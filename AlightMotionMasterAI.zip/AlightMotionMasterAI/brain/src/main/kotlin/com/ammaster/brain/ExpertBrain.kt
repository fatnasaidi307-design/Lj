package com.ammaster.brain

import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ExpertModule
import com.ammaster.core.ExpertRules
import com.ammaster.core.ImplStatus
import com.ammaster.core.KnowledgeEntry
import com.ammaster.core.LlmClient
import com.ammaster.core.MemoryStore
import com.ammaster.core.ModuleInfo

data class Advice(val text: String, val sources: List<KnowledgeEntry>)

class ExpertBrain(private val llm: LlmClient, private val memory: MemoryStore) : ExpertModule {
    override val info = ModuleInfo(
        name = "EXPERT BRAIN",
        status = ImplStatus.PARTIAL,
        summary = "يجيب عن أسئلة Alight Motion اعتماداً على الموسوعة المحلية والخبرات السابقة، ويعلّم غير الموثّق.",
        missing = listOf(
            "تغطية الموسوعة ما زالت أولية (كثير من الأقسام لم تُجمع بعد)",
            "حلقة التنسيق بين الوحدات (Orchestrator) ضمن مرحلة التنفيذ الآلي",
        ),
    )

    suspend fun advise(question: String): Result<Advice> {
        val hits = memory.searchKnowledge(question, 6)
        val past = memory.recentExperiences(3)
        val kb = if (hits.isEmpty()) {
            "(no matching knowledge entries)"
        } else {
            hits.joinToString("\n\n") { "[${it.entry.status}] ${it.entry.title}\n${it.entry.body}" }
        }
        val exp = if (past.isEmpty()) "" else "\n\nPast experiences:\n" +
            past.joinToString("\n") { "- ${it.goal} -> ${it.outcome} (score ${it.score}): ${it.notes}" }
        val user = "Question:\n$question\n\nKnowledge entries:\n$kb$exp"
        return llm.chat(ChatRequest(listOf(ChatMessage("user", user)), ExpertRules.FACT_RULES, 1200, 0.3))
            .map { Advice(it.text, hits.map { h -> h.entry }) }
    }
}
