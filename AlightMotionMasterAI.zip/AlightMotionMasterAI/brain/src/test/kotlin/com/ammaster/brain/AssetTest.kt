package com.ammaster.brain

import com.ammaster.core.AssetIndex
import com.ammaster.core.AssetRequest
import com.ammaster.core.AssetStatus
import com.ammaster.core.IndexedMedia
import com.ammaster.core.MediaCatalog
import com.ammaster.core.MediaItem
import com.ammaster.core.MediaKind
import com.ammaster.core.MediaLabeler
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class AssetTest {
    private class MemIndex : AssetIndex {
        val items = LinkedHashMap<String, IndexedMedia>()
        override suspend fun upsert(media: IndexedMedia) { items[media.item.uri] = media }
        override suspend fun isIndexed(uri: String) = uri in items
        override suspend fun count() = items.size
        override suspend fun candidates(tokens: List<String>, limit: Int) = items.values.toList()
    }

    private fun img(uri: String, w: Int = 1080, h: Int = 1920, kind: MediaKind = MediaKind.IMAGE, dur: Long = 0) =
        MediaItem(uri, kind, "$uri.jpg", w, h, dur)

    private fun idx(item: MediaItem, vararg labels: Pair<String, Float>) = IndexedMedia(item, labels.toMap())

    @Test
    fun picksBestMatchAndExplainsRejections() = runBlocking {
        val index = MemIndex()
        index.upsert(idx(img("village"), "village" to 0.9f, "house" to 0.8f))
        index.upsert(idx(img("lowres", 200, 300), "village" to 0.95f))
        index.upsert(idx(img("wide", 1920, 1080), "village" to 0.95f))
        index.upsert(idx(img("car"), "car" to 0.9f))
        val req = AssetRequest("a1", MediaKind.IMAGE, "قرية مغربية", orientation = "portrait", minWidth = 720,
            searchKeywords = listOf("village", "قرية"))
        val r = AssetResolver(index).resolve(req)
        assertEquals(AssetStatus.FOUND_LOCAL, r.status)
        assertEquals("village", r.uri)
        assertTrue(r.rejectedReasons.any { it.contains("دقة منخفضة") })
        assertTrue(r.rejectedReasons.any { it.contains("اتجاه مختلف") })
    }

    @Test
    fun reportsMissingInsteadOfInventing() = runBlocking {
        val index = MemIndex()
        index.upsert(idx(img("car"), "car" to 0.9f))
        val r = AssetResolver(index).resolve(AssetRequest("a", MediaKind.IMAGE, "village", searchKeywords = listOf("village")))
        assertEquals(AssetStatus.MISSING, r.status)
        assertEquals("", r.uri)
        assertTrue(r.rejectedReasons.isNotEmpty())
    }

    @Test
    fun emptyIndexIsMissingWithClearReason() = runBlocking {
        val r = AssetResolver(MemIndex()).resolve(AssetRequest("a", MediaKind.IMAGE, "x"))
        assertEquals(AssetStatus.MISSING, r.status)
        assertTrue(r.rejectedReasons[0].contains("فارغ"))
    }

    @Test
    fun videoNeedsEnoughDuration() = runBlocking {
        val index = MemIndex()
        index.upsert(idx(img("short", kind = MediaKind.VIDEO, dur = 2000), "person" to 0.9f))
        index.upsert(idx(img("long", kind = MediaKind.VIDEO, dur = 9000), "person" to 0.8f))
        val r = AssetResolver(index).resolve(AssetRequest("v", MediaKind.VIDEO, "person", durationMs = 5000, searchKeywords = listOf("person")))
        assertEquals("long", r.uri)
    }

    @Test
    fun userProvidedAssetIsNeverReplaced() = runBlocking {
        val req = AssetRequest("a", MediaKind.IMAGE, "x", status = AssetStatus.USER_PROVIDED, uri = "mine")
        assertEquals(req, AssetResolver(MemIndex()).resolve(req))
    }

    @Test
    fun expanderOutputIsUsedForSearch() = runBlocking {
        val index = MemIndex()
        index.upsert(idx(img("house"), "house" to 0.9f))
        val r = AssetResolver(index) { listOf("House") }.resolve(AssetRequest("a", MediaKind.IMAGE, "بيت قديم"))
        assertEquals(AssetStatus.FOUND_LOCAL, r.status)
    }

    @Test
    fun parsesExpanderReply() {
        assertEquals(listOf("Village", "House"), LlmKeywordExpander.parse("```json\n{\"labels\":[\"Village\",\"House\"]}\n```"))
        assertEquals(emptyList(), LlmKeywordExpander.parse("nope"))
    }

    @Test
    fun indexerSkipsAlreadyIndexedAndSurvivesLabelerFailure() = runBlocking {
        val items = listOf(img("a"), img("b"), img("c"))
        val catalog = object : MediaCatalog {
            override suspend fun scan() = items
            override suspend fun newVideosSince(sinceMs: Long) = emptyList<MediaItem>()
            override suspend fun describe(uri: String): MediaItem? = null
            override suspend fun stage(runId: String, ordinal: Int, item: MediaItem) = Result.success("x")
        }
        val labeler = object : MediaLabeler {
            override suspend fun labels(item: MediaItem): Result<Map<String, Float>> =
                if (item.uri == "b") Result.failure(IllegalStateException("bad")) else Result.success(mapOf("tree" to 0.9f))
        }
        val index = MemIndex()
        index.upsert(idx(img("a"), "old" to 1f))
        val p = AssetIndexer(catalog, labeler, index).run()
        assertEquals(2, p.total)
        assertEquals(1, p.failed)
        assertEquals(3, index.count())
        assertEquals(mapOf("old" to 1f), index.items["a"]!!.labels)
    }
}
