package com.ammaster.brain

import com.ammaster.core.ChatRequest
import com.ammaster.core.ChatResponse
import com.ammaster.core.Experience
import com.ammaster.core.ImplStatus
import com.ammaster.core.KnowledgeEntry
import com.ammaster.core.KnowledgeHit
import com.ammaster.core.KnowledgeStatus
import com.ammaster.core.LlmClient
import com.ammaster.core.MemoryStore
import com.ammaster.core.ModuleInfo
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class BrainTest {
    private val entry = KnowledgeEntry(
        "easing.what", "easing", "What is easing", "Easing = gradual accel.",
        status = KnowledgeStatus.VERIFIED,
    )

    private class FakeMemory(private val hits: List<KnowledgeHit>) : MemoryStore {
        override val info = ModuleInfo("MEMORY", ImplStatus.PARTIAL, "fake")
        override suspend fun searchKnowledge(query: String, limit: Int) = hits
        override suspend fun listKnowledge(limit: Int) = hits.map { it.entry }
        override suspend fun upsertKnowledge(entry: KnowledgeEntry) {}
        override suspend fun knowledgeCount() = hits.size
        override suspend fun saveExperience(experience: Experience) = 1L
        override suspend fun recentExperiences(limit: Int) = emptyList<Experience>()
    }

    @Test
    fun putsKnowledgeInPromptAndReturnsSources() = runBlocking {
        var captured: ChatRequest? = null
        val llm = object : LlmClient {
            override suspend fun chat(request: ChatRequest): Result<ChatResponse> {
                captured = request
                return Result.success(ChatResponse("answer"))
            }
        }
        val advice = ExpertBrain(llm, FakeMemory(listOf(KnowledgeHit(entry, 3.0)))).advise("easing?").getOrThrow()
        assertEquals("answer", advice.text)
        assertEquals(listOf(entry), advice.sources)
        assertTrue(captured!!.messages[0].text.contains("[verified] What is easing"))
        assertTrue(captured!!.system!!.contains("Never invent"))
    }

    @Test
    fun saysNoKnowledgeWhenNothingMatches() = runBlocking {
        var prompt = ""
        val llm = object : LlmClient {
            override suspend fun chat(request: ChatRequest): Result<ChatResponse> {
                prompt = request.messages[0].text
                return Result.success(ChatResponse("unknown"))
            }
        }
        ExpertBrain(llm, FakeMemory(emptyList())).advise("something").getOrThrow()
        assertTrue(prompt.contains("no matching knowledge entries"))
    }
}
