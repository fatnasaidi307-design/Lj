package com.ammaster.brain

import com.ammaster.core.AssetRequest
import com.ammaster.core.AssetStatus
import com.ammaster.core.Experience
import com.ammaster.core.ImplStatus
import com.ammaster.core.KnowledgeEntry
import com.ammaster.core.KnowledgeHit
import com.ammaster.core.MemoryStore
import com.ammaster.core.ModuleInfo
import com.ammaster.core.RunMode
import com.ammaster.core.RunState
import com.ammaster.core.RunStatus
import com.ammaster.core.RunStore
import com.ammaster.core.Scene
import com.ammaster.core.Shot
import com.ammaster.core.VideoPlan
import com.ammaster.core.VideoPlanner
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class RunManagerTest {
    private class Mem : MemoryStore {
        override val info = ModuleInfo("MEMORY", ImplStatus.PARTIAL, "fake")
        override suspend fun searchKnowledge(query: String, limit: Int) = emptyList<KnowledgeHit>()
        override suspend fun listKnowledge(limit: Int) = emptyList<KnowledgeEntry>()
        override suspend fun upsertKnowledge(entry: KnowledgeEntry) {}
        override suspend fun knowledgeCount() = 0
        override suspend fun saveExperience(experience: Experience) = 1L
        override suspend fun recentExperiences(limit: Int) = emptyList<Experience>()
    }

    private class Store : RunStore {
        val map = LinkedHashMap<String, RunState>()
        override suspend fun save(state: RunState) { map[state.runId] = state }
        override suspend fun load(runId: String) = map[runId]
        override suspend fun latestUnfinished() =
            map.values.filter { it.status != RunStatus.DONE && it.status != RunStatus.FAILED }.maxByOrNull { it.updatedAt }
    }

    private class FixedPlanner(private val result: Result<VideoPlan>) : VideoPlanner {
        override val info = ModuleInfo("VP", ImplStatus.IMPLEMENTED, "fake")
        override suspend fun plan(goal: String, knowledge: List<KnowledgeHit>) = result
    }

    private val plan = VideoPlan(
        "t", totalDurationMs = 3000,
        scenes = listOf(Scene("s", "t", listOf(Shot("sh", 0, 3000, assetId = "a1")))),
        assets = listOf(AssetRequest("a1", description = "قرية")),
    )

    @Test
    fun createsWaitingRunAndPersistsIt() = runBlocking {
        val store = Store()
        val m = RunManager(FixedPlanner(Result.success(plan)), Mem(), store)
        val s = m.create("goal", RunMode.ASSISTED).getOrThrow()
        assertEquals(RunStatus.WAITING_ASSETS, s.status)
        assertEquals(AssetStatus.UNRESOLVED, s.plan!!.assets[0].status)
        assertNotNull(store.load(s.runId))
        assertEquals(s.runId, m.resume()!!.runId)
    }

    @Test
    fun providingAssetMakesRunReadyAndIsSaved() = runBlocking {
        val store = Store()
        val m = RunManager(FixedPlanner(Result.success(plan)), Mem(), store)
        val s = m.create("g", RunMode.AUTONOMOUS).getOrThrow()
        val next = m.provideAsset(s, "a1", "content://media/1")
        assertEquals(RunStatus.READY, next.status)
        assertEquals("content://media/1", store.load(s.runId)!!.plan!!.assets[0].uri)
    }

    @Test
    fun planOnlyModeNeverWaitsOrRuns() = runBlocking {
        val m = RunManager(FixedPlanner(Result.success(plan)), Mem(), Store())
        assertEquals(RunStatus.PLANNED, m.create("g", RunMode.PLAN_ONLY).getOrThrow().status)
    }

    @Test
    fun invalidPlanIsRejectedAndNotSaved() = runBlocking {
        val bad = plan.copy(totalDurationMs = 1000)
        val store = Store()
        val r = RunManager(FixedPlanner(Result.success(bad)), Mem(), store).create("g", RunMode.ASSISTED)
        assertTrue(r.isFailure)
        assertTrue(store.map.isEmpty())
    }

    @Test
    fun plannerFailurePropagates() = runBlocking {
        val r = RunManager(FixedPlanner(Result.failure(IllegalStateException("no llm"))), Mem(), Store())
            .create("g", RunMode.ASSISTED)
        assertTrue(r.isFailure)
    }
}
