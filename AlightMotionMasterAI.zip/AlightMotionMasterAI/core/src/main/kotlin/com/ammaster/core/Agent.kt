package com.ammaster.core

/** عنصر من شجرة واجهة التطبيق (إن وُجدت). الإحداثيات بنفس نظام الصورة التي يراها النموذج. */
data class UiNode(
    val text: String,
    val desc: String,
    val clickable: Boolean,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val type: String = "",
)

enum class AgentStatus { CONTINUE, DONE, FAILED }

data class AgentDecision(
    val status: AgentStatus,
    val action: UiAction? = null,
    val reason: String = "",
    val expected: String = "",
)

data class StepRecord(val n: Int, val action: String, val reason: String, val expected: String, val outcome: String)

data class VerifyResult(val achieved: Boolean, val evidence: String)

interface ActionDecider : ExpertModule {
    suspend fun decide(
        goal: String,
        knowledge: String,
        history: List<StepRecord>,
        shot: Screenshot,
        nodes: List<UiNode>,
    ): Result<AgentDecision>
}

/** مدقّق مستقل عن المنفّذ: لا يصدّق ادّعاء «تم» إلا إذا رأى الدليل في الشاشة. */
interface GoalVerifier : ExpertModule {
    suspend fun verify(goal: String, shot: Screenshot, nodes: List<UiNode>): Result<VerifyResult>
}

// ---- تحويل الإحداثيات بين صورة النموذج وشاشة الجهاز الحقيقية ----
fun Screenshot.toDeviceX(x: Int): Int = if (width <= 0) x else (x.toLong() * deviceWidth / width).toInt()
fun Screenshot.toDeviceY(y: Int): Int = if (height <= 0) y else (y.toLong() * deviceHeight / height).toInt()
private fun Screenshot.toImageX(x: Int): Int = if (deviceWidth <= 0) x else (x.toLong() * width / deviceWidth).toInt()
private fun Screenshot.toImageY(y: Int): Int = if (deviceHeight <= 0) y else (y.toLong() * height / deviceHeight).toInt()

fun Screenshot.nodeToImage(n: UiNode): UiNode =
    n.copy(left = toImageX(n.left), top = toImageY(n.top), right = toImageX(n.right), bottom = toImageY(n.bottom))

fun UiAction.scaledToDevice(shot: Screenshot): UiAction = when (this) {
    is UiAction.Tap -> UiAction.Tap(shot.toDeviceX(x), shot.toDeviceY(y))
    is UiAction.LongPress -> UiAction.LongPress(shot.toDeviceX(x), shot.toDeviceY(y), durationMs)
    is UiAction.Swipe -> UiAction.Swipe(shot.toDeviceX(x1), shot.toDeviceY(y1), shot.toDeviceX(x2), shot.toDeviceY(y2), durationMs)
    else -> this
}

fun UiAction.describe(): String = when (this) {
    is UiAction.Tap -> "tap($x,$y)"
    is UiAction.LongPress -> "long_press($x,$y)"
    is UiAction.Swipe -> "swipe($x1,$y1 -> $x2,$y2)"
    is UiAction.TypeText -> "type(\"$text\")"
    is UiAction.OpenApp -> "open_app($packageName)"
    is UiAction.Wait -> "wait(${ms}ms)"
    UiAction.Back -> "back"
}

fun UiAction.kind(): ActionKind = when (this) {
    is UiAction.TypeText -> ActionKind.TYPE_TEXT
    is UiAction.OpenApp -> ActionKind.OPEN_APP
    else -> ActionKind.UI_GESTURE
}
