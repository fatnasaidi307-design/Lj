package com.ammaster.core

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive

object JsonUtil {
    /** يستخرج أول كائن JSON من رد نموذج (يتجاوز أسوار ```json والنص الزائد). */
    fun extractObject(text: String): String? {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        return if (s in 0 until e) text.substring(s, e + 1) else null
    }
}

fun JsonObject.str(key: String): String = this[key]?.jsonPrimitive?.contentOrNull ?: ""
