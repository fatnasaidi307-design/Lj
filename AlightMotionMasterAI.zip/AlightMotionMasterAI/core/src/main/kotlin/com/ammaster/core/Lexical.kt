package com.ammaster.core

/**
 * تطبيع نصوص عربية/إنجليزية للبحث. يُستعمل عند الفهرسة وعند الاستعلام بالطريقة نفسها
 * (نسخة Python مطابقة في tools/validate_kb.py).
 */
object Lexical {
    private val diacritics = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val nonWord = Regex("[^\\p{L}\\p{N}]+")
    private val stop = setOf(
        "ما", "هو", "هي", "في", "من", "على", "الي", "عن", "مع", "كيف", "لماذا", "هل", "ان", "ال", "او", "و",
        "what", "is", "the", "how", "to", "of", "in", "and", "do", "my", "me", "can",
    )

    private fun mapChars(s: String): String = buildString {
        for (c in s) {
            append(
                when (c) {
                    'أ', 'إ', 'آ' -> 'ا'
                    'ى' -> 'ي'
                    'ة' -> 'ه'
                    else -> c
                },
            )
        }
    }

    fun normalize(s: String): String {
        val cleaned = nonWord.replace(mapChars(diacritics.replace(s.lowercase(), "")), " ")
        return cleaned.split(' ').filter { it.isNotEmpty() }.joinToString(" ") { w ->
            if (w.startsWith("ال") && w.length > 4) w.substring(2) else w
        }
    }

    fun tokens(query: String): List<String> =
        normalize(query).split(' ').filter { it.length >= 2 && it !in stop }.distinct().take(12)

    fun ftsQuery(tokens: List<String>): String = tokens.joinToString(" OR ") { "$it*" }

    fun score(entry: KnowledgeEntry, tokens: List<String>): Double {
        val title = normalize(entry.title)
        val keywords = normalize(entry.keywords)
        val body = normalize(entry.body)
        var s = 0.0
        for (t in tokens) {
            if (title.contains(t)) s += 3.0
            if (keywords.contains(t)) s += 2.0
            if (body.contains(t)) s += 1.0
        }
        return if (entry.status == KnowledgeStatus.VERIFIED) s else s * 0.8
    }
}
