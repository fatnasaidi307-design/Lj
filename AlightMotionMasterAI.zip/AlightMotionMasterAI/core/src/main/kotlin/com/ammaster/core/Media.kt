package com.ammaster.core

data class MediaItem(
    val uri: String,
    val kind: MediaKind,
    val name: String,
    val width: Int = 0,
    val height: Int = 0,
    val durationMs: Long = 0,
    val bucket: String = "",
    val sizeBytes: Long = 0,
    val dateAddedSec: Long = 0,
) {
    val orientation: String
        get() = when {
            width <= 0 || height <= 0 -> "unknown"
            width == height -> "square"
            height > width -> "portrait"
            else -> "landscape"
        }
}

/** عنصر مفهرس: تسميات بصرية (إنجليزية) بثقتها، تُستخرج على الجهاز دون رفع أي صورة. */
data class IndexedMedia(val item: MediaItem, val labels: Map<String, Float>)

interface AssetIndex {
    suspend fun upsert(media: IndexedMedia)
    suspend fun isIndexed(uri: String): Boolean
    suspend fun count(): Int
    suspend fun candidates(tokens: List<String>, limit: Int): List<IndexedMedia>
}

/** مكتبة وسائط الهاتف (MediaStore). */
interface MediaCatalog {
    suspend fun scan(): List<MediaItem>
    suspend fun newVideosSince(sinceMs: Long): List<MediaItem>
    suspend fun describe(uri: String): MediaItem?
    /** ينسخ المادة إلى ألبوم خاص بالمشروع (لا يمس الأصل) ويعيد URI النسخة. */
    suspend fun stage(runId: String, ordinal: Int, item: MediaItem): Result<String>
}

interface MediaLabeler {
    suspend fun labels(item: MediaItem): Result<Map<String, Float>>
}

interface FrameSource {
    suspend fun frameAt(videoUri: String, timeMs: Long): Result<Screenshot>
}
