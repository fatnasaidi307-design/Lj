package com.ammaster.core

import kotlinx.serialization.Serializable

@Serializable
enum class ApiFormat { OPENAI_COMPATIBLE, ANTHROPIC }

@Serializable
data class ApiProvider(
    val id: String,
    val name: String,
    val format: ApiFormat = ApiFormat.OPENAI_COMPATIBLE,
    val baseUrl: String,
    val endpoint: String = "",
    val apiKey: String = "",
    val model: String,
    val headers: Map<String, String> = emptyMap(),
    val supportsVision: Boolean = false,
    val timeoutMs: Int = 60_000,
)

@Serializable
data class ProviderSettings(
    val providers: List<ApiProvider> = emptyList(),
    val primaryId: String? = null,
    val fallbackId: String? = null,
)

interface ProviderStore {
    fun load(): ProviderSettings
    fun save(settings: ProviderSettings)
}

fun ApiProvider.resolvedEndpoint(): String {
    val e = endpoint.trim()
    if (e.isEmpty()) {
        return when (format) {
            ApiFormat.OPENAI_COMPATIBLE -> "/chat/completions"
            ApiFormat.ANTHROPIC -> "/v1/messages"
        }
    }
    return if (e.startsWith("/")) e else "/$e"
}

object HeaderText {
    fun parse(text: String): Map<String, String> =
        text.lines().mapNotNull { line ->
            val i = line.indexOf(':')
            if (i <= 0) null else line.substring(0, i).trim() to line.substring(i + 1).trim()
        }.filter { it.first.isNotEmpty() }.toMap()

    fun format(headers: Map<String, String>): String =
        headers.entries.joinToString("\n") { "${it.key}: ${it.value}" }
}
