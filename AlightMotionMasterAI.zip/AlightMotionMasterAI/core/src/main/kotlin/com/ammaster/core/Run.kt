package com.ammaster.core

import kotlinx.serialization.Serializable

@Serializable
enum class RunMode { PLAN_ONLY, ASSISTED, AUTONOMOUS }

@Serializable
enum class RunStatus { PLANNED, WAITING_ASSETS, READY, RUNNING, PAUSED, DONE, FAILED }

/** نقطة حفظ كاملة لمشروع: تكفي لاستئناف العمل بعد إغلاق التطبيق. */
@Serializable
data class RunState(
    val runId: String,
    val goal: String,
    val mode: RunMode,
    val plan: VideoPlan? = null,
    val issues: List<String> = emptyList(),
    val status: RunStatus,
    val stepIndex: Int = 0,
    val log: List<String> = emptyList(),
    val updatedAt: Long,
)

object RunLogic {
    /** الحالة المشتقة من الوضع وحالة المواد. لا تلمس RUNNING/DONE/FAILED/PAUSED. */
    fun statusFor(mode: RunMode, plan: VideoPlan?): RunStatus {
        if (mode == RunMode.PLAN_ONLY || plan == null) return RunStatus.PLANNED
        val pending = plan.assets.any { it.status == AssetStatus.UNRESOLVED || it.status == AssetStatus.MISSING }
        return if (pending) RunStatus.WAITING_ASSETS else RunStatus.READY
    }

    private fun isDerived(s: RunStatus) =
        s == RunStatus.PLANNED || s == RunStatus.WAITING_ASSETS || s == RunStatus.READY

    fun withAsset(state: RunState, assetId: String, status: AssetStatus, uri: String, now: Long): RunState {
        val plan = state.plan ?: return state
        if (plan.assets.none { it.id == assetId }) return state
        val newPlan = plan.copy(assets = plan.assets.map { if (it.id == assetId) it.copy(status = status, uri = uri) else it })
        val newStatus = if (isDerived(state.status)) statusFor(state.mode, newPlan) else state.status
        return state.copy(
            plan = newPlan, status = newStatus, updatedAt = now,
            log = state.log + "asset $assetId -> $status",
        )
    }

    fun withAssets(state: RunState, assets: List<AssetRequest>, now: Long, note: String): RunState {
        val plan = state.plan ?: return state
        val newPlan = plan.copy(assets = assets)
        val newStatus = if (isDerived(state.status)) statusFor(state.mode, newPlan) else state.status
        return state.copy(plan = newPlan, status = newStatus, updatedAt = now, log = state.log + note)
    }

    /** سطر EXPORT:<uri>|<name> يضيفه المنفّذ بعد التأكد من ظهور فيديو مُصدَّر جديد فعلاً. */
    fun exportedUri(state: RunState): String? =
        state.log.lastOrNull { it.startsWith("EXPORT:") }?.removePrefix("EXPORT:")?.substringBefore('|')

    fun withMode(state: RunState, mode: RunMode, now: Long): RunState {
        val newStatus = if (isDerived(state.status)) statusFor(mode, state.plan) else state.status
        return state.copy(mode = mode, status = newStatus, updatedAt = now, log = state.log + "mode -> $mode")
    }
}

enum class ActionKind {
    UI_GESTURE, TYPE_TEXT, OPEN_APP, READ_SCREEN, CREATE_PROJECT, IMPORT_MEDIA, EXPORT_VIDEO,
    DELETE_USER_FILE, OVERWRITE_EXISTING_PROJECT, PUBLISH_OR_SHARE, PURCHASE, UPLOAD_PRIVATE_MEDIA,
}

enum class Decision { ALLOW, ASK_USER, DENY }

/** سياسة الأمان: مستقلة عن أي منفذ، وكل منفذ مستقبلي يجب أن يستشيرها قبل أي إجراء. */
object SafetyPolicy {
    fun decide(mode: RunMode, kind: ActionKind, uploadConsent: Boolean = false): Decision {
        if (mode == RunMode.PLAN_ONLY) return Decision.DENY
        return when (kind) {
            ActionKind.DELETE_USER_FILE -> Decision.DENY
            ActionKind.OVERWRITE_EXISTING_PROJECT,
            ActionKind.PUBLISH_OR_SHARE,
            ActionKind.PURCHASE -> Decision.ASK_USER
            ActionKind.UPLOAD_PRIVATE_MEDIA -> if (uploadConsent) Decision.ALLOW else Decision.ASK_USER
            else -> Decision.ALLOW
        }
    }
}

interface VideoPlanner : ExpertModule {
    suspend fun plan(goal: String, knowledge: List<KnowledgeHit>): Result<VideoPlan>
}

interface RunStore {
    suspend fun save(state: RunState)
    suspend fun load(runId: String): RunState?
    suspend fun latestUnfinished(): RunState?
}
