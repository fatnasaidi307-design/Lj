package com.ammaster.core

/** حالة التنفيذ الحقيقية لكل وحدة: لا نُظهر شيئاً مكتملاً وهو غير مكتمل. */
enum class ImplStatus { IMPLEMENTED, PARTIAL, PLANNED }

data class ModuleInfo(
    val name: String,
    val status: ImplStatus,
    val summary: String,
    val missing: List<String> = emptyList(),
)

interface ExpertModule {
    val info: ModuleInfo
}
