package com.ammaster.core

import kotlin.test.Test
import kotlin.test.assertEquals

class AgentCoreTest {
    private val shot = Screenshot("b", 100, 200, 1000, 2000)

    @Test
    fun scalesActionsToDeviceCoordinates() {
        assertEquals(UiAction.Tap(100, 200), UiAction.Tap(10, 20).scaledToDevice(shot))
        assertEquals(UiAction.Swipe(0, 0, 500, 1000, 300), UiAction.Swipe(0, 0, 50, 100, 300).scaledToDevice(shot))
        assertEquals(UiAction.Back, UiAction.Back.scaledToDevice(shot))
    }

    @Test
    fun scalesNodesToImageCoordinates() {
        val n = shot.nodeToImage(UiNode("x", "", true, 100, 200, 300, 400))
        assertEquals(listOf(10, 20, 30, 40), listOf(n.left, n.top, n.right, n.bottom))
    }

    @Test
    fun kindsMapToPolicyCategories() {
        assertEquals(ActionKind.OPEN_APP, UiAction.OpenApp("p").kind())
        assertEquals(ActionKind.TYPE_TEXT, UiAction.TypeText("t").kind())
        assertEquals(ActionKind.UI_GESTURE, UiAction.Tap(1, 1).kind())
    }
}
