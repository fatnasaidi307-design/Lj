package com.ammaster.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class CoreTest {
    @Test
    fun normalizesArabic() {
        assertEquals("انيميشن", Lexical.normalize("الأنيميشن"))
        assertEquals("حركه", Lexical.normalize("حَرَكَة"))
    }

    @Test
    fun tokensDropStopWords() {
        assertEquals(listOf("اضيف", "null", "object"), Lexical.tokens("كيف أضيف Null Object؟"))
    }

    @Test
    fun ftsQueryUsesPrefixOr() {
        assertEquals("easing* OR curve*", Lexical.ftsQuery(listOf("easing", "curve")))
    }

    @Test
    fun titleMatchBeatsBodyMatch() {
        val a = KnowledgeEntry("a", "c", "easing curve", "x", status = KnowledgeStatus.VERIFIED)
        val b = KnowledgeEntry("b", "c", "other", "easing curve", status = KnowledgeStatus.VERIFIED)
        val t = Lexical.tokens("easing")
        assertTrue(Lexical.score(a, t) > Lexical.score(b, t))
    }

    @Test
    fun unverifiedScoresLower() {
        val v = KnowledgeEntry("v", "c", "easing", "x", status = KnowledgeStatus.VERIFIED)
        val u = v.copy(key = "u", status = KnowledgeStatus.UNVERIFIED)
        val t = Lexical.tokens("easing")
        assertTrue(Lexical.score(v, t) > Lexical.score(u, t))
    }

    @Test
    fun headerTextRoundTrip() {
        val m = HeaderText.parse("X-A: 1\nbad line\nX-B: two: parts")
        assertEquals(mapOf("X-A" to "1", "X-B" to "two: parts"), m)
        assertEquals(m, HeaderText.parse(HeaderText.format(m)))
    }

    @Test
    fun extractsJsonFromFencedReply() {
        val j = JsonUtil.extractObject("here:\n```json\n{\"a\":1}\n```")
        assertEquals("{\"a\":1}", j)
        assertNull(JsonUtil.extractObject("no json"))
    }

    @Test
    fun resolvedEndpointDefaults() {
        val p = ApiProvider("1", "n", baseUrl = "u", model = "m")
        assertEquals("/chat/completions", p.resolvedEndpoint())
        assertEquals("/v1/messages", p.copy(format = ApiFormat.ANTHROPIC).resolvedEndpoint())
        assertEquals("/custom", p.copy(endpoint = "custom").resolvedEndpoint())
        assertNotNull(p)
    }
}
