package com.ammaster.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class PlanTest {
    private fun plan(
        shots: List<Shot> = listOf(Shot("s1", 0, 3000, assetId = "a1", text = "مرحبا")),
        assets: List<AssetRequest> = listOf(AssetRequest("a1", MediaKind.IMAGE, "قرية مغربية")),
        total: Long = 6000,
    ) = VideoPlan("t", totalDurationMs = total, scenes = listOf(Scene("sc1", "intro", shots)), assets = assets)

    @Test
    fun validPlanHasNoErrors() {
        assertFalse(PlanValidator.hasErrors(PlanValidator.validate(plan(), emptySet())))
    }

    @Test
    fun detectsStructuralErrors() {
        val bad = plan(shots = listOf(Shot("s1", 5000, 3000, assetId = "nope"), Shot("s1", 0, 0)), total = 6000)
        val msgs = PlanValidator.validate(bad, emptySet()).filter { it.severity == Severity.ERROR }.map { it.message }
        assertTrue(msgs.any { it.contains("ends after") })
        assertTrue(msgs.any { it.contains("unknown asset") })
        assertTrue(msgs.any { it.contains("duplicate shot") })
        assertTrue(msgs.any { it.contains("non-positive") })
    }

    @Test
    fun unknownEffectIsWarningNotError() {
        val p = plan(shots = listOf(Shot("s1", 0, 1000, effects = listOf(EffectSpec("Glow", "fx.glow")))), assets = emptyList())
        val issues = PlanValidator.validate(p, setOf("easing.what"))
        assertFalse(PlanValidator.hasErrors(issues))
        assertTrue(issues.any { it.severity == Severity.WARNING && it.message.contains("unverified") })
        val ok = PlanValidator.validate(p, setOf("fx.glow"))
        assertTrue(ok.none { it.message.contains("unverified") })
    }

    @Test
    fun decodesLenientJsonWithNumbersInParams() {
        val json = """{"title":"x","totalDurationMs":3000,"scenes":[{"id":"s","title":"t","shots":[
            {"id":"a","startMs":0,"durationMs":3000,"effects":[{"name":"Blur","params":{"amount":40}}],"extra":1}]}]}"""
        val p = PlanJson.decode(json)
        assertEquals("40", p.scenes[0].shots[0].effects[0].params["amount"])
        assertEquals(30, p.fps)
    }

    @Test
    fun runStatusFollowsAssetsAndMode() {
        val p = plan()
        assertEquals(RunStatus.PLANNED, RunLogic.statusFor(RunMode.PLAN_ONLY, p))
        assertEquals(RunStatus.WAITING_ASSETS, RunLogic.statusFor(RunMode.ASSISTED, p))
        val s0 = RunState("r", "g", RunMode.ASSISTED, p, status = RunStatus.WAITING_ASSETS, updatedAt = 0)
        val s1 = RunLogic.withAsset(s0, "a1", AssetStatus.USER_PROVIDED, "content://x", 1)
        assertEquals(RunStatus.READY, s1.status)
        assertEquals("content://x", s1.plan!!.assets[0].uri)
        assertEquals(RunStatus.PLANNED, RunLogic.withMode(s1, RunMode.PLAN_ONLY, 2).status)
    }

    @Test
    fun unknownAssetIdLeavesStateUntouched() {
        val s = RunState("r", "g", RunMode.ASSISTED, plan(), status = RunStatus.WAITING_ASSETS, updatedAt = 0)
        assertEquals(s, RunLogic.withAsset(s, "zzz", AssetStatus.USER_PROVIDED, "u", 5))
    }

    @Test
    fun runningStateIsNotRederived() {
        val s = RunState("r", "g", RunMode.ASSISTED, plan(), status = RunStatus.RUNNING, updatedAt = 0)
        assertEquals(RunStatus.RUNNING, RunLogic.withMode(s, RunMode.AUTONOMOUS, 1).status)
    }

    @Test
    fun safetyPolicy() {
        assertEquals(Decision.DENY, SafetyPolicy.decide(RunMode.PLAN_ONLY, ActionKind.UI_GESTURE))
        assertEquals(Decision.ALLOW, SafetyPolicy.decide(RunMode.AUTONOMOUS, ActionKind.UI_GESTURE))
        assertEquals(Decision.DENY, SafetyPolicy.decide(RunMode.AUTONOMOUS, ActionKind.DELETE_USER_FILE))
        assertEquals(Decision.ASK_USER, SafetyPolicy.decide(RunMode.AUTONOMOUS, ActionKind.OVERWRITE_EXISTING_PROJECT))
        assertEquals(Decision.ASK_USER, SafetyPolicy.decide(RunMode.AUTONOMOUS, ActionKind.PURCHASE))
        assertEquals(Decision.ASK_USER, SafetyPolicy.decide(RunMode.ASSISTED, ActionKind.UPLOAD_PRIVATE_MEDIA))
        assertEquals(Decision.ALLOW, SafetyPolicy.decide(RunMode.ASSISTED, ActionKind.UPLOAD_PRIVATE_MEDIA, uploadConsent = true))
    }

    @Test
    fun specTextHeaderDependsOnRealStatus() {
        val a = AssetRequest("a1", MediaKind.VIDEO, "شخص في مكتب", durationMs = 4000, searchKeywords = listOf("office", "مكتب"))
        assertTrue(a.specText().startsWith("المادة المطلوبة"))
        val m = a.copy(status = AssetStatus.MISSING, rejectedReasons = listOf("جودة ضعيفة"))
        assertTrue(m.specText().startsWith("MISSING ASSET"))
        assertTrue(m.specText().contains("جودة ضعيفة"))
        assertTrue(m.specText().contains("4.0 ث"))
    }
}
