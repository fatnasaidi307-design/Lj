package com.ammaster.llm

import com.ammaster.core.ApiProvider
import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ChatResponse
import com.ammaster.core.LlmClient
import com.ammaster.core.ProviderSettings

class HttpLlmClient(
    private val provider: ApiProvider,
    private val transport: HttpTransport = UrlConnectionTransport(),
) : LlmClient {
    override suspend fun chat(request: ChatRequest): Result<ChatResponse> = runCatching {
        require(provider.baseUrl.isNotBlank()) { "Base URL is empty" }
        require(provider.model.isNotBlank()) { "Model name is empty" }
        val hasImage = request.messages.any { it.imageJpegBase64 != null }
        check(!hasImage || provider.supportsVision) { "Provider '${provider.name}' is not marked as vision-capable" }
        val res = transport.post(
            ProtocolCodec.url(provider),
            ProtocolCodec.headers(provider),
            ProtocolCodec.body(provider, request),
            provider.timeoutMs,
        )
        if (res.code !in 200..299) error("HTTP ${res.code}: ${res.body.take(300)}")
        ChatResponse(ProtocolCodec.parse(provider, res.body), provider.name)
    }
}

/** يجرّب المزودين بالترتيب: الأساسي ثم الاحتياطي. */
class FallbackLlmClient(private val clients: List<LlmClient>) : LlmClient {
    override suspend fun chat(request: ChatRequest): Result<ChatResponse> {
        var last: Throwable? = null
        for (c in clients) {
            val r = c.chat(request)
            if (r.isSuccess) return r
            last = r.exceptionOrNull()
        }
        return Result.failure(last ?: IllegalStateException("No provider configured"))
    }
}

object LlmFactory {
    /** null إذا لم يُضف أي مزود. إن لم يُحدَّد أساسي يُستعمل أول مزود. */
    fun fromSettings(s: ProviderSettings, transport: HttpTransport = UrlConnectionTransport()): LlmClient? {
        val primary = s.providers.find { it.id == s.primaryId } ?: s.providers.firstOrNull() ?: return null
        val fallback = s.providers.find { it.id == s.fallbackId }
        val ordered = listOfNotNull(primary, fallback).distinctBy { it.id }
        return FallbackLlmClient(ordered.map { HttpLlmClient(it, transport) })
    }
}

data class ConnectionTestResult(val ok: Boolean, val latencyMs: Long, val message: String)

suspend fun testConnection(
    provider: ApiProvider,
    transport: HttpTransport = UrlConnectionTransport(),
): ConnectionTestResult {
    val start = System.currentTimeMillis()
    val r = HttpLlmClient(provider, transport).chat(
        ChatRequest(listOf(ChatMessage("user", "Reply with the single word: ok")), maxTokens = 16),
    )
    val ms = System.currentTimeMillis() - start
    return r.fold(
        onSuccess = { ConnectionTestResult(true, ms, it.text.take(80)) },
        onFailure = { ConnectionTestResult(false, ms, it.message ?: it.javaClass.simpleName) },
    )
}

/** يقرأ إعدادات المزودين عند كل طلب، فيتغيّر المزود فوراً دون إعادة بناء بقية التطبيق. */
class SettingsLlmClient(
    private val store: com.ammaster.core.ProviderStore,
    private val transport: HttpTransport = UrlConnectionTransport(),
) : LlmClient {
    override suspend fun chat(request: ChatRequest): Result<ChatResponse> {
        val client = LlmFactory.fromSettings(store.load(), transport)
            ?: return Result.failure(IllegalStateException("No API provider configured"))
        return client.chat(request)
    }
}
