package com.ammaster.llm

import com.ammaster.core.ApiFormat
import com.ammaster.core.ApiProvider
import com.ammaster.core.ChatRequest
import com.ammaster.core.resolvedEndpoint
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/** بناء الطلبات وتحليل الردود لبروتوكولين: OpenAI-compatible وAnthropic. دوال نقية قابلة للاختبار. */
object ProtocolCodec {
    const val ANTHROPIC_VERSION = "2023-06-01"

    fun url(p: ApiProvider): String = p.baseUrl.trim().trimEnd('/') + p.resolvedEndpoint()

    fun headers(p: ApiProvider): Map<String, String> {
        val h = linkedMapOf("Content-Type" to "application/json")
        when (p.format) {
            ApiFormat.OPENAI_COMPATIBLE -> if (p.apiKey.isNotBlank()) h["Authorization"] = "Bearer ${p.apiKey}"
            ApiFormat.ANTHROPIC -> {
                if (p.apiKey.isNotBlank()) h["x-api-key"] = p.apiKey
                h["anthropic-version"] = ANTHROPIC_VERSION
            }
        }
        h.putAll(p.headers)
        return h
    }

    fun body(p: ApiProvider, r: ChatRequest): String = when (p.format) {
        ApiFormat.OPENAI_COMPATIBLE -> openAiBody(p, r)
        ApiFormat.ANTHROPIC -> anthropicBody(p, r)
    }

    private fun openAiBody(p: ApiProvider, r: ChatRequest): String = buildJsonObject {
        put("model", p.model)
        put("max_tokens", r.maxTokens)
        r.temperature?.let { put("temperature", it) }
        putJsonArray("messages") {
            if (!r.system.isNullOrBlank()) {
                add(buildJsonObject {
                    put("role", "system")
                    put("content", r.system)
                })
            }
            r.messages.forEach { m ->
                add(buildJsonObject {
                    put("role", m.role)
                    if (m.imageJpegBase64 != null && p.supportsVision) {
                        putJsonArray("content") {
                            add(buildJsonObject {
                                put("type", "text")
                                put("text", m.text)
                            })
                            add(buildJsonObject {
                                put("type", "image_url")
                                putJsonObject("image_url") {
                                    put("url", "data:image/jpeg;base64,${m.imageJpegBase64}")
                                }
                            })
                        }
                    } else {
                        put("content", m.text)
                    }
                })
            }
        }
    }.toString()

    private fun anthropicBody(p: ApiProvider, r: ChatRequest): String = buildJsonObject {
        put("model", p.model)
        put("max_tokens", r.maxTokens)
        if (!r.system.isNullOrBlank()) put("system", r.system)
        r.temperature?.let { put("temperature", it) }
        putJsonArray("messages") {
            r.messages.forEach { m ->
                add(buildJsonObject {
                    put("role", m.role)
                    putJsonArray("content") {
                        if (m.imageJpegBase64 != null) {
                            add(buildJsonObject {
                                put("type", "image")
                                putJsonObject("source") {
                                    put("type", "base64")
                                    put("media_type", "image/jpeg")
                                    put("data", m.imageJpegBase64)
                                }
                            })
                        }
                        add(buildJsonObject {
                            put("type", "text")
                            put("text", m.text)
                        })
                    }
                })
            }
        }
    }.toString()

    fun parse(p: ApiProvider, body: String): String {
        val root = Json.parseToJsonElement(body).jsonObject
        return when (p.format) {
            ApiFormat.OPENAI_COMPATIBLE -> {
                val content = root["choices"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("message")?.jsonObject?.get("content")
                when (content) {
                    null, is JsonNull -> error("Empty reply from provider")
                    is JsonArray -> content.joinToString("") { it.jsonObject["text"]?.jsonPrimitive?.contentOrNull ?: "" }
                    is JsonPrimitive -> content.content
                    else -> error("Unexpected reply shape")
                }
            }
            ApiFormat.ANTHROPIC -> {
                val parts = root["content"]?.jsonArray?.mapNotNull { it.jsonObject["text"]?.jsonPrimitive?.contentOrNull }
                    ?: error("Empty reply from provider")
                parts.joinToString("")
            }
        }
    }
}
