package com.ammaster.llm

import com.ammaster.core.ApiFormat
import com.ammaster.core.ApiProvider
import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ProviderSettings
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class FakeTransport(private val code: Int = 200, private val responseBody: String) : HttpTransport {
    var lastUrl = ""
    var lastHeaders: Map<String, String> = emptyMap()
    var lastBody = ""
    override suspend fun post(url: String, headers: Map<String, String>, body: String, timeoutMs: Int): HttpResult {
        lastUrl = url
        lastHeaders = headers
        lastBody = body
        return HttpResult(code, responseBody)
    }
}

class LlmTest {
    private val openai = ApiProvider("o", "OpenAI-like", baseUrl = "https://x.test/v1/", model = "m1", apiKey = "K")
    private val anthropic = ApiProvider(
        "a", "Anthropic", ApiFormat.ANTHROPIC, "https://api.anthropic.com", model = "m2", apiKey = "K2",
    )
    private val req = ChatRequest(listOf(ChatMessage("user", "hi")), system = "sys")

    @Test
    fun openAiRequestAndParse() = runBlocking {
        val t = FakeTransport(responseBody = """{"choices":[{"message":{"content":"hello"}}]}""")
        val r = HttpLlmClient(openai, t).chat(req).getOrThrow()
        assertEquals("hello", r.text)
        assertEquals("https://x.test/v1/chat/completions", t.lastUrl)
        assertEquals("Bearer K", t.lastHeaders["Authorization"])
        assertTrue(t.lastBody.contains("\"model\":\"m1\""))
        assertTrue(t.lastBody.contains("\"role\":\"system\""))
    }

    @Test
    fun anthropicRequestAndParse() = runBlocking {
        val t = FakeTransport(responseBody = """{"content":[{"type":"text","text":"hi there"}]}""")
        val r = HttpLlmClient(anthropic, t).chat(req).getOrThrow()
        assertEquals("hi there", r.text)
        assertEquals("https://api.anthropic.com/v1/messages", t.lastUrl)
        assertEquals("K2", t.lastHeaders["x-api-key"])
        assertEquals(ProtocolCodec.ANTHROPIC_VERSION, t.lastHeaders["anthropic-version"])
        assertTrue(t.lastBody.contains("\"system\":\"sys\""))
    }

    @Test
    fun customHeadersAreMerged() {
        val h = ProtocolCodec.headers(openai.copy(headers = mapOf("X-Org" to "7")))
        assertEquals("7", h["X-Org"])
        assertEquals("application/json", h["Content-Type"])
    }

    @Test
    fun imageNeedsVisionProvider() = runBlocking {
        val withImage = ChatRequest(listOf(ChatMessage("user", "look", "AAAA")))
        val t = FakeTransport(responseBody = "{}")
        assertTrue(HttpLlmClient(openai, t).chat(withImage).isFailure)
        val v = openai.copy(supportsVision = true)
        val t2 = FakeTransport(responseBody = """{"choices":[{"message":{"content":"ok"}}]}""")
        assertTrue(HttpLlmClient(v, t2).chat(withImage).isSuccess)
        assertTrue(t2.lastBody.contains("data:image/jpeg;base64,AAAA"))
    }

    @Test
    fun httpErrorIsFailure() = runBlocking {
        val t = FakeTransport(code = 401, responseBody = "unauthorized")
        val r = HttpLlmClient(openai, t).chat(req)
        assertTrue(r.isFailure)
        assertTrue(r.exceptionOrNull()!!.message!!.contains("401"))
    }

    @Test
    fun fallbackUsesSecondProviderWhenFirstFails() = runBlocking {
        val bad = HttpLlmClient(openai, FakeTransport(500, "boom"))
        val good = HttpLlmClient(
            anthropic,
            FakeTransport(responseBody = """{"content":[{"type":"text","text":"from backup"}]}"""),
        )
        val r = FallbackLlmClient(listOf(bad, good)).chat(req).getOrThrow()
        assertEquals("from backup", r.text)
        assertEquals("Anthropic", r.providerName)
    }

    @Test
    fun factoryReturnsNullWithoutProviders() {
        assertEquals(null, LlmFactory.fromSettings(ProviderSettings()))
        assertFalse(LlmFactory.fromSettings(ProviderSettings(listOf(openai))) == null)
    }

    @Test
    fun connectionTestReportsFailure() = runBlocking {
        val r = testConnection(openai, FakeTransport(403, "nope"))
        assertFalse(r.ok)
        assertTrue(r.message.contains("403"))
    }
}
