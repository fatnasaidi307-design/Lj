package com.ammaster.llm

import com.ammaster.core.ApiProvider
import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ProviderSettings
import com.ammaster.core.ProviderStore
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SettingsClientTest {
    private class MemStore(var s: ProviderSettings = ProviderSettings()) : ProviderStore {
        override fun load() = s
        override fun save(settings: ProviderSettings) { s = settings }
    }

    private val req = ChatRequest(listOf(ChatMessage("user", "hi")))

    @Test
    fun failsWithoutProviderThenPicksUpNewSettingsImmediately() = runBlocking {
        val store = MemStore()
        val t = FakeTransport(responseBody = """{"choices":[{"message":{"content":"yo"}}]}""")
        val client = SettingsLlmClient(store, t)
        assertTrue(client.chat(req).isFailure)
        store.save(ProviderSettings(listOf(ApiProvider("p", "P", baseUrl = "https://h.test", model = "m"))))
        assertEquals("yo", client.chat(req).getOrThrow().text)
    }
}
