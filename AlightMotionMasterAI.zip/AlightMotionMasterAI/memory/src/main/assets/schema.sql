CREATE TABLE knowledge (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  keywords TEXT NOT NULL DEFAULT '',
  source_url TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'unverified',
  verified_at TEXT NOT NULL DEFAULT '',
  origin TEXT NOT NULL DEFAULT 'learned',
  updated_at INTEGER NOT NULL
);
CREATE VIRTUAL TABLE knowledge_fts USING fts4(title, body, keywords);
CREATE TABLE experience (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  goal TEXT NOT NULL,
  outcome TEXT NOT NULL,
  score INTEGER NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE TABLE meta (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL
);
