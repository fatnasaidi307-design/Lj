package com.ammaster.memory

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.ammaster.core.ProviderSettings
import com.ammaster.core.ProviderStore
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * يحفظ إعدادات المزودين (بما فيها مفاتيح API) مشفّرة عبر Android Keystore.
 * إن فشل إنشاء التشفير على جهاز ما، يُستعمل تخزين خاص بالتطبيق غير مشفّر، و[isEncrypted] يخبرك بذلك.
 */
class PrefsProviderStore(context: Context) : ProviderStore {
    private val json = Json { ignoreUnknownKeys = true }
    private val encrypted: Boolean
    private val prefs: SharedPreferences

    init {
        var enc = true
        val p = try {
            val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                context, "providers_enc", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        } catch (t: Throwable) {
            enc = false
            context.getSharedPreferences("providers_plain", Context.MODE_PRIVATE)
        }
        prefs = p
        encrypted = enc
    }

    val isEncrypted: Boolean get() = encrypted

    override fun load(): ProviderSettings {
        val raw = prefs.getString(KEY, null) ?: return ProviderSettings()
        return try {
            json.decodeFromString(ProviderSettings.serializer(), raw)
        } catch (t: Throwable) {
            ProviderSettings()
        }
    }

    override fun save(settings: ProviderSettings) {
        prefs.edit().putString(KEY, json.encodeToString(ProviderSettings.serializer(), settings)).apply()
    }

    private companion object {
        const val KEY = "settings_json"
    }
}
