package com.ammaster.memory

import android.content.ContentValues
import com.ammaster.core.AssetIndex
import com.ammaster.core.IndexedMedia
import com.ammaster.core.Lexical
import com.ammaster.core.MediaItem
import com.ammaster.core.MediaKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** فهرس بصري محلي للصور والفيديوهات: اسم + ألبوم + تسميات الصورة، مع بحث FTS4. */
class SqliteAssetIndex(private val helper: MemoryDb) : AssetIndex {

    override suspend fun upsert(media: IndexedMedia) {
        withContext(Dispatchers.IO) {
            val db = helper.writableDatabase
            db.beginTransaction()
            try {
                var id = -1L
                db.rawQuery("SELECT id FROM asset_index WHERE uri = ?", arrayOf(media.item.uri)).use {
                    if (it.moveToFirst()) id = it.getLong(0)
                }
                val labelsText = encodeLabels(media.labels)
                val cv = ContentValues().apply {
                    put("uri", media.item.uri)
                    put("kind", media.item.kind.name)
                    put("name", media.item.name)
                    put("width", media.item.width)
                    put("height", media.item.height)
                    put("duration_ms", media.item.durationMs)
                    put("bucket", media.item.bucket)
                    put("size_bytes", media.item.sizeBytes)
                    put("date_added", media.item.dateAddedSec)
                    put("labels", labelsText)
                    put("indexed_at", System.currentTimeMillis())
                }
                if (id == -1L) id = db.insertOrThrow("asset_index", null, cv)
                else db.update("asset_index", cv, "id = ?", arrayOf(id.toString()))
                db.delete("asset_fts", "docid = ?", arrayOf(id.toString()))
                val f = ContentValues().apply {
                    put("docid", id)
                    put("name", Lexical.normalize(media.item.name))
                    put("labels", Lexical.normalize(media.labels.keys.joinToString(" ")))
                    put("bucket", Lexical.normalize(media.item.bucket))
                }
                db.insertOrThrow("asset_fts", null, f)
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }
    }

    override suspend fun isIndexed(uri: String): Boolean = withContext(Dispatchers.IO) {
        helper.readableDatabase.rawQuery("SELECT 1 FROM asset_index WHERE uri = ?", arrayOf(uri)).use { it.moveToFirst() }
    }

    override suspend fun count(): Int = withContext(Dispatchers.IO) {
        helper.readableDatabase.rawQuery("SELECT COUNT(*) FROM asset_index", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    }

    override suspend fun candidates(tokens: List<String>, limit: Int): List<IndexedMedia> = withContext(Dispatchers.IO) {
        if (tokens.isEmpty()) return@withContext emptyList()
        val db = helper.readableDatabase
        val ids = LinkedHashSet<Long>()
        db.rawQuery(
            "SELECT docid FROM asset_fts WHERE asset_fts MATCH ? LIMIT ?",
            arrayOf(Lexical.ftsQuery(tokens), limit.toString()),
        ).use { c -> while (c.moveToNext()) ids.add(c.getLong(0)) }
        if (ids.isEmpty()) return@withContext emptyList()
        val out = ArrayList<IndexedMedia>()
        db.rawQuery(
            "SELECT uri,kind,name,width,height,duration_ms,bucket,size_bytes,date_added,labels FROM asset_index WHERE id IN (${ids.joinToString(",")})",
            null,
        ).use { c ->
            while (c.moveToNext()) {
                val item = MediaItem(
                    uri = c.getString(0), kind = MediaKind.valueOf(c.getString(1)), name = c.getString(2),
                    width = c.getInt(3), height = c.getInt(4), durationMs = c.getLong(5), bucket = c.getString(6),
                    sizeBytes = c.getLong(7), dateAddedSec = c.getLong(8),
                )
                out.add(IndexedMedia(item, decodeLabels(c.getString(9))))
            }
        }
        out
    }

    companion object {
        fun encodeLabels(m: Map<String, Float>): String = m.entries.joinToString(";") { "${it.key.replace(';', ' ').replace(':', ' ')}:${it.value}" }

        fun decodeLabels(s: String): Map<String, Float> {
            val out = LinkedHashMap<String, Float>()
            for (part in s.split(';')) {
                val i = part.lastIndexOf(':')
                if (i <= 0) continue
                val v = part.substring(i + 1).toFloatOrNull() ?: continue
                out[part.substring(0, i)] = v
            }
            return out
        }
    }
}
