package com.ammaster.memory

import android.content.ContentValues
import android.content.Context
import com.ammaster.core.Experience
import com.ammaster.core.ImplStatus
import com.ammaster.core.KnowledgeEntry
import com.ammaster.core.KnowledgeHit
import com.ammaster.core.Lexical
import com.ammaster.core.MemoryStore
import com.ammaster.core.ModuleInfo
import com.ammaster.core.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

class SqliteMemoryStore(
    private val context: Context,
    private val helper: MemoryDb = MemoryDb(context),
) : MemoryStore {

    override val info = ModuleInfo(
        name = "MEMORY",
        status = ImplStatus.PARTIAL,
        summary = "موسوعة SQLite قابلة للتحديث مع بحث نصي (FTS4) وتطبيع عربي، وجدول خبرات.",
        missing = listOf(
            "البحث الدلالي بالـ Embeddings غير منجز بعد (البحث الحالي نصي)",
            "الواجهة لا تسجّل الخبرات تلقائياً بعد (لا توجد حلقة تنفيذ بعد)",
            "تغطية الموسوعة أولية: صفحتان رسميتان فقط حتى الآن",
        ),
    )

    private val colsKnowledge = "id,key,category,title,body,keywords,source_url,status,verified_at"

    override suspend fun searchKnowledge(query: String, limit: Int): List<KnowledgeHit> = withContext(Dispatchers.IO) {
        val tokens = Lexical.tokens(query)
        if (tokens.isEmpty()) return@withContext emptyList()
        val db = helper.readableDatabase
        val ids = LinkedHashSet<Long>()
        db.rawQuery(
            "SELECT docid FROM knowledge_fts WHERE knowledge_fts MATCH ? LIMIT 80",
            arrayOf(Lexical.ftsQuery(tokens)),
        ).use { c -> while (c.moveToNext()) ids.add(c.getLong(0)) }
        if (ids.isEmpty()) return@withContext emptyList()
        val hits = ArrayList<KnowledgeHit>()
        db.rawQuery("SELECT $colsKnowledge FROM knowledge WHERE id IN (${ids.joinToString(",")})", null).use { c ->
            while (c.moveToNext()) {
                val e = KnowledgeEntry(
                    key = c.getString(1), category = c.getString(2), title = c.getString(3), body = c.getString(4),
                    keywords = c.getString(5), sourceUrl = c.getString(6), status = c.getString(7),
                    verifiedAt = c.getString(8),
                )
                hits.add(KnowledgeHit(e, Lexical.score(e, tokens)))
            }
        }
        hits.sortedByDescending { it.score }.take(limit)
    }

    override suspend fun listKnowledge(limit: Int): List<KnowledgeEntry> = withContext(Dispatchers.IO) {
        val out = ArrayList<KnowledgeEntry>()
        helper.readableDatabase.rawQuery(
            "SELECT $colsKnowledge FROM knowledge ORDER BY category, key LIMIT ?",
            arrayOf(limit.toString()),
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    KnowledgeEntry(
                        key = c.getString(1), category = c.getString(2), title = c.getString(3), body = c.getString(4),
                        keywords = c.getString(5), sourceUrl = c.getString(6), status = c.getString(7),
                        verifiedAt = c.getString(8),
                    ),
                )
            }
        }
        out
    }

    override suspend fun upsertKnowledge(entry: KnowledgeEntry) = withContext(Dispatchers.IO) {
        upsert(entry, ORIGIN_LEARNED)
    }

    /** يُحدّث الإدخال حسب المفتاح. إدخالات origin=learned لا يستبدلها البذر أبداً. */
    internal fun upsert(entry: KnowledgeEntry, origin: String) {
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            var id = -1L
            var existingOrigin = ""
            db.rawQuery("SELECT id, origin FROM knowledge WHERE key = ?", arrayOf(entry.key)).use {
                if (it.moveToFirst()) {
                    id = it.getLong(0)
                    existingOrigin = it.getString(1)
                }
            }
            if (id != -1L && existingOrigin == ORIGIN_LEARNED && origin == ORIGIN_SEED) {
                db.setTransactionSuccessful()
                return
            }
            val cv = ContentValues().apply {
                put("key", entry.key)
                put("category", entry.category)
                put("title", entry.title)
                put("body", entry.body)
                put("keywords", entry.keywords)
                put("source_url", entry.sourceUrl)
                put("status", entry.status)
                put("verified_at", entry.verifiedAt)
                put("origin", origin)
                put("updated_at", System.currentTimeMillis())
            }
            if (id == -1L) id = db.insertOrThrow("knowledge", null, cv)
            else db.update("knowledge", cv, "id = ?", arrayOf(id.toString()))
            db.delete("knowledge_fts", "docid = ?", arrayOf(id.toString()))
            val f = ContentValues().apply {
                put("docid", id)
                put("title", Lexical.normalize(entry.title))
                put("body", Lexical.normalize(entry.body))
                put("keywords", Lexical.normalize(entry.keywords))
            }
            db.insertOrThrow("knowledge_fts", null, f)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    override suspend fun knowledgeCount(): Int = withContext(Dispatchers.IO) {
        helper.readableDatabase.rawQuery("SELECT COUNT(*) FROM knowledge", null).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }
    }

    override suspend fun saveExperience(experience: Experience): Long = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            put("goal", experience.goal)
            put("outcome", experience.outcome)
            put("score", experience.score)
            put("notes", experience.notes)
            put("created_at", experience.createdAt)
        }
        helper.writableDatabase.insertOrThrow("experience", null, cv)
    }

    override suspend fun recentExperiences(limit: Int): List<Experience> = withContext(Dispatchers.IO) {
        val out = ArrayList<Experience>()
        helper.readableDatabase.rawQuery(
            "SELECT id, goal, outcome, score, notes, created_at FROM experience ORDER BY created_at DESC LIMIT ?",
            arrayOf(limit.toString()),
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Experience(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getString(4), c.getLong(5)))
            }
        }
        out
    }

    /** يحمّل assets/kb_seed.json إن كان إصداره أحدث من المخزَّن. يرجع true إذا حدّث شيئاً. */
    suspend fun seedIfNeeded(): Boolean = withContext(Dispatchers.IO) {
        val text = context.assets.open("kb_seed.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = Json.parseToJsonElement(text).jsonObject
        val version = root["seed_version"]!!.jsonPrimitive.int
        val current = getMeta("seed_version")?.toIntOrNull() ?: 0
        if (version <= current) return@withContext false
        root["entries"]!!.jsonArray.forEach { el ->
            val o = el.jsonObject
            upsert(
                KnowledgeEntry(
                    key = o.str("key"), category = o.str("category"), title = o.str("title"), body = o.str("body"),
                    keywords = o.str("keywords"), sourceUrl = o.str("source_url"),
                    status = o.str("status").ifEmpty { "unverified" }, verifiedAt = o.str("verified_at"),
                ),
                ORIGIN_SEED,
            )
        }
        setMeta("seed_version", version.toString())
        true
    }

    private fun getMeta(k: String): String? =
        helper.readableDatabase.rawQuery("SELECT v FROM meta WHERE k = ?", arrayOf(k)).use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    private fun setMeta(k: String, v: String) {
        val cv = ContentValues().apply {
            put("k", k)
            put("v", v)
        }
        helper.writableDatabase.insertWithOnConflict("meta", null, cv, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE)
    }

    companion object {
        const val ORIGIN_SEED = "seed"
        const val ORIGIN_LEARNED = "learned"
    }
}
