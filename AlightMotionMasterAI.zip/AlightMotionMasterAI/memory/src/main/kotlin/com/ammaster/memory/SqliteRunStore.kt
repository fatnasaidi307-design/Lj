package com.ammaster.memory

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import com.ammaster.core.PlanJson
import com.ammaster.core.RunState
import com.ammaster.core.RunStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** يحفظ نقطة الحفظ كاملة كـ JSON، فيستأنف المشروع من آخر حالة بعد إغلاق التطبيق. */
class SqliteRunStore(private val helper: MemoryDb) : RunStore {

    override suspend fun save(state: RunState) {
        withContext(Dispatchers.IO) {
            val cv = ContentValues().apply {
                put("run_id", state.runId)
                put("status", state.status.name)
                put("json", PlanJson.json.encodeToString(RunState.serializer(), state))
                put("updated_at", state.updatedAt)
            }
            helper.writableDatabase.insertWithOnConflict("run_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        }
    }

    override suspend fun load(runId: String): RunState? = withContext(Dispatchers.IO) {
        queryOne("SELECT json FROM run_state WHERE run_id = ?", arrayOf(runId))
    }

    override suspend fun latestUnfinished(): RunState? = withContext(Dispatchers.IO) {
        queryOne(
            "SELECT json FROM run_state WHERE status NOT IN ('DONE','FAILED') ORDER BY updated_at DESC LIMIT 1",
            null,
        )
    }

    private fun queryOne(sql: String, args: Array<String>?): RunState? {
        val raw = helper.readableDatabase.rawQuery(sql, args).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: return null
        return try {
            PlanJson.json.decodeFromString(RunState.serializer(), raw)
        } catch (t: Throwable) {
            null
        }
    }
}
