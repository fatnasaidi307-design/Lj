package com.ammaster.operator

import android.accessibilityservice.AccessibilityService
import android.graphics.Path
import com.ammaster.core.ImplStatus
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Operator
import com.ammaster.core.Screenshot
import com.ammaster.core.UiAction
import com.ammaster.core.UiNode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class AccessibilityOperator : Operator {
    override val info = ModuleInfo(
        name = "OPERATOR",
        status = ImplStatus.PARTIAL,
        summary = "لمس وسحب وكتابة ورجوع وفتح Alight Motion ولقطة شاشة وشجرة عناصر عبر خدمة الوصول (Android 11+).",
        missing = listOf(
            "اللقطة نجحت على هاتفك؛ اللمس والكتابة وفتح التطبيق ما زالت تحتاج اختباراً على الهاتف",
            "يفتح تطبيق Alight Motion فقط (قائمة سماح)",
            "لوحة Alight Motion الرسومية لا تعرض عناصرها لخدمة الوصول، فالتحكم سيكون بالإحداثيات",
        ),
    )

    override suspend fun isReady(): Boolean = AlightAccessibilityService.instance != null

    override suspend fun screenshot(): Result<Screenshot> = runCatching {
        val svc = AlightAccessibilityService.instance ?: error(NOT_ENABLED)
        svc.capture()
    }

    override suspend fun uiNodes(): List<UiNode> = withContext(Dispatchers.Default) {
        AlightAccessibilityService.instance?.dumpNodes() ?: emptyList()
    }

    override suspend fun perform(action: UiAction): Result<Unit> = runCatching {
        val svc = AlightAccessibilityService.instance ?: error(NOT_ENABLED)
        when (action) {
            is UiAction.Tap -> svc.gesture(point(action.x, action.y), 50)
            is UiAction.LongPress -> svc.gesture(point(action.x, action.y), action.durationMs)
            is UiAction.Swipe -> svc.gesture(
                Path().apply {
                    moveTo(action.x1.toFloat(), action.y1.toFloat())
                    lineTo(action.x2.toFloat(), action.y2.toFloat())
                },
                action.durationMs,
            )
            UiAction.Back -> check(svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)) { "Back action failed" }
            is UiAction.Wait -> delay(action.ms)
            is UiAction.TypeText -> check(svc.typeText(action.text)) { "No focused text field to type into" }
            is UiAction.OpenApp -> {
                check(action.packageName in ALLOWED_PACKAGES) { "App is not on the allow list" }
                check(svc.openApp(action.packageName)) { "App is not installed or cannot be launched" }
            }
        }
    }

    private fun point(x: Int, y: Int) = Path().apply { moveTo(x.toFloat(), y.toFloat()) }

    private companion object {
        const val NOT_ENABLED = "Accessibility service is not enabled"
        val ALLOWED_PACKAGES = setOf("com.alightcreative.motion")
    }
}
