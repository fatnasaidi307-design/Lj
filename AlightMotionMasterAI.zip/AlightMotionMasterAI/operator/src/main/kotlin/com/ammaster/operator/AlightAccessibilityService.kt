package com.ammaster.operator

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.ammaster.core.Screenshot
import com.ammaster.core.UiNode
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** الخدمة لا تفعل شيئاً من تلقاء نفسها: تنفّذ فقط ما يطلبه AccessibilityOperator. */
class AlightAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    /** عناصر النافذة الحالية التي لها نص/وصف أو قابلة للنقر (إحداثيات الشاشة الحقيقية). */
    fun dumpNodes(): List<UiNode> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = ArrayList<UiNode>()
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (out.size >= MAX_NODES || depth > 25) return
            val text = n.text?.toString().orEmpty()
            val desc = n.contentDescription?.toString().orEmpty()
            if ((text.isNotEmpty() || desc.isNotEmpty() || n.isClickable) && n.isVisibleToUser) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) {
                    out.add(
                        UiNode(
                            text.take(60), desc.take(60), n.isClickable, r.left, r.top, r.right, r.bottom,
                            n.className?.toString().orEmpty().substringAfterLast('.'),
                        ),
                    )
                }
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c, depth + 1)
            }
        }
        walk(root, 0)
        return out
    }

    /** يكتب في الحقل النصي الذي عليه التركيز (يستبدل محتواه). */
    fun typeText(text: String): Boolean {
        val node = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun openApp(packageName: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    suspend fun gesture(path: Path, durationMs: Long) = suspendCancellableCoroutine<Unit> { cont ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1)))
            .build()
        val accepted = dispatchGesture(
            g,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(Unit)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resumeWithException(IllegalStateException("Gesture was cancelled"))
                }
            },
            null,
        )
        if (!accepted && cont.isActive) cont.resumeWithException(IllegalStateException("Gesture was rejected"))
    }

    /** يلتقط الشاشة (Android 11+) ويصغّرها إلى 1280px كحد أقصى ويضغطها JPEG. */
    suspend fun capture(): Screenshot = suspendCancellableCoroutine { cont ->
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val buffer = result.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                            ?: throw IllegalStateException("wrapHardwareBuffer returned null")
                        val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                            ?: throw IllegalStateException("Bitmap copy failed")
                        buffer.close()
                        val scale = minOf(1f, MAX_SIDE / maxOf(soft.width, soft.height).toFloat())
                        val out = if (scale < 1f) {
                            Bitmap.createScaledBitmap(soft, (soft.width * scale).toInt(), (soft.height * scale).toInt(), true)
                        } else {
                            soft
                        }
                        val bos = ByteArrayOutputStream()
                        out.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                        val shot = Screenshot(
                            Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP),
                            out.width, out.height, soft.width, soft.height,
                        )
                        if (cont.isActive) cont.resume(shot)
                    } catch (t: Throwable) {
                        if (cont.isActive) cont.resumeWithException(t)
                    }
                }

                override fun onFailure(errorCode: Int) {
                    if (cont.isActive) {
                        cont.resumeWithException(IllegalStateException("takeScreenshot failed, error code $errorCode"))
                    }
                }
            },
        )
    }

    companion object {
        @Volatile
        var instance: AlightAccessibilityService? = null
            private set

        private const val MAX_SIDE = 1280f
        private const val MAX_NODES = 80
    }
}
