package com.ammaster.planner

import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ExpertRules
import com.ammaster.core.ImplStatus
import com.ammaster.core.JsonUtil
import com.ammaster.core.KnowledgeHit
import com.ammaster.core.LlmClient
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Plan
import com.ammaster.core.PlanStep
import com.ammaster.core.Planner
import com.ammaster.core.str
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject

class LlmPlanner(private val llm: LlmClient) : Planner {
    override val info = ModuleInfo(
        name = "PLANNER",
        status = ImplStatus.IMPLEMENTED,
        summary = "يحوّل الهدف إلى خطوات نصية مرتبة اعتماداً على الموسوعة المحلية.",
        missing = listOf("لا يولّد إحداثيات أو إجراءات لمس؛ هذا ضمن مرحلة التنفيذ الآلي"),
    )

    override suspend fun plan(goal: String, knowledge: List<KnowledgeHit>): Result<Plan> {
        val kb = if (knowledge.isEmpty()) "(none)" else knowledge.joinToString("\n") {
            "- [${it.entry.status}] ${it.entry.title}: ${it.entry.body}"
        }
        val user = "Goal:\n$goal\n\nKnowledge entries:\n$kb"
        return llm.chat(ChatRequest(listOf(ChatMessage("user", user)), SYSTEM, 1500, 0.2))
            .mapCatching { parsePlan(goal, it.text) }
    }

    companion object {
        val SYSTEM: String = ExpertRules.FACT_RULES + "\n\n" + """
            Task: break the user's goal into 3-10 ordered, concrete steps for editing in Alight Motion.
            Reply with JSON only, no prose: {"steps":[{"title":"...","technique":"...","details":"..."}]}
            - "technique": name an Alight Motion feature ONLY if it appears in the knowledge entries; otherwise leave it empty.
            - "details": prefix with [UNVERIFIED] any step that depends on unverified or missing knowledge.
        """.trimIndent()

        fun parsePlan(goal: String, text: String): Plan {
            val json = JsonUtil.extractObject(text) ?: error("Planner reply has no JSON object")
            val steps = Json.parseToJsonElement(json).jsonObject["steps"]?.jsonArray?.map { s ->
                val o = s.jsonObject
                PlanStep(o.str("title"), o.str("technique"), o.str("details"))
            } ?: error("Planner reply has no steps")
            require(steps.isNotEmpty()) { "Planner returned an empty plan" }
            return Plan(goal, steps)
        }
    }
}
