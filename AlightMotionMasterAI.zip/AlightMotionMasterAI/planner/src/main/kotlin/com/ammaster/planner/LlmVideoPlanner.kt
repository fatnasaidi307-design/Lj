package com.ammaster.planner

import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ExpertRules
import com.ammaster.core.ImplStatus
import com.ammaster.core.JsonUtil
import com.ammaster.core.KnowledgeHit
import com.ammaster.core.LlmClient
import com.ammaster.core.ModuleInfo
import com.ammaster.core.PlanJson
import com.ammaster.core.PlanValidator
import com.ammaster.core.Severity
import com.ammaster.core.VideoPlan
import com.ammaster.core.VideoPlanner

/** مخطط بيانات قابلة للتنفيذ: مشاهد ولقطات بتوقيت دقيق ومواد مطلوبة، مع تحقق وإعادة محاولة واحدة. */
class LlmVideoPlanner(private val llm: LlmClient) : VideoPlanner {
    override val info = ModuleInfo(
        name = "VIDEO PLANNER",
        status = ImplStatus.IMPLEMENTED,
        summary = "يحوّل فكرة المونتاج إلى خطة JSON منظمة (مشاهد، لقطات، توقيت، مواد، تأثيرات، طبقات) ويتحقق منها.",
        missing = listOf(
            "لا يبحث عن المواد بنفسه بعد (ASSET MANAGER في خطوة لاحقة): كل المواد تبدأ بحالة غير محلولة",
            "التأثيرات التي لا توجد في الموسوعة تُعلَّم غير موثّقة",
        ),
    )

    override suspend fun plan(goal: String, knowledge: List<KnowledgeHit>): Result<VideoPlan> {
        val kb = if (knowledge.isEmpty()) "(none)" else knowledge.joinToString("\n") {
            "- key=${it.entry.key} [${it.entry.status}] ${it.entry.title}: ${it.entry.body}"
        }
        val keys = knowledge.map { it.entry.key }.toSet()
        var feedback = ""
        var lastError: Throwable? = null
        for (attempt in 1..2) {
            val user = "Goal:\n$goal\n\nKnowledge entries (use the key as kbKey):\n$kb$feedback"
            val reply = llm.chat(ChatRequest(listOf(ChatMessage("user", user)), SYSTEM, 3500, 0.2))
            val parsed = reply.mapCatching { parsePlan(it.text) }
            if (parsed.isSuccess) {
                val plan = parsed.getOrThrow()
                val errors = PlanValidator.validate(plan, keys).filter { it.severity == Severity.ERROR }
                if (errors.isEmpty()) return Result.success(plan)
                val list = errors.joinToString("\n") { "- ${it.message}" }
                feedback = "\n\nYour previous reply had these errors. Fix them and reply with the full JSON again:\n$list"
                lastError = IllegalStateException("Invalid plan: ${errors.first().message}")
            } else {
                lastError = parsed.exceptionOrNull()
                feedback = "\n\nYour previous reply could not be parsed (${lastError?.message}). Reply with valid JSON only."
            }
        }
        return Result.failure(lastError ?: IllegalStateException("Video planner failed"))
    }

    companion object {
        val SYSTEM: String = ExpertRules.FACT_RULES + "\n\n" + """
            Task: turn the user's video idea into an executable edit plan for Alight Motion.
            Reply with ONE JSON object only, no prose, using exactly this shape (all times in milliseconds):
            {"title":"","aspectRatio":"9:16","fps":30,"totalDurationMs":0,
             "scenes":[{"id":"sc1","title":"","shots":[
               {"id":"sh1","startMs":0,"durationMs":0,"assetId":"a1","text":"",
                "effects":[{"name":"","kbKey":"","params":{}}],
                "transition":{"name":"","kbKey":"","durationMs":0},
                "layerOrder":["background","subject","text"],"notes":""}]}],
             "assets":[{"id":"a1","kind":"IMAGE","description":"","orientation":"portrait|landscape|square|any",
                "minWidth":0,"minHeight":0,"durationMs":0,"cameraAngle":"","background":"",
                "needsTransparency":false,"searchKeywords":["arabic","english"]}]}
            Rules:
            - shot startMs is absolute on the timeline; shots must stay within totalDurationMs; one shot per clip/image.
            - every shot that shows media references an assetId defined in "assets"; describe each asset precisely.
            - "kind" is IMAGE or VIDEO; for VIDEO set durationMs.
            - kbKey must be the key of a provided knowledge entry. If an effect or transition is not in the entries, leave kbKey empty and explain in notes; never invent parameter values.
            - Do NOT set asset status or uri; never claim an asset exists.
            - Write texts in the language of the goal (Arabic text for Arabic goals).
            - searchKeywords: include both Arabic and English terms.
        """.trimIndent()

        fun parsePlan(text: String): VideoPlan {
            val json = JsonUtil.extractObject(text) ?: error("Planner reply has no JSON object")
            return PlanJson.decode(json)
        }
    }
}
