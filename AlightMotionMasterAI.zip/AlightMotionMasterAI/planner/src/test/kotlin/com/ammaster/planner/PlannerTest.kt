package com.ammaster.planner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class PlannerTest {
    @Test
    fun parsesFencedJson() {
        val text = "Sure:\n```json\n{\"steps\":[{\"title\":\"A\",\"technique\":\"Keyframes\",\"details\":\"d\"},{\"title\":\"B\"}]}\n```"
        val plan = LlmPlanner.parsePlan("goal", text)
        assertEquals(2, plan.steps.size)
        assertEquals("Keyframes", plan.steps[0].technique)
        assertEquals("", plan.steps[1].details)
    }

    @Test
    fun rejectsEmptyOrMissing() {
        assertFailsWith<IllegalArgumentException> { LlmPlanner.parsePlan("g", "{\"steps\":[]}") }
        assertFailsWith<IllegalStateException> { LlmPlanner.parsePlan("g", "no json") }
        assertFailsWith<IllegalStateException> { LlmPlanner.parsePlan("g", "{\"x\":1}") }
    }
}
