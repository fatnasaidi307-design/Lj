package com.ammaster.planner

import com.ammaster.core.ChatRequest
import com.ammaster.core.ChatResponse
import com.ammaster.core.KnowledgeEntry
import com.ammaster.core.KnowledgeHit
import com.ammaster.core.LlmClient
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class VideoPlannerTest {
    private val good = """{"title":"قرية","totalDurationMs":3000,"scenes":[{"id":"s","title":"t","shots":[
        {"id":"a","startMs":0,"durationMs":3000,"assetId":"a1"}]}],
        "assets":[{"id":"a1","kind":"IMAGE","description":"قرية مغربية"}]}"""
    private val badTiming = good.replace("\"durationMs\":3000,\"assetId\"", "\"durationMs\":9000,\"assetId\"")

    private class Scripted(private val replies: List<String>) : LlmClient {
        var calls = 0
        val prompts = mutableListOf<String>()
        override suspend fun chat(request: ChatRequest): Result<ChatResponse> {
            prompts.add(request.messages[0].text)
            return Result.success(ChatResponse(replies[minOf(calls++, replies.size - 1)]))
        }
    }

    private val hits = listOf(KnowledgeHit(KnowledgeEntry("k1", "c", "Easing", "body"), 1.0))

    @Test
    fun acceptsValidPlanFirstTime() = runBlocking {
        val llm = Scripted(listOf("```json\n$good\n```"))
        val plan = LlmVideoPlanner(llm).plan("فيديو عن قرية", hits).getOrThrow()
        assertEquals("a1", plan.assets[0].id)
        assertEquals(1, llm.calls)
        assertTrue(llm.prompts[0].contains("key=k1"))
    }

    @Test
    fun retriesOnceWithValidationFeedback() = runBlocking {
        val llm = Scripted(listOf(badTiming, good))
        val plan = LlmVideoPlanner(llm).plan("x", hits).getOrThrow()
        assertEquals(3000, plan.scenes[0].shots[0].durationMs)
        assertEquals(2, llm.calls)
        assertTrue(llm.prompts[1].contains("ends after totalDurationMs"))
    }

    @Test
    fun failsAfterTwoBadReplies() = runBlocking {
        val llm = Scripted(listOf("not json", "still not json"))
        assertTrue(LlmVideoPlanner(llm).plan("x", hits).isFailure)
        assertEquals(2, llm.calls)
    }
}
