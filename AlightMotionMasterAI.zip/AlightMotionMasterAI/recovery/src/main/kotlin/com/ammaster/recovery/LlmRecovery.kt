package com.ammaster.recovery

import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ExpertRules
import com.ammaster.core.Failure
import com.ammaster.core.ImplStatus
import com.ammaster.core.JsonUtil
import com.ammaster.core.KnowledgeHit
import com.ammaster.core.LlmClient
import com.ammaster.core.ModuleInfo
import com.ammaster.core.PlanStep
import com.ammaster.core.Recovery
import com.ammaster.core.RecoveryDecision
import com.ammaster.core.str
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject

class LlmRecovery(private val llm: LlmClient, private val maxAttempts: Int = 3) : Recovery {
    override val info = ModuleInfo(
        name = "RECOVERY",
        status = ImplStatus.PARTIAL,
        summary = "يقرر بعد فشل خطوة: إعادة المحاولة بتعديل، أو بديل، أو الاستسلام بعد حد المحاولات.",
        missing = listOf("غير مربوط بحلقة تنفيذ بعد (يحتاج Operator يعمل فعلياً)"),
    )

    override suspend fun decide(failure: Failure, knowledge: List<KnowledgeHit>): Result<RecoveryDecision> {
        if (failure.attempt >= maxAttempts) {
            return Result.success(RecoveryDecision.GiveUp("Reached $maxAttempts attempts"))
        }
        val kb = if (knowledge.isEmpty()) "(none)" else knowledge.joinToString("\n") {
            "- [${it.entry.status}] ${it.entry.title}: ${it.entry.body}"
        }
        val user = buildString {
            append("A step failed.\nStep: ${failure.step?.title ?: "(unknown)"}\n")
            append("Details: ${failure.step?.details ?: ""}\nError: ${failure.message}\n")
            append("Attempt: ${failure.attempt} of $maxAttempts\n\nKnowledge entries:\n$kb")
        }
        return llm.chat(ChatRequest(listOf(ChatMessage("user", user)), SYSTEM, 700, 0.2))
            .mapCatching { parse(it.text) }
    }

    companion object {
        val SYSTEM: String = ExpertRules.FACT_RULES + "\n\n" + """
            Task: decide how to recover from the failed step.
            Reply with JSON only: {"decision":"retry|alternative|give_up","title":"","technique":"","details":""}
            - retry: "details" = the adjusted instructions for the same step.
            - alternative: provide a new step (title, technique only if in the knowledge entries, details).
            - give_up: "details" = the reason.
        """.trimIndent()

        fun parse(text: String): RecoveryDecision {
            val json = JsonUtil.extractObject(text) ?: error("Recovery reply has no JSON object")
            val root = Json.parseToJsonElement(json).jsonObject
            return when (root.str("decision").lowercase()) {
                "retry" -> RecoveryDecision.Retry(root.str("details"))
                "alternative" -> RecoveryDecision.Alternative(
                    PlanStep(root.str("title"), root.str("technique"), root.str("details")),
                )
                "give_up" -> RecoveryDecision.GiveUp(root.str("details"))
                else -> error("Unknown recovery decision")
            }
        }
    }
}
