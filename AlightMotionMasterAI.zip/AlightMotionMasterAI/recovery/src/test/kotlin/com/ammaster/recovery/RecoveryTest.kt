package com.ammaster.recovery

import com.ammaster.core.ChatRequest
import com.ammaster.core.ChatResponse
import com.ammaster.core.Failure
import com.ammaster.core.LlmClient
import com.ammaster.core.RecoveryDecision
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class RecoveryTest {
    private val neverCalled = object : LlmClient {
        override suspend fun chat(request: ChatRequest): Result<ChatResponse> = error("LLM must not be called")
    }

    @Test
    fun givesUpAtMaxAttemptsWithoutCallingModel() = runBlocking {
        val d = LlmRecovery(neverCalled, maxAttempts = 3).decide(Failure(null, "x", 3), emptyList()).getOrThrow()
        assertTrue(d is RecoveryDecision.GiveUp)
    }

    @Test
    fun parsesDecisions() {
        assertEquals(RecoveryDecision.Retry("slower"), LlmRecovery.parse("{\"decision\":\"retry\",\"details\":\"slower\"}"))
        val alt = LlmRecovery.parse("{\"decision\":\"alternative\",\"title\":\"T\",\"details\":\"D\"}")
        assertTrue(alt is RecoveryDecision.Alternative && alt.newStep.title == "T")
        assertTrue(LlmRecovery.parse("{\"decision\":\"give_up\",\"details\":\"r\"}") is RecoveryDecision.GiveUp)
        assertFailsWith<IllegalStateException> { LlmRecovery.parse("{\"decision\":\"dance\"}") }
    }
}
