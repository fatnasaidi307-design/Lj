package com.ammaster.reviewer

import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ImplStatus
import com.ammaster.core.JsonUtil
import com.ammaster.core.LlmClient
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Review
import com.ammaster.core.Reviewer
import com.ammaster.core.Screenshot
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

class LlmReviewer(private val llm: LlmClient, private val passThreshold: Int = 80) : Reviewer {
    override val info = ModuleInfo(
        name = "REVIEWER",
        status = ImplStatus.PARTIAL,
        summary = "يقيّم لقطة شاشة مقابل النتيجة المتوقعة بدرجة 0-100 وقائمة عيوب واقتراحات.",
        missing = listOf(
            "يقيّم لقطة ثابتة فقط؛ لا يشغّل المعاينة ولا يراقب الحركة عبر الزمن بعد",
            "غير مربوط بحلقة التنفيذ بعد",
        ),
    )

    override suspend fun review(goal: String, expected: String, shot: Screenshot): Result<Review> {
        val user = "Goal: $goal\nExpected visual result: $expected\nEvaluate the screenshot against the expected result."
        return llm.chat(ChatRequest(listOf(ChatMessage("user", user, shot.jpegBase64)), SYSTEM, 800, 0.1))
            .mapCatching { parse(it.text, passThreshold) }
    }

    companion object {
        const val SYSTEM = "You are a strict quality reviewer for Alight Motion edits. Judge only what is visible in the " +
            "screenshot. Reply with JSON only: {\"score\":0-100,\"issues\":[\"...\"],\"suggestions\":[\"...\"]}. " +
            "Do not claim to see motion or timing from a single still frame."

        fun parse(text: String, threshold: Int): Review {
            val json = JsonUtil.extractObject(text) ?: error("Reviewer reply has no JSON object")
            val root = Json.parseToJsonElement(json).jsonObject
            val raw = root["score"]?.jsonPrimitive?.doubleOrNull ?: error("Reviewer reply has no numeric score")
            val score = raw.toInt().coerceIn(0, 100)
            fun list(key: String) = root[key]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull } ?: emptyList()
            return Review(score, score >= threshold, list("issues"), list("suggestions"))
        }
    }
}
