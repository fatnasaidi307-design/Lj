package com.ammaster.reviewer

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ReviewerTest {
    @Test
    fun passesAtThreshold() {
        val r = LlmReviewer.parse("{\"score\":85,\"issues\":[],\"suggestions\":[\"x\"]}", 80)
        assertTrue(r.passed)
        assertEquals(listOf("x"), r.suggestions)
    }

    @Test
    fun failsBelowThresholdAndClamps() {
        val r = LlmReviewer.parse("```json\n{\"score\":142.5,\"issues\":[\"blur\"]}\n```", 150)
        assertEquals(100, r.score)
        assertFalse(r.passed)
        assertEquals(listOf("blur"), r.issues)
    }

    @Test
    fun missingScoreIsError() {
        assertFailsWith<IllegalStateException> { LlmReviewer.parse("{\"issues\":[]}", 80) }
    }
}
