#!/usr/bin/env python3
"""يولّد memory/src/main/assets/kb_seed.json من القائمة أدناه.
لإضافة معرفة جديدة: أضف إدخالاً هنا (مع source_url رسمي إن كان status=verified) ثم ارفع seed_version.
لا تضع status=verified إلا لما قُرئ فعلاً من مصدر رسمي."""
import json, pathlib

EASING = "https://support.alightmotion.com/hc/en-us/articles/10536934703889-Animation-Easing-Curves"
PARENT = "https://support.alightmotion.com/hc/en-us/articles/10536997444369-Layer-Parenting-and-Null-Objects"
DATE = "2026-11-16"

def v(key, category, title, body, keywords, src):
    return dict(key=key, category=category, title=title, body=body, keywords=keywords,
                source_url=src, status="verified", verified_at=DATE)

entries = [
 v("easing.what", "keyframes_easing", "ما هو الـ Easing (التسهيل) في Alight Motion",
   "الـ Easing هو تسارع الحركة وتباطؤها تدريجياً بدل الحركة بسرعة ثابتة. الحركة بسرعة ثابتة تسمى Linear وتبدو غير طبيعية لأنها لا تشبه حركة الأشياء في الواقع. يمكن تطبيق الـ Easing على أي خاصية تدعم الـ Keyframes، ومنها الموقع والحجم والدوران واللون والشفافية.",
   "easing linear ease keyframes curve تسهيل ايزينج منحنى حركة سلسة", EASING),
 v("easing.common_types", "keyframes_easing", "أنواع Easing الشائعة: Ease-in وEase-out وEase-in-out",
   "Ease-in: تبدأ الحركة ببطء ثم تتسارع، وتناسب العناصر التي تغادر الشاشة. Ease-out: تتباطأ الحركة تدريجياً حتى تتوقف، وتناسب العناصر التي تدخل الشاشة. Ease-in-out: تبدأ ببطء ثم تتسارع ثم تتباطأ حتى التوقف، وتناسب انتقال عنصر من مكان إلى آخر على الشاشة.",
   "ease-in ease-out ease-in-out easing دخول خروج تسارع تباطؤ", EASING),
 v("easing.how_to", "keyframes_easing", "خطوات تعديل منحنى Easing بين Keyframes",
   "1) أضف Keyframesين على الأقل للخاصية الحالية. الـ Keyframes التي تخص الخاصية الحالية تظهر كماسات بيضاء مصمتة بحدود داكنة؛ أما الباهتة بلا حدود فتخص خاصية أخرى (مثلاً Keyframes دوران بينما الخاصية المحددة هي الحجم)، فغيّر الخاصية أولاً. 2) افتح Curve Editor من الأيقونة المخصصة. 3) حرّك مؤشر التشغيل (Playhead) بين الـ Keyframesين ليظهر المنحنى. 4) اختر نمطاً جاهزاً من الأزرار على اليمين أو اسحب المقبضين البيضاء لضبط المنحنى يدوياً. في المنحنى: المحور X هو زمن المشروع الأصلي، والمحور Y هو الزمن المعاد تخطيطه المطبّق على الحركة؛ وسرعة الحركة تحددها ميل المنحنى (الميل الأشد يعني حركة أسرع).",
   "curve editor easing keyframes playhead preset handles محرر المنحنى منحنى مقبض خطوات", EASING),
 v("easing.multiple_keyframes", "keyframes_easing", "منحنى Easing مستقل بين كل زوج Keyframes",
   "عند وجود أكثر من Keyframesين يوجد منحنى Easing مستقل بين كل زوج متتالٍ، وعدد المنحنيات يساوي عدد الـ Keyframes ناقص واحد. مثال: ثلاث Keyframes تعني منحنيين.",
   "keyframes easing curves multiple عدد المنحنيات", EASING),
 v("easing.advanced_types", "keyframes_easing", "أنواع Easing المتقدمة: Bounce وElastic وCyclic وRandom وSteps",
   "إضافة إلى منحنيات Cubic Bezier القياسية ذات المقبضين توجد أنواع متقدمة. Bounce: ارتداد كأن الجاذبية تجذب القيمة نحو القيمة النهائية. Elastic: يتجاوز القيمة النهائية بسرعة ثم يستقر كنابض محرَّر. Cyclic: يكرر التقدم بين القيمة الأولى والأخيرة، ذهاباً وإياباً أو باتجاه واحد. Random: عشوائية مضبوطة تشبه الحركة البراونية. Steps: حركة بخطوات منفصلة بدل السلاسة، تشبه مؤثر Time Quantization لكن بتحكم أكبر ويمكن تطبيقها على خاصية واحدة بدل الطبقة كلها. Elastic Steps: خطوات مع ارتداد مرن عند كل خطوة.",
   "bounce elastic cyclic random steps elastic steps time quantization ارتداد مطاطي ارتداد دوري عشوائي خطوات", EASING),
 v("easing.overshoot", "keyframes_easing", "تفعيل Overshoot لتجاوز قيم الـ Keyframes",
   "افتراضياً يبقى منحنى الـ Easing داخل الخطوط المنقطة كي لا تتجاوز الحركة قيم الـ Keyframes المجاورة. لتجاوزها عمداً (مثل حركة الترقب Anticipation أو الارتداد): افتح Curve Editor، اضغط ••• أسفل اليمين لفتح القائمة، اختر Enable Overshoot، ثم اسحب المقبضين خارج الخطوط المنقطة. للعودة للوضع الافتراضي عطّل Overshoot من القائمة نفسها.",
   "overshoot anticipation enable overshoot curve editor تجاوز ترقب", EASING),
 v("easing.copy_paste_curve", "keyframes_easing", "نسخ منحنى Easing ولصقه (Copy Curve / Paste Curve)",
   "لإعادة استعمال منحنى على زوج Keyframes آخر في الطبقة نفسها أو طبقة أخرى: افتح Curve Editor، اضغط •••، اختر Copy Curve، ثم انتقل إلى زوج آخر وافتح Curve Editor له، اضغط •••، واختر Paste Curve. الخيار Paste Curve to All Keyframes يلصق المنحنى على كل أزواج الـ Keyframes في الخاصية المحددة فقط، ولا يؤثر في الخصائص أو الطبقات الأخرى.",
   "copy curve paste curve paste curve to all keyframes نسخ لصق منحنى", EASING),
 v("parenting.overview", "layers_parenting", "Layer Parenting: علاقة أب وابن بين الطبقات",
   "الـ Layer Parenting يُنشئ علاقة أب-ابن بين طبقتين: تؤثر الطبقة الأب في موضع الطبقة الابن ودورانها وحجمها.",
   "parenting parent child layer ربط طبقات اب ابن", PARENT),
 v("null.add", "layers_parenting", "إضافة Null Object في Alight Motion",
   "الـ Null Object طبقة غير مرئية تعمل جيداً مع الـ Parenting وتعطي مستوى تحكم إضافياً في الحركة. إضافته على iPhone وAndroid: Add Layer ثم Object ثم Null. على iPad: تبويب Object ثم Null.",
   "null object add layer object null invisible layer طبقة غير مرئية اضافة نل", PARENT),
 v("null.use_cases", "layers_parenting", "متى نستعمل Null Object مع الـ Parenting",
   "حالتان موثّقتان: (1) عند الحاجة إلى توقيتات Keyframes مختلفة لمحاور منفصلة على طبقة، اجعل الطبقة ابناً لـ Null Object وحرّك محوراً واحداً على الـ Null. (2) لتطبيق تأثير حركة موحد على طبقتين أو أكثر مع بقاء إمكانية تحريكها كلٌّ على حدة، اجعلها أبناء لـ Null Object وطبّق تأثير الحركة على الـ Null.",
   "null object parenting axis motion effect multiple layers محور تأثير حركة عدة طبقات", PARENT),
]

out = pathlib.Path(__file__).resolve().parent.parent / "memory/src/main/assets/kb_seed.json"
out.write_text(json.dumps({"seed_version": 1, "entries": entries}, ensure_ascii=False, indent=1), encoding="utf-8")
print("wrote", out, len(entries), "entries")
