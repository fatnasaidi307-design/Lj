package com.ammaster.vision

import com.ammaster.core.ChatMessage
import com.ammaster.core.ChatRequest
import com.ammaster.core.ImplStatus
import com.ammaster.core.LlmClient
import com.ammaster.core.ModuleInfo
import com.ammaster.core.Observation
import com.ammaster.core.Screenshot
import com.ammaster.core.Vision

class LlmVision(private val llm: LlmClient) : Vision {
    override val info = ModuleInfo(
        name = "VISION",
        status = ImplStatus.PARTIAL,
        summary = "يرسل لقطة الشاشة إلى نموذج رؤية ويعيد وصفاً لما يظهر مع إحداثيات تقريبية.",
        missing = listOf(
            "لم تُضبط للتعرّف على عناصر Alight Motion بدقة",
            "يتطلب مزوداً يدعم الصور",
        ),
    )

    override suspend fun observe(shot: Screenshot, question: String): Result<Observation> {
        val system = "You analyze screenshots of the Alight Motion mobile app. Describe only what is visible. " +
            "Never guess names of tools or menu items that are not readable on screen; if text is unreadable, say so. " +
            "The image is ${shot.width}x${shot.height} pixels. When you mention a UI element, give its approximate " +
            "center as (x,y) in these pixel coordinates. Answer in the language of the question."
        return llm.chat(
            ChatRequest(listOf(ChatMessage("user", question, shot.jpegBase64)), system, 900, 0.1),
        ).map { Observation(it.text) }
    }
}
