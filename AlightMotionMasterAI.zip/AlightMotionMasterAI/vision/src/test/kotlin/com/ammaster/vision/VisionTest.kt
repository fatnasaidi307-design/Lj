package com.ammaster.vision

import com.ammaster.core.ChatRequest
import com.ammaster.core.ChatResponse
import com.ammaster.core.LlmClient
import com.ammaster.core.Screenshot
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class VisionTest {
    @Test
    fun sendsImageAndSizeToModel() = runBlocking {
        var captured: ChatRequest? = null
        val llm = object : LlmClient {
            override suspend fun chat(request: ChatRequest): Result<ChatResponse> {
                captured = request
                return Result.success(ChatResponse("a timeline"))
            }
        }
        val obs = LlmVision(llm).observe(Screenshot("B64", 720, 1600), "what is on screen?").getOrThrow()
        assertEquals("a timeline", obs.summary)
        assertEquals("B64", captured!!.messages[0].imageJpegBase64)
        assertTrue(captured!!.system!!.contains("720x1600"))
    }
}
