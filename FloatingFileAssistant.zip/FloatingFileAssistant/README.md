# ChatGPT Floating File Assistant (Android, Kotlin)

A floating bubble that lets you pick files while ChatGPT is open and hand them to the **official ChatGPT app**
through Android's standard share system (ACTION_SEND / ACTION_SEND_MULTIPLE, content:// URIs, temporary read grants).
No API key, no ChatGPT private APIs, no accessibility scraping, no upload of its own.

## Build the debug APK
**Option A – Android Studio (Koala 2024.1+ / JDK 17)**
1. File > Open > select this folder, wait for Gradle sync (it downloads Gradle 8.7 + dependencies).
2. Build > Build App Bundle(s) / APK(s) > Build APK(s).
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

**Option B – command line** (Android SDK + JDK 17 installed): `gradle wrapper --gradle-version 8.7` then `./gradlew assembleDebug`

**Option C – no PC setup**: push this folder to a GitHub repo, open Actions > "Build debug APK" > Run workflow,
then download the `app-debug-apk` artifact.

Install: `adb install -r app-debug.apk`, or copy the APK to the phone and allow "install unknown apps".

## First run (Realme / ColorOS)
1. Open the app > grant "display over other apps" and notifications > "Show floating bubble".
2. Settings > Apps > Special app access > Display over other apps (if the bubble does not appear).
3. Battery: set the app to Unrestricted; allow Auto-launch if you want it back after reboot.

## Test checklist (not yet run on a device by the author)
- Bubble stays above ChatGPT, drags, snaps to edge, menu opens instantly, Hide works.
- Add file / multiple files / folder (tick files manually) / Recent files.
- Large file (>1 GB): progress, Cancel, Retry, UI stays responsive.
- Corrupted PDF/ZIP/DOCX/JSON/XML/image are flagged and blocked from sending.
- ZIP: Contents, Extract (limit abort message), extracted files sent via FileProvider.
- Send: ChatGPT's share screen opens; confirm the conversation inside ChatGPT; if ChatGPT rejects the file, its own message applies.
- Reboot with "Restore bubble after restart" on.

## Limits (by design)
- The app can only confirm that Android launched ChatGPT's share screen, never that the upload finished.
- ChatGPT's file-size, format and plan limits are enforced by ChatGPT and cannot be bypassed.
- Sharing speed depends on storage, network and ChatGPT.
