package com.floatingfile.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (Prefs.restoreOnBoot(ctx) && Prefs.bubbleWanted(ctx) && Settings.canDrawOverlays(ctx)) {
            try { BubbleService.start(ctx) } catch (_: Exception) { /* OEM may block auto-start */ }
        }
    }
}
