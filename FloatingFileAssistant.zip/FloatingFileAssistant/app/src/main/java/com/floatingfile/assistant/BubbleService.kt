package com.floatingfile.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlin.math.hypot

class BubbleService : Service() {
    companion object {
        const val ACTION_STOP = "com.floatingfile.assistant.STOP"
        private const val CHANNEL = "bubble"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BubbleService::class.java))
        }

        fun stop(ctx: Context) {
            Prefs.setBubbleWanted(ctx, false)
            ctx.stopService(Intent(ctx, BubbleService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private var bubble: FrameLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var lastClosed = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundNow()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        Prefs.setBubbleWanted(this, true)
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setBubbleWanted(this, false)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating bubble", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val hide = PendingIntent.getService(
            this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_bubble)
            .setContentTitle("Floating bubble is active")
            .setContentText("Tap the bubble to share a file with ChatGPT")
            .setContentIntent(open)
            .addAction(0, "Hide bubble", hide)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun addBubble() {
        val ctx = this
        val size = dp(56)
        val v = FrameLayout(ctx)
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFF10A37F.toInt())
            setStroke(ctx.dp(2), Color.WHITE)
        }
        v.elevation = dp(6).toFloat()
        v.addView(TextView(ctx).apply {
            text = "📎"; textSize = 24f; gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(size, size))

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.bubbleX(ctx); y = Prefs.bubbleY(ctx)
        }
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop

        v.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx; val dy = e.rawY - ty
                        if (!moved && hypot(dx, dy) > slop) moved = true
                        if (moved) {
                            lp.x = (sx + dx).toInt(); lp.y = (sy + dy).toInt()
                            wm.updateViewLayout(v, lp)
                            closePanel()
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) snapAndSave(lp, v, size)
                        else if (panel != null) closePanel()
                        else if (SystemClock.uptimeMillis() - lastClosed > 400) openPanel()
                    }
                }
                return true
            }
        })
        wm.addView(v, lp)
        bubble = v
        bubbleLp = lp
    }

    private fun snapAndSave(lp: WindowManager.LayoutParams, v: View, size: Int) {
        val w = resources.displayMetrics.widthPixels
        lp.x = if (lp.x + size / 2 < w / 2) 0 else w - size
        lp.y = lp.y.coerceIn(0, resources.displayMetrics.heightPixels - size)
        wm.updateViewLayout(v, lp)
        Prefs.setBubblePos(this, lp.x, lp.y)
    }

    private fun openPanel() {
        val b = bubbleLp ?: return
        val svc = this
        val col = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(svc.dp(8), svc.dp(8), svc.dp(8), svc.dp(8))
            background = GradientDrawable().apply {
                cornerRadius = svc.dp(16).toFloat()
                setColor(0xFFFFFFFF.toInt())
                setStroke(svc.dp(1), 0xFFDDDDDD.toInt())
            }
            elevation = svc.dp(8).toFloat()
        }
        fun row(label: String, action: () -> Unit) {
            col.addView(TextView(svc).apply {
                text = label; textSize = 16f; setTextColor(0xFF111111.toInt())
                setPadding(svc.dp(12), svc.dp(12), svc.dp(12), svc.dp(12))
                setOnClickListener { closePanel(); action() }
            })
        }
        row("Add file") { picker(PickerActivity.SINGLE) }
        row("Add multiple files") { picker(PickerActivity.MULTI) }
        row("Select folder") { picker(PickerActivity.FOLDER) }
        row("Recent files") {
            startActivity(Intent(svc, ShareActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(ShareActivity.EXTRA_RECENT, true))
        }
        row("Settings") {
            startActivity(Intent(svc, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        row("Hide bubble") { Prefs.setBubbleWanted(svc, false); stopSelf() }

        val w = dp(220)
        val screenW = resources.displayMetrics.widthPixels
        val onLeft = b.x + dp(28) < screenW / 2
        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (onLeft) b.x + dp(64) else b.x - w - dp(8)
            y = b.y
        }
        col.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false
        }
        wm.addView(col, lp)
        panel = col
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        if (panel != null) lastClosed = SystemClock.uptimeMillis()
        panel = null
    }

    private fun picker(mode: String) {
        // Allowed from the background because this app currently shows an overlay window.
        startActivity(Intent(this, PickerActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(PickerActivity.EXTRA_MODE, mode))
    }

    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        bubble = null
        super.onDestroy()
    }
}
