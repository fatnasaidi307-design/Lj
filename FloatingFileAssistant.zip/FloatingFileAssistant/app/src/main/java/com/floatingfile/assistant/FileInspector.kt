package com.floatingfile.assistant

import android.content.Context
import android.graphics.BitmapFactory
import android.util.JsonReader
import android.util.JsonToken
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedReader
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.zip.ZipException
import java.util.zip.ZipInputStream

/**
 * Streams a file in configurable chunks (never loads it fully into RAM), computes SHA-256,
 * and checks basic structural validity. The original file is only ever opened read-only.
 */
object FileInspector {
    data class Result(val status: Status, val detail: String, val sha256: String?)

    private val BLOCKED = setOf("apk", "exe", "dll", "so", "dex", "iso", "dmg", "msi")
    private val ZIPLIKE = setOf("zip", "docx", "xlsx", "pptx", "odt", "ods", "odp", "epub")
    private val DOCS = setOf("pdf", "rtf")
    private val IMAGES = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "heic", "heif")
    private val STRICT_IMAGES = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp")
    private val TEXT = setOf(
        "txt", "csv", "tsv", "md", "json", "xml", "html", "htm", "css", "js", "ts", "tsx", "jsx",
        "kt", "java", "py", "c", "cpp", "h", "hpp", "cs", "go", "rs", "rb", "php", "sql", "yml",
        "yaml", "toml", "ini", "log", "sh", "swift", "dart", "r", "lua", "gradle", "properties"
    )
    private val KNOWN = ZIPLIKE + DOCS + IMAGES + TEXT

    /** Makes long parser loops cancellable. */
    private class ActiveStream(s: InputStream, val check: () -> Unit) : FilterInputStream(s) {
        override fun read(): Int { check(); return super.read() }
        override fun read(b: ByteArray, off: Int, len: Int): Int { check(); return super.read(b, off, len) }
    }

    suspend fun inspect(ctx: Context, item: Item, chunkBytes: Int, onProgress: (Int) -> Unit): Result =
        withContext(Dispatchers.IO) {
            val ext = item.ext
            if (ext in BLOCKED) {
                return@withContext Result(Status.ERROR, "Unsupported format (.$ext): ChatGPT does not accept executables or installers.", null)
            }
            val cr = ctx.contentResolver
            val buf = ByteArray(chunkBytes.coerceAtLeast(4096))
            val md = MessageDigest.getInstance("SHA-256")
            val head = ByteArray(8); var headLen = 0
            val tail = ByteArray(1024); var tailLen = 0
            var total = 0L
            var nul = false
            var first = true

            val stream = (try { cr.openInputStream(item.uri) } catch (_: Exception) { null })
                ?: return@withContext Result(Status.ERROR, "Cannot open the file (permission expired or file moved).", null)

            // ---- Pass 1: stream in chunks -> hash, header, tail ----
            stream.use { s ->
                while (true) {
                    ensureActive()
                    val n = s.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    md.update(buf, 0, n)
                    if (first) {
                        first = false
                        headLen = minOf(8, n)
                        System.arraycopy(buf, 0, head, 0, headLen)
                        for (i in 0 until minOf(n, 4096)) if (buf[i] == 0.toByte()) { nul = true; break }
                    }
                    if (n >= tail.size) {
                        System.arraycopy(buf, n - tail.size, tail, 0, tail.size); tailLen = tail.size
                    } else {
                        val keep = minOf(tailLen, tail.size - n)
                        System.arraycopy(tail, tailLen - keep, tail, 0, keep)
                        System.arraycopy(buf, 0, tail, keep, n)
                        tailLen = keep + n
                    }
                    total += n
                    if (item.size > 0) onProgress(((total * 100) / item.size).toInt().coerceAtMost(99))
                }
            }
            val hash = md.digest().joinToString("") { "%02x".format(it) }

            if (total == 0L) return@withContext Result(Status.ERROR, "The file is empty.", hash)
            if (item.size > 0 && total != item.size) {
                return@withContext Result(Status.ERROR,
                    "Read $total bytes but the file provider reports ${item.size}: the file may be truncated or corrupted.", hash)
            }

            var st = Status.OK
            var msg = "Readable (${formatSize(total)}), structure looks valid."
            fun warn(m: String) { if (st == Status.OK) { st = Status.WARNING; msg = m } }
            val headStr = String(head, 0, headLen, Charsets.ISO_8859_1)

            // ---- Format-specific validation (streaming, second pass) ----
            if (ext == "pdf" || headStr.startsWith("%PDF")) {
                if (!headStr.startsWith("%PDF-")) return@withContext Result(Status.ERROR, "Not a valid PDF (missing %PDF header).", hash)
                if (!String(tail, 0, tailLen, Charsets.ISO_8859_1).contains("%%EOF"))
                    warn("PDF has no end-of-file marker; it may be truncated.")
            }

            if (ext in ZIPLIKE) {
                if (!headStr.startsWith("PK")) {
                    return@withContext Result(Status.ERROR, "Not a valid .$ext file (missing ZIP signature).", hash)
                }
                var entries = 0
                var hasDocXml = false
                try {
                    val s2 = cr.openInputStream(item.uri) ?: throw IOException("Cannot reopen file")
                    ZipInputStream(ActiveStream(s2.buffered()) { ensureActive() }).use { z ->
                        while (true) {
                            val e = z.nextEntry ?: break
                            entries++
                            if (e.name == "word/document.xml") hasDocXml = true
                            while (z.read(buf) >= 0) { /* validates CRC/stream integrity */ }
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: ZipException) {
                    return@withContext Result(Status.ERROR, "Corrupted archive: ${e.message}", hash)
                } catch (e: IOException) {
                    return@withContext Result(Status.ERROR, "Archive is unreadable or truncated: ${e.message}", hash)
                }
                if (entries == 0) {
                    return@withContext if (ext == "zip") Result(Status.WARNING, "Archive contains no entries.", hash)
                    else Result(Status.ERROR, "Not a valid .$ext file (no archive entries).", hash)
                }
                if (ext == "docx" && !hasDocXml) warn("DOCX is missing word/document.xml; it may be damaged.")
                if (st == Status.OK) msg = "Valid archive, $entries entries."
            }

            if (ext == "json") {
                try {
                    val s2 = cr.openInputStream(item.uri) ?: throw IOException("Cannot reopen file")
                    val r = JsonReader(BufferedReader(InputStreamReader(ActiveStream(s2) { ensureActive() }, Charsets.UTF_8), 64 * 1024))
                    r.use { it.skipValue(); if (it.peek() != JsonToken.END_DOCUMENT) throw IOException("Unexpected data after JSON value") }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: IOException) {
                    return@withContext Result(Status.ERROR, "Invalid JSON: ${e.message}", hash)
                }
                if (st == Status.OK) msg = "Valid JSON."
            }

            if (ext == "xml") {
                try {
                    val s2 = cr.openInputStream(item.uri) ?: throw IOException("Cannot reopen file")
                    val p = XmlPullParserFactory.newInstance().newPullParser()
                    p.setInput(ActiveStream(s2.buffered()) { ensureActive() }, null)
                    while (p.next() != XmlPullParser.END_DOCUMENT) { /* well-formedness check */ }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: XmlPullParserException) {
                    return@withContext Result(Status.ERROR, "Invalid XML: ${e.message}", hash)
                } catch (e: IOException) {
                    return@withContext Result(Status.ERROR, "XML unreadable: ${e.message}", hash)
                }
                if (st == Status.OK) msg = "Well-formed XML."
            }

            if (ext in IMAGES) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                try {
                    cr.openInputStream(item.uri)?.use { BitmapFactory.decodeStream(ActiveStream(it) { ensureActive() }, null, o) }
                } catch (e: CancellationException) { throw e } catch (_: IOException) { }
                if (o.outWidth <= 0) {
                    val m = "Android could not read this image header; the file may be corrupted or in an unsupported image format."
                    if (ext in STRICT_IMAGES) return@withContext Result(Status.ERROR, m, hash) else warn(m)
                } else if (st == Status.OK) msg = "Image ${o.outWidth}×${o.outHeight}."
            }

            if (ext in TEXT && ext != "json" && ext != "xml" && nul) {
                warn("Contains NUL bytes: may be binary or UTF-16 text rather than plain text.")
            }

            if (ext !in KNOWN) {
                warn("Unrecognized format (${if (ext.isEmpty()) "no extension" else ".$ext"}); ChatGPT may reject it.")
            }

            Result(st, msg, hash)
        }
}
