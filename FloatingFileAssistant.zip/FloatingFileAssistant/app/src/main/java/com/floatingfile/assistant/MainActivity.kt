package com.floatingfile.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { updateStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(24))
        }
        fun text(t: String, size: Float = 14f) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, dp(4), 0, dp(8))
        }
        fun button(label: String, onClick: () -> Unit) = MaterialButton(this).apply {
            text = label; setOnClickListener { onClick() }
        }.also {
            col.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        }

        col.addView(text("Floating File Assistant", 24f))
        col.addView(text(
            "A floating bubble that hands files to the official ChatGPT app through Android's share system. " +
                "It is not a chatbot, uses no API key, and uploads nothing by itself."
        ))
        status = text("")
        col.addView(status)

        button("1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("2. Allow notifications (Android 13+)") {
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            else Toast.makeText(this, "Not needed on this Android version.", Toast.LENGTH_SHORT).show()
        }
        button("3. Show floating bubble") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant 'display over other apps' first.", Toast.LENGTH_LONG).show()
            } else BubbleService.start(this)
        }
        button("Hide floating bubble") { BubbleService.stop(this) }
        button("Open ChatGPT") {
            val i = packageManager.getLaunchIntentForPackage(ShareHelper.CHATGPT_PKG)
            if (i == null) Toast.makeText(this, "ChatGPT is not installed.", Toast.LENGTH_LONG).show() else startActivity(i)
        }
        button("Settings") { startActivity(Intent(this, SettingsActivity::class.java)) }

        col.addView(text(
            "\nRealme / ColorOS tips: Settings → Apps → Special app access → Display over other apps; " +
                "set this app's battery usage to Unrestricted; allow Auto-launch / Startup so the bubble can return after a reboot.\n\n" +
                "After you pick files, Android opens ChatGPT's share screen. Choosing the conversation may require confirmation " +
                "inside ChatGPT, and ChatGPT's own file-size, format and plan limits always apply."
        ))
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() { super.onResume(); updateStatus() }

    private fun updateStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val gpt = ShareHelper.chatGptInstalled(this)
        status.text = "Overlay permission: ${if (overlay) "granted ✔" else "not granted ✖"}\n" +
            "ChatGPT app: ${if (gpt) "installed ✔" else "not found ✖"}"
    }
}
