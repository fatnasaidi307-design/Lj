package com.floatingfile.assistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Invisible activity that opens the system file picker (Storage Access Framework), then hands off. */
class PickerActivity : ComponentActivity() {
    companion object {
        const val EXTRA_MODE = "mode"
        const val SINGLE = "single"
        const val MULTI = "multi"
        const val FOLDER = "folder"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val single = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
            done(listOfNotNull(u), true)
        }
        val multi = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
            done(l, true)
        }
        val tree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { t ->
            if (t == null) finish() else folder(t)
        }
        if (savedInstanceState == null) {
            when (intent.getStringExtra(EXTRA_MODE)) {
                MULTI -> multi.launch(arrayOf("*/*"))
                FOLDER -> tree.launch(null)
                else -> single.launch(arrayOf("*/*"))
            }
        }
    }

    private fun done(uris: List<Uri>, preselect: Boolean) {
        if (uris.isEmpty()) { finish(); return }
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { /* e.g. children of a tree grant */ }
        }
        startActivity(
            Intent(this, ShareActivity::class.java)
                .putParcelableArrayListExtra(ShareActivity.EXTRA_URIS, ArrayList(uris))
                .putExtra(ShareActivity.EXTRA_PRESELECT, preselect)
        )
        finish()
    }

    private fun folder(tree: Uri) {
        try {
            contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        lifecycleScope.launch {
            val files = withContext(Dispatchers.IO) { listChildren(tree) }
            if (files.isEmpty()) {
                Toast.makeText(this@PickerActivity, "No files in this folder (subfolders are not scanned).", Toast.LENGTH_LONG).show()
                finish()
            } else {
                // Nothing is pre-selected: the user must tick each file to share.
                done(files, false)
            }
        }
    }

    private fun listChildren(tree: Uri): List<Uri> {
        val out = ArrayList<Uri>()
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        contentResolver.query(
            children,
            arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_MIME_TYPE),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                if (c.getString(1) != DocumentsContract.Document.MIME_TYPE_DIR) {
                    out.add(DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)))
                }
            }
        }
        return out
    }
}
