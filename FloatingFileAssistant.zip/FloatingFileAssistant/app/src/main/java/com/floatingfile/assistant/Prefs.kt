package com.floatingfile.assistant

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("ffa", Context.MODE_PRIVATE)

    fun chunkKb(c: Context) = sp(c).getInt("chunkKb", 1024)
    fun setChunkKb(c: Context, v: Int) = sp(c).edit().putInt("chunkKb", v).apply()

    fun maxUnzipMb(c: Context) = sp(c).getInt("maxUnzipMb", 512)
    fun setMaxUnzipMb(c: Context, v: Int) = sp(c).edit().putInt("maxUnzipMb", v).apply()

    fun restoreOnBoot(c: Context) = sp(c).getBoolean("boot", false)
    fun setRestoreOnBoot(c: Context, v: Boolean) = sp(c).edit().putBoolean("boot", v).apply()

    fun bubbleWanted(c: Context) = sp(c).getBoolean("bubbleOn", false)
    fun setBubbleWanted(c: Context, v: Boolean) = sp(c).edit().putBoolean("bubbleOn", v).apply()

    fun bubbleX(c: Context) = sp(c).getInt("bx", 0)
    fun bubbleY(c: Context) = sp(c).getInt("by", 400)
    fun setBubblePos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("bx", x).putInt("by", y).apply()
}
