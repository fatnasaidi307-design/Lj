package com.floatingfile.assistant

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Remembers only URIs of files the user explicitly shared (never file contents). */
object RecentStore {
    private const val KEY = "recent"
    private const val MAX = 20

    private fun raw(ctx: Context): JSONArray =
        try { JSONArray(ctx.getSharedPreferences("ffa", Context.MODE_PRIVATE).getString(KEY, "[]")) }
        catch (_: Exception) { JSONArray() }

    fun load(ctx: Context): List<Uri> {
        val a = raw(ctx)
        return (0 until a.length()).map { Uri.parse(a.getJSONObject(it).getString("uri")) }
    }

    fun add(ctx: Context, items: List<Item>) {
        val out = JSONArray()
        val seen = HashSet<String>()
        // newest first
        for (it in items.filter { !it.local }) {
            if (seen.add(it.uri.toString())) out.put(JSONObject().put("uri", it.uri.toString()).put("name", it.name))
        }
        val old = raw(ctx)
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (out.length() >= MAX) break
            if (seen.add(o.getString("uri"))) out.put(o)
        }
        ctx.getSharedPreferences("ffa", Context.MODE_PRIVATE).edit().putString(KEY, out.toString()).apply()
    }

    fun clear(ctx: Context) =
        ctx.getSharedPreferences("ffa", Context.MODE_PRIVATE).edit().remove(KEY).apply()
}
