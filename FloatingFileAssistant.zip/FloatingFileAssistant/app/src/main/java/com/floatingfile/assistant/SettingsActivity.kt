package com.floatingfile.assistant

import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import java.io.File

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(24))
        }
        fun label(t: String, size: Float = 15f) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, dp(12), 0, dp(2))
        }.also { col.addView(it) }

        label("Settings", 24f)

        val chunkLabel = label("")
        val chunk = Slider(this).apply {
            valueFrom = 64f; valueTo = 8192f; stepSize = 64f
            value = Prefs.chunkKb(this@SettingsActivity).toFloat().coerceIn(64f, 8192f)
        }
        fun showChunk() { chunkLabel.text = "Read chunk size: ${chunk.value.toInt()} KB (used when inspecting files)" }
        showChunk()
        chunk.addOnChangeListener { _, v, _ -> Prefs.setChunkKb(this, v.toInt()); showChunk() }
        col.addView(chunk)

        val unzipLabel = label("")
        val unzip = Slider(this).apply {
            valueFrom = 64f; valueTo = 4096f; stepSize = 64f
            value = Prefs.maxUnzipMb(this@SettingsActivity).toFloat().coerceIn(64f, 4096f)
        }
        fun showUnzip() { unzipLabel.text = "Max total size when extracting a ZIP: ${unzip.value.toInt()} MB (extraction aborts, never truncates)" }
        showUnzip()
        unzip.addOnChangeListener { _, v, _ -> Prefs.setMaxUnzipMb(this, v.toInt()); showUnzip() }
        col.addView(unzip)

        col.addView(MaterialSwitch(this).apply {
            text = "Restore bubble after restart (if allowed by the phone)"
            isChecked = Prefs.restoreOnBoot(this@SettingsActivity)
            setOnCheckedChangeListener { _, c -> Prefs.setRestoreOnBoot(this@SettingsActivity, c) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) })

        fun button(t: String, f: () -> Unit) = MaterialButton(this).apply {
            text = t; setOnClickListener { f() }
        }.also {
            col.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        button("Clear recent files list") {
            RecentStore.clear(this); Toast.makeText(this, "Recent files cleared.", Toast.LENGTH_SHORT).show()
        }
        button("Delete locally extracted ZIP files") {
            File(cacheDir, "extracted").deleteRecursively()
            Toast.makeText(this, "Extracted files deleted.", Toast.LENGTH_SHORT).show()
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
