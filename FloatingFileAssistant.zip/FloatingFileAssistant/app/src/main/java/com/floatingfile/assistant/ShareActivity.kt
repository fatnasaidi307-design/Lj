package com.floatingfile.assistant

import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.content.IntentCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File

/** Review screen: inspect (in background), then explicitly send the checked files to ChatGPT. */
class ShareActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_URIS = "uris"
        const val EXTRA_RECENT = "recent"
        const val EXTRA_PRESELECT = "preselect"
    }

    private val items = mutableListOf<Item>()
    private val jobs = HashMap<Item, Job>()
    private val gate = Semaphore(2)
    private lateinit var adapter: Adapter
    private lateinit var summary: TextView
    private lateinit var sendBtn: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "Review files"; textSize = 22f; setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Files stay on your device until you tap Send. Sending uses Android's share system; " +
                "ChatGPT may ask you to confirm the conversation, and its own size, format and plan limits still apply."
            textSize = 13f; setPadding(0, dp(4), 0, dp(8))
        })
        summary = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, dp(8)) }
        root.addView(summary)
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@ShareActivity)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        adapter = Adapter()
        rv.adapter = adapter
        root.addView(rv)
        sendBtn = MaterialButton(this).apply {
            text = "Send to ChatGPT"
            setOnClickListener { send() }
        }
        root.addView(sendBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        val recent = intent.getBooleanExtra(EXTRA_RECENT, false)
        val uris: List<Uri> = if (recent) RecentStore.load(this)
        else IntentCompat.getParcelableArrayListExtra(intent, EXTRA_URIS, Uri::class.java) ?: arrayListOf()
        val preselect = !recent && intent.getBooleanExtra(EXTRA_PRESELECT, true)
        if (uris.isEmpty()) {
            Toast.makeText(this, if (recent) "No recent files yet." else "No files selected.", Toast.LENGTH_SHORT).show()
            finish(); return
        }
        for (u in uris) items.add(Items.fromUri(this, u, preselect))
        adapter.notifyDataSetChanged()
        updateSummary()
        items.toList().forEach { startInspect(it) }
    }

    // ---------- inspection (background, cancellable, retryable) ----------

    private fun startInspect(item: Item) {
        jobs[item]?.cancel()
        item.status = Status.PENDING; item.progress = 0; item.detail = ""
        refresh(item)
        val chunk = Prefs.chunkKb(this) * 1024
        jobs[item] = lifecycleScope.launch {
            try {
                gate.withPermit {
                    item.status = Status.CHECKING; refresh(item)
                    var last = -1
                    val r = FileInspector.inspect(applicationContext, item, chunk) { p ->
                        if (p != last) { last = p; item.progress = p; runOnUiThread { refresh(item) } }
                    }
                    item.status = r.status; item.detail = r.detail; item.sha256 = r.sha256; item.progress = 100
                }
            } catch (e: CancellationException) {
                item.status = Status.CANCELLED; item.detail = "Cancelled"
                refresh(item); updateSummary()
                throw e
            } catch (e: Exception) {
                item.status = Status.ERROR; item.detail = "Could not read file: ${e.message}"
            }
            refresh(item); updateSummary()
        }
    }

    private fun refresh(item: Item) {
        val i = items.indexOf(item)
        if (i >= 0) adapter.notifyItemChanged(i)
    }

    private fun updateSummary() {
        val sel = items.count { it.checked }
        val busy = items.count { it.status == Status.PENDING || it.status == Status.CHECKING }
        val bad = items.count { it.status == Status.ERROR }
        summary.text = "${items.size} file(s) · $sel selected" +
            (if (busy > 0) " · $busy checking" else "") + (if (bad > 0) " · $bad with problems" else "")
        sendBtn.isEnabled = sel > 0
    }

    // ---------- sending ----------

    private fun send() {
        val sel = items.filter { it.checked }
        if (sel.isEmpty()) return
        val busy = sel.filter { it.status == Status.PENDING || it.status == Status.CHECKING }
        if (busy.isNotEmpty()) {
            Toast.makeText(this, "Still checking ${busy.size} file(s). Wait, cancel, or untick them.", Toast.LENGTH_LONG).show()
            return
        }
        val bad = sel.filter { it.status == Status.ERROR || it.status == Status.CANCELLED }
        if (bad.isNotEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Can't send yet")
                .setMessage(bad.joinToString("\n") { "• ${it.name}: ${it.detail}" } + "\n\nRetry, or untick these files.")
                .setPositiveButton("OK", null).show()
            return
        }
        val warn = sel.filter { it.status == Status.WARNING }
        if (warn.isNotEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Warnings")
                .setMessage(warn.joinToString("\n") { "• ${it.name}: ${it.detail}" } + "\n\nSend anyway?")
                .setPositiveButton("Send anyway") { _, _ -> doSend(sel) }
                .setNegativeButton("Cancel", null).show()
        } else doSend(sel)
    }

    private fun doSend(sel: List<Item>) {
        val uris = sel.map { it.uri }
        val mimes = sel.map { it.mime }
        when (val o = ShareHelper.send(this, uris, mimes)) {
            is ShareHelper.Outcome.Launched -> {
                RecentStore.add(this, sel)
                Toast.makeText(
                    this,
                    "Android opened ChatGPT's share screen with ${sel.size} file(s). Confirm the conversation inside ChatGPT. " +
                        "This app cannot see whether the upload completes; ChatGPT will report any size, format or plan limit.",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            }
            is ShareHelper.Outcome.NoTarget -> MaterialAlertDialogBuilder(this)
                .setTitle("ChatGPT can't receive this")
                .setMessage(o.reason + "\n\nYou can open the normal Android share sheet instead.")
                .setPositiveButton("Share sheet") { _, _ ->
                    val r = ShareHelper.sendChooser(this, uris, mimes)
                    if (r is ShareHelper.Outcome.Failed) Toast.makeText(this, r.reason, Toast.LENGTH_LONG).show()
                    else finish()
                }
                .setNegativeButton("Cancel", null).show()
            is ShareHelper.Outcome.Failed -> MaterialAlertDialogBuilder(this)
                .setTitle("Share failed").setMessage(o.reason).setPositiveButton("OK", null).show()
        }
    }

    // ---------- ZIP (optional, user-triggered) ----------

    private fun showZipList(item: Item) {
        lifecycleScope.launch {
            try {
                val (entries, total) = ZipTools.list(applicationContext, item.uri, 1000)
                val lines = entries.map {
                    (if (it.dir) "📁 " else "") + it.name + (if (!it.dir && it.size >= 0) "  (${formatSize(it.size)})" else "")
                }
                val title = "${item.name}: $total entries" + if (total > entries.size) " (showing first ${entries.size})" else ""
                MaterialAlertDialogBuilder(this@ShareActivity).setTitle(title)
                    .setItems(lines.toTypedArray(), null).setPositiveButton("Close", null).show()
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { error("Cannot list archive", e.message) }
        }
    }

    private fun extractZip(item: Item) {
        val safe = item.name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dir = File(cacheDir, "extracted/${System.currentTimeMillis()}-$safe")
        Toast.makeText(this, "Extracting locally…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try {
                val res = ZipTools.extract(applicationContext, item.uri, dir, Prefs.maxUnzipMb(this@ShareActivity).toLong() * 1024 * 1024)
                val start = items.size
                for (f in res.files) {
                    val uri = FileProvider.getUriForFile(this@ShareActivity, "$packageName.fileprovider", f)
                    items.add(Item(uri, f.relativeTo(dir).path, f.length(), mimeFromName(f.name), false, true))
                }
                adapter.notifyItemRangeInserted(start, res.files.size)
                updateSummary()
                items.subList(start, items.size).toList().forEach { startInspect(it) }
                val extra = if (res.skipped > 0) "\n${res.skipped} entr(ies) with unsafe paths were skipped." else ""
                error("Extracted ${res.files.size} file(s)", "They were added below, unticked. Nothing is sent unless you tick and send them.$extra")
            } catch (e: CancellationException) { throw e }
            catch (e: ZipTools.ExtractLimitException) {
                error("Extraction stopped", "${e.message} Nothing was kept. You can raise the limit in Settings.")
            } catch (e: Exception) { error("Extraction failed", e.message) }
        }
    }

    private fun error(title: String, msg: String?) {
        MaterialAlertDialogBuilder(this).setTitle(title).setMessage(msg ?: "Unknown error")
            .setPositiveButton("OK", null).show()
    }

    // ---------- list UI ----------

    private fun outlined() = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)

    inner class VH(
        v: View, val check: CheckBox, val name: TextView, val detail: TextView,
        val bar: LinearProgressIndicator, val act: MaterialButton,
        val zipList: MaterialButton, val zipExtract: MaterialButton
    ) : RecyclerView.ViewHolder(v)

    inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = this@ShareActivity
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, dp(8))
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val check = CheckBox(ctx)
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val name = TextView(ctx).apply { textSize = 16f; setTypeface(typeface, Typeface.BOLD) }
            val detail = TextView(ctx).apply { textSize = 13f }
            val bar = LinearProgressIndicator(ctx).apply { max = 100 }
            val btns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val act = outlined(); val zl = outlined(); val ze = outlined()
            zl.text = "Contents"; ze.text = "Extract"
            btns.addView(act); btns.addView(zl); btns.addView(ze)
            col.addView(name); col.addView(detail); col.addView(bar); col.addView(btns)
            row.addView(check)
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            return VH(row, check, name, detail, bar, act, zl, ze)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = items[position]
            h.check.setOnCheckedChangeListener(null)
            h.check.isChecked = item.checked
            h.check.setOnCheckedChangeListener { _, c -> item.checked = c; updateSummary() }
            h.name.text = item.name
            val st = when (item.status) {
                Status.PENDING -> "Waiting…"
                Status.CHECKING -> "Checking… ${item.progress}%"
                Status.OK -> "✔ ${item.detail}"
                Status.WARNING -> "⚠ ${item.detail}"
                Status.ERROR -> "✖ ${item.detail}"
                Status.CANCELLED -> "Cancelled"
            }
            val sha = if (item.sha256 != null && (item.status == Status.OK || item.status == Status.WARNING))
                "\nSHA-256 ${item.sha256!!.take(16)}…" else ""
            h.detail.text = "${formatSize(item.size)} · $st$sha"
            val checking = item.status == Status.CHECKING
            h.bar.visibility = if (checking) View.VISIBLE else View.GONE
            if (checking) {
                h.bar.isIndeterminate = item.size <= 0
                if (item.size > 0) h.bar.setProgressCompat(item.progress, false)
            }
            when (item.status) {
                Status.CHECKING, Status.PENDING -> {
                    h.act.visibility = View.VISIBLE; h.act.text = "Cancel"
                    h.act.setOnClickListener { jobs[item]?.cancel() }
                }
                Status.ERROR, Status.CANCELLED -> {
                    h.act.visibility = View.VISIBLE; h.act.text = "Retry"
                    h.act.setOnClickListener { startInspect(item) }
                }
                else -> h.act.visibility = View.GONE
            }
            val zip = item.ext == "zip" && (item.status == Status.OK || item.status == Status.WARNING)
            h.zipList.visibility = if (zip) View.VISIBLE else View.GONE
            h.zipExtract.visibility = if (zip) View.VISIBLE else View.GONE
            h.zipList.setOnClickListener { showZipList(item) }
            h.zipExtract.setOnClickListener { extractZip(item) }
        }
    }
}
