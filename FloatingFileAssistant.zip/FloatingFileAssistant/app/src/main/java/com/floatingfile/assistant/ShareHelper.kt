package com.floatingfile.assistant

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

/** Hands files to the official ChatGPT app through the standard Android share mechanism. */
object ShareHelper {
    const val CHATGPT_PKG = "com.openai.chatgpt"

    sealed class Outcome {
        /** Android started ChatGPT's share screen. This does NOT mean the upload finished. */
        object Launched : Outcome()
        data class NoTarget(val reason: String) : Outcome()
        data class Failed(val reason: String) : Outcome()
    }

    fun chatGptInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(CHATGPT_PKG, 0); true
    } catch (_: PackageManager.NameNotFoundException) { false }

    private fun commonMime(mimes: List<String?>): String {
        val m = mimes.map { it ?: "*/*" }.distinct()
        if (m.size == 1) return m[0]
        val top = m.map { it.substringBefore('/') }.distinct()
        return if (top.size == 1) "${top[0]}/*" else "*/*"
    }

    fun buildIntent(uris: List<Uri>, mimes: List<String?>): Intent {
        val i = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        i.type = commonMime(mimes)
        val clip = ClipData.newRawUri("files", uris[0])
        for (u in uris.drop(1)) clip.addItem(ClipData.Item(u))
        i.clipData = clip
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) // temporary, read-only
        return i
    }

    fun send(ctx: Context, uris: List<Uri>, mimes: List<String?>): Outcome {
        if (!chatGptInstalled(ctx)) return Outcome.NoTarget("The official ChatGPT app (com.openai.chatgpt) is not installed.")
        val intent = buildIntent(uris, mimes).setPackage(CHATGPT_PKG)
        val handlers = ctx.packageManager.queryIntentActivities(intent, 0)
        if (handlers.isEmpty()) {
            return Outcome.NoTarget("ChatGPT is installed but does not offer a share target for this combination of ${uris.size} file(s) and type \"${intent.type}\".")
        }
        return try {
            ctx.startActivity(intent)
            Outcome.Launched
        } catch (e: Exception) {
            Outcome.Failed("Android could not open ChatGPT: ${e.message}")
        }
    }

    /** Fallback: standard Android share sheet (the user picks the target). */
    fun sendChooser(ctx: Context, uris: List<Uri>, mimes: List<String?>): Outcome = try {
        ctx.startActivity(Intent.createChooser(buildIntent(uris, mimes), "Share files"))
        Outcome.Launched
    } catch (e: Exception) {
        Outcome.Failed("Could not open the share sheet: ${e.message}")
    }
}
