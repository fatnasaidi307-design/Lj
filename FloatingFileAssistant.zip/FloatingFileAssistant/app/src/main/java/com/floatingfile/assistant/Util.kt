package com.floatingfile.assistant

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import java.util.Locale

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun formatSize(b: Long): String {
    if (b < 0) return "unknown size"
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

fun mimeFromName(name: String): String? =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())

enum class Status { PENDING, CHECKING, OK, WARNING, ERROR, CANCELLED }

class Item(
    val uri: Uri,
    val name: String,
    val size: Long,
    val mime: String?,
    var checked: Boolean,
    val local: Boolean = false
) {
    var status = Status.PENDING
    var detail = ""
    var progress = 0
    var sha256: String? = null
    val ext: String get() = name.substringAfterLast('.', "").lowercase()
}

object Items {
    fun fromUri(ctx: Context, uri: Uri, checked: Boolean): Item {
        var name = uri.lastPathSegment ?: "file"
        var size = -1L
        try {
            ctx.contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Exception) { }
        val mime = ctx.contentResolver.getType(uri)?.takeIf { it != "application/octet-stream" }
            ?: mimeFromName(name)
        return Item(uri, name, size, mime, checked)
    }
}
