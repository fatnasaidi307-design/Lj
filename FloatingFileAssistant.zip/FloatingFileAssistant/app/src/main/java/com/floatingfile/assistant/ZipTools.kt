package com.floatingfile.assistant

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipInputStream

/** Optional, user-triggered ZIP listing and local extraction. Nothing is ever sent automatically. */
object ZipTools {
    class ExtractLimitException(msg: String) : Exception(msg)
    data class Entry(val name: String, val size: Long, val dir: Boolean)
    data class Extracted(val files: List<File>, val skipped: Int)

    /** Returns the first [limit] entries and the TOTAL entry count (so the UI can say it is partial). */
    suspend fun list(ctx: Context, uri: Uri, limit: Int): Pair<List<Entry>, Int> = withContext(Dispatchers.IO) {
        val out = ArrayList<Entry>()
        var total = 0
        val s = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open file")
        ZipInputStream(s.buffered()).use { z ->
            while (true) {
                ensureActive()
                val e = z.nextEntry ?: break
                total++
                if (out.size < limit) out.add(Entry(e.name, e.size, e.isDirectory))
                z.closeEntry()
            }
        }
        Pair(out, total)
    }

    /**
     * Extracts into [dest] with zip-slip protection and hard limits. If a limit is hit the whole
     * extraction is rolled back and an exception is thrown (no silent truncation).
     */
    suspend fun extract(
        ctx: Context, uri: Uri, dest: File, maxBytes: Long, maxEntries: Int = 20000
    ): Extracted = withContext(Dispatchers.IO) {
        dest.mkdirs()
        val destPath = dest.canonicalPath + File.separator
        val files = ArrayList<File>()
        var skipped = 0
        var total = 0L
        var count = 0
        val buf = ByteArray(64 * 1024)
        var ok = false
        try {
            val s = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open file")
            ZipInputStream(s.buffered()).use { z ->
                while (true) {
                    ensureActive()
                    val e = z.nextEntry ?: break
                    if (e.isDirectory) { z.closeEntry(); continue }
                    count++
                    if (count > maxEntries) throw ExtractLimitException("The archive has more than $maxEntries files.")
                    val target = File(dest, e.name)
                    if (!target.canonicalPath.startsWith(destPath)) { skipped++; z.closeEntry(); continue }
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { o ->
                        while (true) {
                            ensureActive()
                            val n = z.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > maxBytes) throw ExtractLimitException("Uncompressed size exceeds the ${formatSize(maxBytes)} limit.")
                            o.write(buf, 0, n)
                        }
                    }
                    files.add(target)
                }
            }
            ok = true
            Extracted(files, skipped)
        } finally {
            if (!ok) dest.deleteRecursively()
        }
    }
}
